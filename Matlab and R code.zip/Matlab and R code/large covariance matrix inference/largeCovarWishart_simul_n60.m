% Importance Sampler for covariance matrix of the mulitvariate skew normal model.
% This code run a simulation study over Nreplications
clear;
%--------------------------------------------------------------------------
% Wishart prior for precision matrix (Omega):
%--------------------------------------------------------------------------
p = 10;  n = 60;  % NUmber of variables (p) and sample size (n)
Nreplications = 100; % Number of time to run the IS algorithm
% Prior scale matrix. Prior mean of Omega is nu*SCALE = eye(p);
SCALE = (1/(p-1))*eye(p); nu=(p-1);
%--------------------------------------------------------------------------
% QIL parameters:
%--------------------------------------------------------------------------
d = n;   lambda = ((1:d)/(d+1))';
Qsyn   = lambda;%=unifinv(lambda,0,1).Also,unifpdf(unifinv(lambda,0,1),0,1)=1
Covnum = lambda*(1-lambda)'; Covnum=triu(Covnum)+triu(Covnum,1)';% u(k)*(1-u(l)) for l>k.
Cov    = Covnum./n;
%--------------------------------------------------------------------------
% Importance sampler setup, using prior as the instrumental distribution:
%--------------------------------------------------------------------------
Niterations       = 10^5; % Number of Importance Samples
%--------------------------------------------------------------------------
% Preallocate objects before running simulations over Nreplications:
%--------------------------------------------------------------------------
rowPairs = (1:p)';  colPairs = 1:p;
rowPAIRS        = rowPairs(:,ones(p,1)); colPAIRS = colPairs(ones(p,1),:);
LowerDiagInd    = rowPAIRS > colPAIRS;
rowPAIRS        = reshape(rowPAIRS,[],1); colPAIRS = reshape(colPAIRS,[],1);
rowPAIRS        = rowPAIRS(LowerDiagInd); colPAIRS = colPAIRS(LowerDiagInd);
numUniquePairs  = p*(p-1)/2; MU  = zeros(1,p);
IndAllUniqPairs = 1:numUniquePairs;
IndDiag         = sub2ind([p,p], (1:10)', (1:10)');
RMSE_Sel10      = NaN(Nreplications,1);
RMSE_NonSel10   = NaN(Nreplications,1);
RMSE_Diag       = NaN(Nreplications,1);
ESSreplications = NaN(Nreplications,1);
CompTimeSecondsReplications = NaN(Nreplications,1);
%--------------------------------------------------------------------------

%==========================================================================
for r = 1:Nreplications % Run Nreplications of IS algorithm
%--------------------------------------------------------------------------
% Randomly generate a correlation matrix, SIGMAtrue:
%--------------------------------------------------------------------------
pd = 0;
while pd==0
 SIGMAtrue           = eye(p); % Initiate with p x p identity matrix.
 % randomly select 10 off-diagonal entries of SIGMAtrue to have nonzero correlations:
 sampleInd           = sort(randsample(numUniquePairs,10));
 rowPAIRSsel10       = rowPAIRS(sampleInd); % row indices
 colPAIRSsel10       = colPAIRS(sampleInd); % column indices
 IndSel10            = sub2ind([p,p], rowPAIRSsel10, colPAIRSsel10); % Linear index.
 SIGMAtrue(IndSel10) = unifrnd(-1,1,10,1);% set 10 nonzero correlations as independent Uniform(-1,1) draws. 
 [~,notpd]           = chol(SIGMAtrue) ; % Check if positive definite. 
 pd = notpd == 0;% Is positive definite when notpd = 0
end
% By now, we have linear indices of diagonal entries of precision matrix (IndDiag),
% and linear indices of randomly selected linear indices correlations with
% Uniform(-1,1 ) distribution.
% Now, set indices of zero correlations (IndNonSel10): 
NotsampleInd        = IndAllUniqPairs(~ismember(IndAllUniqPairs,sampleInd))';
rowPAIRSnonsel10    = rowPAIRS(NotsampleInd); 
colPAIRSnonsel10    = colPAIRS(NotsampleInd);
IndNonSel10         = sub2ind([p,p], rowPAIRSnonsel10, colPAIRSnonsel10); % Linear index.
% Simulate a data set of size n using randomly generated correlation matrix SIGMAtrue:
y                   = mvnrnd2(MU,SIGMAtrue,n); % Simulate data.
y                   = zscore(y,1); % Standardize data set to z-scores .
% Set the true value of the precision matrix:  
OMEGAtrue           = inv(SIGMAtrue);
%--------------------------------------------------------------------------
% Initiate objects for next IS algorithm run, for this single replication:
% -------------------------------------------------------------------------
E_Omega      = zeros(p,p); 
E_Omega2     = E_Omega;
MSE_Sel10    = 0;
MSE_NonSel10 = 0;
MSE_Diag     = 0;
Samples_ISweights = NaN(Niterations,1); % Store importance sampling weights setup
% -------------------------------------------------------------------------

%--------------------------------------------------------------------------
% Run this IS algorithm for this single replication:
% -------------------------------------------------------------------------
tic
for s = 1:Niterations
 % -------------------------------------------------------------------------
 % Sample from the prior for the precision matrix, Omega.
 % -------------------------------------------------------------------------
 Omega =  wishrnd(SCALE, nu); % Prior mean is (nu+(p-1))*eyep =  where nu = 1.
 % -------------------------------------------------------------------------
 % Calculate QIL of prior Omega sample (importance weight):
 % -------------------------------------------------------------------------
 MahTheta = diag(y*Omega*y'); % quadratic form.
 R        = chi2cdf(MahTheta,p,'upper');% complimentary chi-square cdf
 Q        = quantile(R,lambda);
 t        = (Q-Qsyn)'*(Cov\(Q-Qsyn));
 Like     = (t^((d/2)-1)).*exp(-t/2);
 Samples_ISweights(s) = Like;
 % ------------------------------------------------------------------------
 % Take averages (normalize at the end of the IS run):
 % ------------------------------------------------------------------------
 E_Omega      = (Like.* Omega    )              + E_Omega;
 E_Omega2     = (Like.*(Omega.^2))              + E_Omega2;
 MSE          = (Omega-OMEGAtrue).^2;
 MSE_Sel10    = (Like.*mean(MSE(IndSel10)))     + MSE_Sel10;
 MSE_NonSel10 = (Like.*mean(MSE(IndNonSel10)))  + MSE_NonSel10;
 MSE_Diag     = (Like.*mean(MSE(IndDiag)))      + MSE_Diag;
 % ------------------------------------------------------------------------
 if (s/500)==round(s/500); disp(s); end % Display iteration 
 % ------------------------------------------------------------------------
 if s == Niterations
  normISweights     = sum(Samples_ISweights);
  Samples_ISweights = Samples_ISweights./normISweights;%Final IS weights.
  ESS               = 1./sum(Samples_ISweights.^2,1);% Effective sample size
  E_Omega           = E_Omega ./normISweights;%Marginal posterior means
  E_Omega2          = E_Omega2./normISweights;
  SD_Omega          = sqrt(E_Omega2 - ((E_Omega).^2));%Marginal posterior standard deviations
  % Calculate the RMSEs:
  MSE_Sel10         = MSE_Sel10./normISweights;
  MSE_NonSel10      = MSE_NonSel10./normISweights;
  MSE_Diag          = MSE_Diag./normISweights;
  RMSE_Sel10(r)     = sqrt(MSE_Sel10);   % RMSE for 10 nonzero correlations
  RMSE_NonSel10(r)  = sqrt(MSE_NonSel10);% RMSE for zero correlations
  RMSE_Diag(r)      = sqrt(MSE_Diag);    % RMSE for variances/stds in diagonals.
  computationTimeSeconds        = toc; %Elapsed time
  ESSreplications(r)            = ESS;
  CompTimeSecondsReplications(r) = computationTimeSeconds;
 end
end

end
%==========================================================================

%==========================================================================
% Organize, display, and save output:
%==========================================================================
format bank
SummaryResults = mean([RMSE_Sel10,RMSE_NonSel10,RMSE_Diag,...
                       ESSreplications,CompTimeSecondsReplications],1)
% save output:
save(  char(strcat({'SIMULATION Bayesian Precision Matrix Estim '},...
       {'n='},num2str(n),{' '},{'p='},num2str(p),{' '},...
       {'Nreplications='},num2str(Nreplications),{' '},...
        strrep(datestr(datetime),':','_'),'.mat'))  )
%==========================================================================