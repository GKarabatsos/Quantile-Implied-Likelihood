% Importance Sampler for covariance matrix of the mulitvariate skew normal model.
clear;
% Import Breast Cancer Coimbra Data Set:
y   = xlsread('Breast Cancer Coimbra Data Set.csv');
y   = zscore(y,1);
n   = size(y,1); % n = 208
p   = size(y,2); % p = 61
MU  = zeros(1,p);
%--------------------------------------------------------------------------
% Wishart prior for precision matrix (Omega):
%--------------------------------------------------------------------------
SCALE = (1/(p-1))*eye(p); nu=(p-1);% Prior mean of Omega is nu*SCALE = eye(p);
%--------------------------------------------------------------------------
% QIL parameters:
%--------------------------------------------------------------------------
d = n;   lambda = ((1:d)/(d+1))';
Qsyn   = lambda;%=unifinv(lambda,0,1).Also,unifpdf(unifinv(lambda,0,1),0,1)=1
Covnum = lambda*(1-lambda)'; Covnum=triu(Covnum)+triu(Covnum,1)';% u(k)*(1-u(l)) for l>k.
Cov    = Covnum./n;
%--------------------------------------------------------------------------
% Importance sampler setup, using prior as the instrumental distribution:
%--------------------------------------------------------------------------
Niterations          = 10^5; %10^5; Number of Importance Samples
Samples_ISweights    = NaN(Niterations,1); % Store importance sampling weights setup
E_Omega              = zeros(p,p); E_Omega2              = E_Omega;
E_partialCorrelation = E_Omega;    E_partialCorrelation2 = E_Omega;
E_partialVariance    = zeros(p,1); E_partialVariance2    = E_partialVariance;
%--------------------------------------------------------------------------
tic

for s = 1:Niterations
 % -------------------------------------------------------------------------
 % Sample from the prior for the precision matrix, Omega.
 % -------------------------------------------------------------------------
 Omega =  wishrnd(SCALE, nu); % Prior mean is (nu+(p-1))*eyep =  where nu = 1.
 %OmegaSamples(:,:,s) = Omega;
 % -------------------------------------------------------------------------
 % Calculate QIL of prior Omega sample (importance weight):
 % -------------------------------------------------------------------------
 MahTheta = diag(y*Omega*y'); % quadratic form.
 R        = chi2cdf(MahTheta,p,'upper');% complimentary chi-square cdf
 Q        = quantile(R,lambda);
 t        = (Q-Qsyn)'*(Cov\(Q-Qsyn));
 Like     = (t^((d/2)-1)).*exp(-t/2);
 Samples_ISweights(s) = Like;
 % Take averages (normalize at the end of the IS run):
 E_Omega               = (Like.* Omega    )    + E_Omega;
 E_Omega2              = (Like.*(Omega.^2))    + E_Omega2;
 partialVariance       = 1./diag(Omega); 
 partialCorrelation    = -Omega./sqrt(partialVariance.*partialVariance');
 E_partialCorrelation  = (Like.*partialCorrelation)    + E_partialCorrelation;
 E_partialCorrelation2 = (Like.*partialCorrelation.^2) + E_partialCorrelation2; 
 E_partialVariance     = (Like.*partialVariance)       + E_partialVariance;
 E_partialVariance2    = (Like.*partialVariance.^2)    + E_partialVariance2;
 % -------------------------------------------------------------------------
 every = 100;
 if (s/every)==round(s/every); disp(s); end % Display iteration 
 % -------------------------------------------------------------------------
 if s == Niterations
  normISweights         = sum(Samples_ISweights);
  Samples_ISweights     = Samples_ISweights./normISweights;
  ESS                   = 1./sum(Samples_ISweights.^2,1);
  E_Omega               = E_Omega ./normISweights;
  E_Omega2              = E_Omega2./normISweights;
  E_partialCorrelation  = E_partialCorrelation ./normISweights;
  E_partialCorrelation2 = E_partialCorrelation2./normISweights;
  E_partialVariance     = E_partialVariance    ./normISweights;
  E_partialVariance2    = E_partialVariance2   ./normISweights;
  SD_Omega              = sqrt(E_Omega2              - ((E_Omega).^2));
  SD_partialCorrelation = sqrt(E_partialCorrelation2 - ((E_partialCorrelation).^2));
  SD_partialVariance    = sqrt(E_partialVariance2    - ((E_partialVariance).^2));
  E_partialCorrelationAndVariance                   = E_partialCorrelation;
  E_partialCorrelationAndVariance( logical(eye(p))) = E_partialVariance;
  SD_partialCorrelationAndVariance                  = SD_partialCorrelation;
  SD_partialCorrelationAndVariance(logical(eye(p))) = SD_partialVariance; 
 end
end

computationTimeSeconds = toc; %Elapsed time
format bank
% E_Omega
%SD_Omega
% E_partialCorrelation
%SD_partialCorrelation
% E_partialVariance
%SD_partialVariance
ESS_NumIterations_TimeSec = [ESS,Niterations,computationTimeSeconds]
%ESS_NumIterations_TimeSec =
%      18645.10     100000.00         64.06

% save output:
save(char(strcat({'Breast Cancer Data Bayesian Precision Matrix Estim'},{' '},strrep(datestr(datetime),':','_'),'.mat')))