colInd =  1:p; colInd = colInd(ones(p,1),:);
rowInd = (1:p)'; rowInd = rowInd(:,ones(1,p));
figure('Color','white');
subplot(1,2,1); stem3(colInd,rowInd,E_Omega,'MarkerFaceColor','g');
xlabel('Column #'); ylabel('Row #');  zlabel('Posterior expected precision')
subplot(1,2,2); stem3(colInd,rowInd,SD_Omega,'MarkerFaceColor','g');
xlabel('Column #'); ylabel('Row #');  zlabel('Posterior SD precision')

