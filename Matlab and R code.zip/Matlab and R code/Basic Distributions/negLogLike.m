function negLL = negLogLike(model,Q,lambda,n,theta)
  if strcmp(model,'Beta');             Qsyn = icdf('Beta',            [eps;lambda],theta(1),theta(2)              ); end
  if strcmp(model,'Binomial');         Qsyn = icdf('Normal',          [eps;lambda],theta(1),sqrt(theta(1)*(1-theta(1)))); end
  if strcmp(model,'BirnbaumSaunders'); Qsyn = icdf('BirnbaumSaunders',[eps;lambda],theta(1),theta(2)              ); end
  if strcmp(model,'Burr');             Qsyn = icdf('Burr',            [eps;lambda],theta(1),theta(2),theta(3)     ); end
  if strcmp(model,'Exponential');      Qsyn = icdf('Exponential',     [eps;lambda],1/theta(1)                     ); end
  if strcmp(model,'Gamma');            Qsyn = icdf('Gamma',           [eps;lambda],theta(1),theta(2)              ); end
  if strcmp(model,'Generalized Extreme Value'); Qsyn = icdf('Generalized Extreme Value',[eps;lambda],theta(1),theta(2),theta(3)); end
  if strcmp(model,'Geometric');        Qsyn = icdf('Normal',          [eps;lambda],(1-theta(1))/theta(1),sqrt((1-theta(1))/(theta(1)^2))); end
  if strcmp(model,'HalfNormal');       Qsyn = icdf('HalfNormal',      [eps;lambda],       0,theta(1)              ); end
  if strcmp(model,'InverseGaussian');  Qsyn = icdf('InverseGaussian', [eps;lambda],theta(1),theta(2)              ); end
  if strcmp(model,'Lognormal');        Qsyn = icdf('Lognormal',       [eps;lambda],theta(1),theta(2)              ); end
  if strcmp(model,'Negative Binomial');Qsyn = icdf('Normal',          [eps;lambda],(theta(1)*3)/(1-theta(1)),sqrt((theta(1)*3)/((1-theta(1))^2))); end
  if strcmp(model,'Normal, s2 known'); Qsyn = icdf('Normal',          [eps;lambda],theta(1),1                     ); end
  if strcmp(model,'Normal, mu known'); Qsyn = icdf('Normal',          [eps;lambda],3,sqrt(theta(1))               ); end
  if strcmp(model,'Normal');           Qsyn = icdf('Normal',          [eps;lambda],theta(1),theta(2)              ); end
  if strcmp(model,'Geometric');        Qsyn = icdf('Normal',          [eps;lambda],(1-theta(1))/theta(1),sqrt((1-theta(1))/(theta(1)^2))); end
  if strcmp(model,'Poisson');          Qsyn = icdf('Normal',          [eps;lambda],theta(1),sqrt(theta(1))        ); end
  if strcmp(model,'tLocationScale');   Qsyn = icdf('tLocationScale',  [eps;lambda],theta(1),theta(2),theta(3)     ); end
  if strcmp(model,'Uniform');          Qsyn = icdf('Uniform',         [eps;lambda],       0,theta(1)              ); end
  if strcmp(model,'Weibull');          Qsyn = icdf('Weibull',         [eps;lambda],theta(1),theta(2)              ); end
  if strcmp(model,'g and h') % for g and h model
   A = theta(1); B = exp(theta(2)); g = theta(3); h = exp(theta(4)); 
   c = .8; zQ = norminv([eps;lambda],0,1);
   Qsyn = A + B*(1 + c*tanh(g*zQ./2)).*zQ.*exp((h*(zQ.^2))/2);
  end
  if strcmp(model,'g and k') % for g and k model
   A = theta(1); B = exp(theta(2)); g = theta(3); k = exp(theta(4));
   c = .8; zQ = norminv([eps;lambda],0,1);   
   Qsyn = A + B*(1 + c*tanh(g*zQ./2)).*zQ.*(1+(zQ.^2)).^k;
  end
  if strcmp(model,'Bayes Bernoulli');         Qsyn = icdf('Normal',     [eps;lambda],theta(1),sqrt(theta(1)*(1-theta(1)))); end
  if strcmp(model,'Bayes Exponential');       Qsyn = icdf('Exponential',[eps;lambda],1/theta(1)                       ); end
  if strcmp(model,'Bayes Negative Binomial'); Qsyn = icdf('Normal',     [eps;lambda],(theta(1)*3)/(1-theta(1)),sqrt((theta(1)*3)/((1-theta(1))^2))); end
  if strcmp(model,'Bayes Normal, s2 known');  Qsyn = icdf('Normal',     [eps;lambda],theta(1),1                     ); end
  if strcmp(model,'Bayes Normal, mu known');  Qsyn = icdf('Normal',     [eps;lambda],3,sqrt(theta(1))               ); end
  if strcmp(model,'Bayes Normal');            Qsyn = icdf('Normal',     [eps;lambda],theta(1),theta(2)              ); end
  if strcmp(model,'Bayes Poisson');           Qsyn = icdf('Normal',     [eps;lambda],theta(1),sqrt(theta(1))        ); end
  if strcmp(model,'Bayes Uniform');           Qsyn = icdf('Uniform',    [eps;lambda],0,theta(1)                     ); end
  d     = length(lambda);
  fsyn  = 1./((d+1)*(Qsyn(2:d+1)-Qsyn(1:d))); % pdf estimate from equal probability histogram (1st entry ensures that the lowest quantile is assigned a density estimate.)
  Qsyn  = Qsyn(2:(d+1));
  Covnum = lambda*(1-lambda)'; Covnum = triu(Covnum)+triu(Covnum,1)';%must be lambda(m)*(1-lambda(l)) for l>m.
  Cov   = Covnum./(n*(fsyn)*fsyn'+eps);
  t     = (Q-Qsyn)'*(Cov\(Q-Qsyn));
  %negLL0= -log(chi2pdf(t+eps,d));
  negLL0= ((nthroot(t/d,3) - (1-(2/(9*d))))./sqrt(2/(9*d)))^2;%more numerically stable than -log(chi2pdf(t+eps,d));
  if strcmp(model(1:min(5,length(model))),'Bayes')
   if strcmp(model,'Bayes Bernoulli')||strcmp(model,'Bayes Negative Binomial')||strcmp(model,'Geometric')
      negLL  = negLL0 - log(unifpdf(theta(1),0,1)); end %uniform prior.
   if strcmp(model,'Bayes Exponential')
      negLL  = negLL0 - log(gampdf(theta(1),1,1));          end
   if strcmp(model,'Bayes Normal, s2 known')
      negLL  = negLL0 - log(normpdf(theta(1),0,sqrt(100))); end
   if strcmp(model,'Bayes Normal, mu known')
      negLL  = negLL0 - log(gampdf(1/(theta(1)^2),1,1));    end
   if strcmp(model,'Bayes Normal')
      negLL  = negLL0 - log(normpdf(theta(1),0,sqrt((theta(2)^2)*sqrt(100)))) - log(gampdf(1/(theta(2)^2),1,1)); end
   if strcmp(model,'Bayes Poisson')
      negLL  = negLL0 - log(gampdf(theta(1),1,1));          end
   if strcmp(model,'Bayes Uniform')
      negLL  = negLL0 - log(1/theta(1));                    end
   if strcmp(model,'Beta');             negLL = negLL0 - sum(log(real(unifpdf(theta,0,100)>0))); end
   if strcmp(model,'BirnbaumSaunders'); negLL = negLL0 - sum(log(real(unifpdf(theta,0,100)>0))); end
   if strcmp(model,'Burr');             negLL = negLL0 - sum(log(real(unifpdf(theta,0,100)>0))); end
   if strcmp(model,'Gamma');            negLL = negLL0 - sum(log(real(unifpdf(theta,0,100)>0))); end
   if strcmp(model,'Generalized Extreme Value'); negLL = negLL0 - sum(log(real(unifpdf(theta([1,3]),-100,100)>0))) - log(real(unifpdf(theta(2),0,100)>0)); end
   if strcmp(model,'HalfNormal');       negLL = negLL0 - sum(log(real(unifpdf(theta,0,100)>0))); end
   if strcmp(model,'InverseGaussian');  negLL = negLL0 - sum(log(real(unifpdf(theta,0,100)>0))); end
   if strcmp(model,'Lognormal');        negLL = negLL0 - log(real(unifpdf(theta(1),-100,100)>0)) - log(real(unifpdf(theta(1),0,100)>0)); end
   if strcmp(model,'tLocationScale');   negLL = negLL0 - log(normpdf(theta(1),0,sqrt(100))) - log(gampdf(theta(2),1,1)) - log(real(unifpdf(theta(3),3,40)>0)); end
   if strcmp(model,'Weibull');          negLL = negLL0 - sum(log(real(unifpdf(theta,0,100)>0))); end
  else
   negLL= negLL0;
  end
end