clear; 
tic;
n = 2000; % Simulation sample size
Epsilon = .1; % for d(Epsilon), number of equally-spaced quantiles elected for QMLE analysis

for dist = 1:19
%    
warning('off','all')
if dist==1
ySimul        = NaN(n,19);   trueParam       = cell(19,1);
distMLE       = cell(19,1);  distSEmle       = cell(19,1);
distdHat      = cell(19,1);  distlambdaHat   = cell(19,1);
distQMLE      = cell(19,1);  distSEqmle      = cell(19,1);
distQPostMode = cell(19,1);  distQSEPostMode = cell(19,1);
distEtheta    = cell(19,1);  distSDtheta     = cell(19,1); 
end
%---------------------------------------------------------------------------------------------------------
if dist== 1; likemodel='Binomial';                                     thetatrue = .3;
    y = binornd(1,thetatrue,n,1);                   trueParam{dist} =  thetatrue;                      end
%---------------------------------------------------------------------------------------------------------
if dist== 2; likemodel='Beta';                                         atrue = 3;  btrue  = 1;
    y = random(likemodel,atrue,btrue,n,1);          trueParam{dist} = [atrue,btrue];                   end
%---------------------------------------------------------------------------------------------------------
if dist== 3; likemodel='BirnbaumSaunders';                             btrue  = 3; gtrue = 1;
    y = random(likemodel,btrue,gtrue,n,1);          trueParam{dist} = [btrue,gtrue];                   end
%---------------------------------------------------------------------------------------------------------
if dist== 4; likemodel='Burr';                                         atrue = .5; ctrue  = 2; ktrue = 5;
    y = random(likemodel,atrue,ctrue,ktrue,n,1);    trueParam{dist} = [atrue,ctrue,ktrue];             end
%---------------------------------------------------------------------------------------------------------
if dist== 5; likemodel='Exponential';                                  thetatrue = 3;
    y = exprnd(1/thetatrue,n,1);                    trueParam{dist} =  thetatrue;                      end
%---------------------------------------------------------------------------------------------------------
if dist== 6; likemodel='Gamma';                                        atrue  = 3; btrue = 1;
    y = random(likemodel,atrue,btrue,n,1);          trueParam{dist} = [atrue,btrue];                   end
%---------------------------------------------------------------------------------------------------------
if dist== 7; likemodel='Geometric';                                    thetatrue = .3;
    y = geornd(thetatrue,n,1);                      trueParam{dist} =  thetatrue;                      end
%---------------------------------------------------------------------------------------------------------
if dist== 8; likemodel='Generalized Extreme Value';                    ktrue=0; sigmatrue=3; mutrue=0;
    y=random(likemodel,ktrue,sigmatrue,mutrue,n,1); trueParam{dist} = [ktrue,sigmatrue,mutrue];        end
%---------------------------------------------------------------------------------------------------------
if dist== 9; likemodel='HalfNormal';                                   mutrue = 0; sigmatrue = 3;
    y = random(likemodel,mutrue,sigmatrue,n,1);     trueParam{dist} = [mutrue,sigmatrue];              end
%---------------------------------------------------------------------------------------------------------
if dist==10; likemodel='InverseGaussian';                              atrue  = 3; btrue     = 1;
    y = random(likemodel,atrue,btrue,n,1);          trueParam{dist} = [atrue,btrue];                   end
%---------------------------------------------------------------------------------------------------------
if dist==11; likemodel='Lognormal';                                    mutrue = 3; sigmatrue = 1;
    y = random(likemodel,mutrue,sigmatrue,n,1);     trueParam{dist} = [mutrue,sigmatrue];              end
%---------------------------------------------------------------------------------------------------------
if dist==12; likemodel='Negative Binomial';                            rtrue  = 3; thetatrue = .3;
    y = nbinrnd(rtrue,thetatrue,n,1);               trueParam{dist} = [rtrue,thetatrue];               end
%---------------------------------------------------------------------------------------------------------
if dist==13; likemodel='Normal, s2 known';                             mutrue = 3; strue = 1;
    y = normrnd(mutrue,strue,n,1);                  trueParam{dist} = [mutrue,strue];                  end
%---------------------------------------------------------------------------------------------------------
if dist==14; likemodel='Normal, mu known';                             mutrue = 3; strue = 1;
    y = normrnd(mutrue,strue,n,1);                  trueParam{dist} = [mutrue,strue];                  end
%---------------------------------------------------------------------------------------------------------
if dist==15; likemodel='Normal';                                       mutrue = 3; strue = 1;
    y = normrnd(mutrue,strue,n,1);                  trueParam{dist} = [mutrue,strue];                  end
%---------------------------------------------------------------------------------------------------------
if dist==16; likemodel='Poisson';                                      mutrue = 3;
    y = poissrnd(3,n,1);                            trueParam{dist} =  mutrue;                         end
%---------------------------------------------------------------------------------------------------------
if dist==17; likemodel='tLocationScale';                               mutrue = 3; strue = 1; nutrue = 4;
    y = strue*trnd(nutrue,n,1) + mutrue;            trueParam{dist} = [mutrue,strue,nutrue];           end
%---------------------------------------------------------------------------------------------------------
if dist==18; likemodel='Uniform';                                      thetatrue = 3;
    y = unifrnd(0,thetatrue,n,1);                   trueParam{dist} =  thetatrue;                      end% model y ~ Unif(0,theta)
%---------------------------------------------------------------------------------------------------------
if dist==19; likemodel='Weibull';                                      atrue  = 3; btrue = 1;
    y = random(likemodel,atrue,btrue,n,1);          trueParam{dist} = [atrue,btrue];                   end
%---------------------------------------------------------------------------------------------------------
ySimul(:,dist) = y; 
continuousDist = ~(strcmp(likemodel,'Binomial')||strcmp(likemodel,'Negative Binomial')...
                   ||strcmp(likemodel,'Geometric')||strcmp(likemodel,'Poisson'));
%---------------------------------------------------------------------------------------------------------
% estimate lambda and d:
%---------------------------------------------------------------------------------------------------------       
ks2stat = Inf; d = 0;
while (ks2stat>Epsilon) && (d<=n)
 d = d+1;                 lambda        = ((1:d)/(d+1))';
 Q = quantile(y,lambda);  [~,~,ks2stat] = kstest2(Q,y);
end
%---------------------------------------------------------------------------------------------------------
% Find MLE and SEmle of theta:
%---------------------------------------------------------------------------------------------------------
if continuousDist
 if strcmp(likemodel,'Exponential')
   [MLE,CI95] = mle(y,'distribution',likemodel); MLE = 1/MLE; end %reparameterize to rate parameter
 if strcmp(likemodel,'Normal, s2 known')
   [MLE,CI95] = mle(y,'distribution','Normal');  MLE = MLE(1); CI95 = CI95(:,1);     end
 if strcmp(likemodel,'Normal, mu known')
   [MLE,CI95] = mle(y,'distribution','Normal');  MLE = MLE(2); CI95 = CI95(:,2);     end
if strcmp(likemodel,'Uniform')
   [MLE,CI95] = mle(y,'distribution',likemodel); MLE = MLE(2); CI95 = CI95(:,2);     end
 if ~(strcmp(likemodel,'Normal, s2 known')||strcmp(likemodel,'Normal, mu known')...
    ||strcmp(likemodel,'Uniform')||strcmp(likemodel,'Exponential'))
    [MLE,CI95] = mle(y,'distribution',likemodel);
 end
 SEmle      = (CI95(2,:)-CI95(1,:))./(2*1.96);
else
 if strcmp(likemodel,'Binomial') ; [MLE,CI95] = mle(y,'distribution',likemodel,'ntrials',1); end
 if strcmp(likemodel,'Geometric'); [MLE,CI95] = mle(y,'distribution',likemodel);             end
 if strcmp(likemodel,'Negative Binomial')
  [MLE,CI95] = mle(y,'distribution',likemodel); MLE = MLE(2); CI95 = CI95(:,2);      end
 if strcmp(likemodel,'Poisson');   [MLE,CI95] = mle(y,'distribution',likemodel);     end
 SEmle      = (CI95(2,:)-CI95(1,:))./(2*1.96);
end
%---------------------------------------------------------------------------------------------------------
% find MLE of lambda, and QMLE, SEqmle:
%---------------------------------------------------------------------------------------------------------
% if d==1; negLLval = NaN(210,1); QMLEs = cell(210,1); SEqmles = QMLEs; end
if continuousDist
 Q = quantile(y,lambda);
else % Do normal transformation of data quantiles, for discrete distributions: 
 if strcmp(likemodel,'Binomial');          Q = norminv(lambda,MLE,sqrt(MLE*(1-MLE)));                     end
 if strcmp(likemodel,'Geometric');         Q = norminv(lambda,(1-MLE)/MLE,sqrt((1-MLE)/(MLE^2)));         end
 if strcmp(likemodel,'Negative Binomial'); Q = norminv(lambda,(MLE*3)/(1-MLE),sqrt((MLE*3)/((1-MLE)^2))); end
 if strcmp(likemodel,'Poisson');           Q = norminv(lambda,MLE,sqrt(MLE));                             end
end
[QMLE,negLLval,~,~,~,hessian] = fminunc(@(theta) negLogLike(likemodel,Q,lambda,n,theta),MLE);
SEqmle                        = real(sqrt(diag(inv(hessian))))';
%--------------------------------------------------------------------------
% Find the Bayesian solution for selected distributions:
%--------------------------------------------------------------------------
if dist==1  %  Bayes Bernoulli model
  Bayesmodel =  'Bayes Bernoulli';
  a = 1; b = 1;% Prior set up. theta ~ Beta(a,b) prior.
  r = sum(y); an = a+r; bn = b+n-r;
  Etheta  = an/(an+bn); SDtheta = sqrt((an*bn)/(((an+bn)^2)*(an+bn+1)));  
  distEtheta{dist}  = Etheta;
  distSDtheta{dist} = SDtheta;
end
if dist==5  %  Bayesian exponential model
  Bayesmodel = strcat({'Bayes'},{' '},likemodel); Bayesmodel = Bayesmodel{:};
  a = 1; b = 1;% Prior set up. theta ~ Gamma(a,b) prior (a shape; b rate; mean a/b).
  % the following posterior quantities is in terms of the rate parameter
  % (MATLAB parameterizes exponential in terms of the mean, and mean = 1/rate.
  t = sum(y);
  Etheta  = (a+n)/(b+t); %Posterior: theta ~ Ga(a+n,b+t)
  SDtheta = sqrt((a+n)/((b+t)^2));
  distEtheta{dist}  = Etheta;
  distSDtheta{dist} = SDtheta;
end
if dist==12 %  Bayes Negative binomial model
  Bayesmodel = strcat({'Bayes'},{' '},likemodel); Bayesmodel = Bayesmodel{:};
  a = 1; b = 1;% Prior set up. theta ~ Beta(a,b) prior.
  r = rtrue; t = sum(y); an = a+(n*r); bn = b+t;
  Etheta  = an/(an+bn);
  SDtheta = sqrt((an*bn)/(((an+bn)^2)*(an+bn+1)));
  distEtheta{dist}  = Etheta;
  distSDtheta{dist} = SDtheta;
end
if dist==13 %  Bayes Normal model, s2 known
  Bayesmodel = strcat({'Bayes'},{' '},likemodel); Bayesmodel = Bayesmodel{:}; 
  mu_mu = 0; s2_mu = 100;% Prior set up. mu ~ Normal(mu_mu,s2_mu) prior.
  s2true = strue^2;
  Emu    = ((mu_mu*(1/s2_mu))+(n*(1/s2true)*mean(y)))/((1/s2_mu)+(n*(1/s2true)));
  SDmu   = sqrt(1/((1/s2_mu)+(n*(1/s2true))));
  distEtheta{dist}  = Emu;
  distSDtheta{dist} = SDmu;
end
if dist==14  %  Bayes Normal model, mu known
  Bayesmodel = strcat({'Bayes'},{' '},likemodel); Bayesmodel = Bayesmodel{:}; 
  a = 1; b = 1;  % choices a=0, b=0 is the reference noninformative prior.
  t    = sum((y-mutrue).^2);
  Es2  = (b+(t/2))/(a+(n/2)-1);
  SDs2 = sqrt(((b+(t/2))^2)/(((a+(n/2)-1)^2)*(a+(n/2)-2)));
  distEtheta{dist}  = Es2;
  distSDtheta{dist} = SDs2;
end
if dist==15  %  Bayes Normal model, mu and s2 unknown
  Bayesmodel = strcat({'Bayes'},{' '},likemodel); Bayesmodel = Bayesmodel{:};
  mu_mu = 0; s2_mu = 100; n0 = 1; a = 1; b = 1;  % NIG prior parameters.
  meany = mean(y); s2 = var(y,1); an = a + (n/2);
  bn    = b + (.5*n*s2) + (.5*((n0+n)^-1)*n0*n*((mu_mu-meany)^2));
  Emu   = ((n0*mu_mu)+(n*meany))/(n0+n);
  SDmu  = sqrt((((n0+n)*(a+(.5*n))*(1/bn))^-1)*an*((an-2)^(-1)));
  Es2   = bn/(a+(n/2)-1);
  SDs2  = sqrt((bn^2)/(((an-1)^2)*(an-2)));
  distEtheta{dist}  = [Emu, Es2];
  distSDtheta{dist} = [SDmu,SDs2];
end
if dist==16  %  Bayes Poisson model
  Bayesmodel = strcat({'Bayes'},{' '},likemodel); Bayesmodel = Bayesmodel{:}; 
  a = 1; b = 1;% Prior set up. theta ~ Gamma(a,b) prior (a shape; b rate; mean a/b).
  an = a + sum(y);  bn = b + n;
  Etheta  = an/bn;  SDtheta = sqrt(an*(bn^(-2)));
  distEtheta{dist}  = Etheta;
  distSDtheta{dist} = SDtheta;
end
if dist==18  %  Bayes Uniform model
  Bayesmodel = strcat({'Bayes'},{' '},likemodel); Bayesmodel = Bayesmodel{:};
  t = max(y); an = a+n; bn = max(b,t);
  Etheta  = (bn*an)/(an-1);%Posterior: theta ~ Ga(a+n,b+t)
  SDtheta = sqrt(((bn^2)*an)/(((an-1)^2)*(an-2)));
  distEtheta{dist}  = Etheta;
  distSDtheta{dist} = SDtheta;
end
%--------------------------------------------------------------------------
% Find posterior mode, and its standard error (for models with informative priors):
%--------------------------------------------------------------------------
if (dist==5)||(dist==13)||(dist==14)||(dist==15)||(dist==16)||(dist==18)
[thetaPostMode,negLLval,~,~,~,hessian] = ...
    fminunc(@(theta) negLogLike(Bayesmodel,Q,lambda,n,theta),QMLE);
SEPostMode = real(sqrt(diag(inv(hessian))))';
else
  thetaPostMode= []; SEPostMode = [];
end
%--------------------------------------------------------------------------
% Save the results:
%--------------------------------------------------------------------------
distMLE{dist}  = MLE;  distSEmle{dist}     = SEmle;
distdHat{dist} = d;    distlambdaHat{dist} = lambda;
distQMLE{dist} = QMLE; distSEqmle{dist}    = SEqmle;
distQPostMode{dist} = thetaPostMode;  distQSEPostMode{dist} = SEPostMode;
%--------------------------------------------------------------------------
end

% Construct table of differences between 
% the true posterior mean(modes) and QIL's posterior mean (mode),
% and the true posterior SD (modes) and QIL's posterior SD.
TABLEestdiff = NaN(19,3); TABLEsddiff = NaN(19,3);
for dist2=1:19
 nParams = length(distMLE{dist2});
 BayesianResult   = (dist2==1)||(dist2==5)||(dist2==12)||(dist2==13)||(dist2==14)||(dist2==15)||(dist2==16)||(dist2==18);
 nonflatPrior     = ((dist2==5)||(dist2==13)||(dist2==14)||(dist2==15)||(dist2==16)||(dist2==18));
 if ~BayesianResult  % if flat prior, used MLE as the Bayes solution:
   TABLEestdiff(dist2,1:nParams)  = distMLE{dist2}     - distQMLE{dist2}  ;
   TABLEsddiff(dist2,1:nParams)   = distSEmle{dist2}   - distSEqmle{dist2};
 else
   if ~nonflatPrior  % if flat prior, and calculated exact Bayes solution:
    TABLEestdiff(dist2,1:nParams) = distEtheta{dist2}  - distQMLE{dist2}  ;
    TABLEsddiff(dist2,1:nParams)  = distSDtheta{dist2} - distSEqmle{dist2};
   end
   if nonflatPrior  % if informative prior, and calculated exact Bayes solution:
    TABLEestdiff(dist2,1:nParams) = distEtheta{dist2}  - distQPostMode{dist2};
    TABLEsddiff(dist2 ,1:nParams) = distSDtheta{dist2} - distQSEPostMode{dist2};
   end      
 end
 % add distribution numbers and the estimates of d, in the first two columns of the results.  
 if dist2 == 19
   TABLEestdiff = [(1:19)',[distdHat{:}]',TABLEestdiff];
   TABLEsddiff  = [(1:19)',[distdHat{:}]',TABLEsddiff];
 end
end
QMLEvsMLE_minmedmax     = [min(nanmin(abs(TABLEestdiff(:,3:5)))),median(nanmedian(abs(TABLEestdiff(:,3:5)))),max(nanmax(abs(TABLEestdiff(:,3:5))))];
QMLEvsMLEinSD_minmedmax = [min(nanmin(abs( TABLEsddiff(:,3:5)))),median(nanmedian(abs( TABLEsddiff(:,3:5)))),max(nanmax(abs( TABLEsddiff(:,3:5))))];
RMSEdist = NaN(19,1);
for l=1:19;  RMSEdist(l,:) = sqrt(mean((trueParam{l}-distQMLE{l}).^2)); end;
RMSEallQMLE = sqrt(mean(RMSEdist.^2));
RMSEdist = NaN(19,1);
for l=1:19;  RMSEdist(l,:) = sqrt(mean((trueParam{l}-distMLE{l}).^2)); end;
RMSEallMLE = sqrt(mean(RMSEdist.^2));
computationTime = toc;
format bank
[n,Epsilon,computationTime,RMSEallQMLE,RMSEallMLE]
[n,Epsilon,computationTime,QMLEvsMLE_minmedmax]
[n,Epsilon,computationTime,QMLEvsMLEinSD_minmedmax]
save(char(strcat({'Qfit simulations,'},...
     {' Epsilon = '},num2str(Epsilon),{', '},...
     {' n = '},num2str(n),{', '},...
     strrep(datestr(datetime),':','_'),'.mat')))