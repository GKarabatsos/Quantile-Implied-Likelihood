%clear;% simulate data:
%n = 20000;  mutrue = 3; s2true = 1;
%y = normrnd(mutrue,s2true,n,1);
% -------------------------------------------------------------------------
% Sulfur dioxide concentration, in ppb, as a numeric vector.(n = 63371)
clear;
Data = xlsread('mydata.xls');
y = Data(:,8);  y = y(~isnan(y),:);
y = y/100; % rescale to ppb/100 for more numerical stability.
n = length(y);
% -------------------------------------------------------------------------
% Prior set up. mu ~ Normal(mu_mu,s2_mu) prior.
mu_mu = 0; s2_mu = 100; n0 = 1;
a = 1; b = 1;  % choices a=0, b=0 is the reference noninformative prior.
% -------------------------------------------------------------------------
S = 50000; % # MH sampling iterations.
% -------------------------------------------------------------------------
for s = 1:S
  if s==1 % Initiate
   tic; warning('off','all')
   % ------------------------------------------------
   % estimate lambda and d
   % ------------------------------------------------
   ks2stat = Inf; d = 0;
   while (ks2stat>.01) && (d<=n)
    d = d+1;                 lambda        = ((1:d)/(d+1))';
    Q = quantile(y,lambda);  [~,~,ks2stat] = kstest2(Q,y);
   end %[d,ks2stat]
   Covnum     = lambda*(1-lambda)'; Covnum = triu(Covnum)+triu(Covnum,1)';%must be lambda(m)*(1-lambda(l)) for l>m.  
   Samples_mus2 = NaN(S,2);
   % ----------------------------------------------------------------------
   % Find the maximum log likelihood estimator as the starting value:
   % ----------------------------------------------------------------------
   MLE = mle(y,'distribution','Normal');
   thetahat = fminunc(@(theta) negLogLike('Normal',Q,lambda,n,theta),MLE);
   mu1      = thetahat(1);
   s21      = thetahat(2)^2; 
   % Adaptive Metropolis parameters:
   D = length([mu1,s21]); D2 = 2*D; muhat = [mu1,s21]'; EXXt = muhat*muhat';
   cMH1 = (2.38^2)/D; cMH2 = sqrt((.1^2)/D); LL0 = -Inf;  Jitter = .0001*eye(D);
  end
  % -----------------------------------------------------------------------
  % Sample from proposal distribution.
  % -----------------------------------------------------------------------
  if (rand>.05)&&(s>D2);  R =  mvnrnd([mu0,s20],cMH1*Vhat);
  else;          if s>1;  R = normrnd([mu0,s20],cMH2);      end; end;
  if s>1; mu1 = R(1); s21 = R(2); end;
  % -----------------------------------------------------------------------
  % Perform Metropolis update.
  % -----------------------------------------------------------------------
  Qsyn   = norminv([eps;lambda],mu1,sqrt(s21));   
  fsyn   = 1./((d+1)*(Qsyn(2:(d+1))-Qsyn(1:d))+eps); %equiprob histogram pdf
  Qsyn   = Qsyn(2:(d+1));
  Cov    = Covnum./(n*(fsyn)*fsyn');
  t      = (Q-Qsyn)'*(Cov\(Q-Qsyn));
  %LL1    = log(chi2pdf(t+eps,d));
  LL1    = -(((nthroot(t/d,3) - (1-(2/(9*d))))./sqrt(2/(9*d)))^2);  
  if ((a>0) && (b>0))
    LL1 = LL1 + log(normpdf(mu1,mu_mu,sqrt(s2_mu))) + log(gampdf(1/s21,a,1/b)); end
  if ((a==0) && (b==0)); LL1 = LL1 + log((s21>0)*normpdf(mu1,mu_mu,sqrt(s2_mu))); end
  if (log(rand)<(LL1-LL0))||(s==1); mu0 = mu1; s20 = s21; LL0 = LL1; end
  Samples_mus2(s,:) = [mu0,s20];
  % -----------------------------------------------------------------------   
  % Update proposal covariance matrix:
  % -----------------------------------------------------------------------
  muhat  = (Samples_mus2(s,:)' + (s-1)*muhat)/s;
  EXXt   = ((Samples_mus2(s,:)'*Samples_mus2(s,:)) + ((s-1)*EXXt))./s;
  Vhat   = (EXXt - muhat*muhat') + Jitter;
  if (s/1000)==round(s/1000); disp(s); end % Display iteration 
end
warning('on','all')
computationTimeSeconds = toc; %Elapsed time
meany    = mean(y); s2 = var(y,1); an = a + (n/2);
bn       = b + (.5*n*s2) + (.5*((n0+n)^-1)*n0*n*((mu_mu-meany)^2));
EmuTrue  = ((n0*mu_mu)+(n*meany))/(n0+n);
SDmuTrue = sqrt((((n0+n)*(a+(.5*n))*(1/bn))^-1)*an*((an-2)^(-1)));
Es2True  = bn/(a+(n/2)-1);
SDs2True = sqrt((bn^2)/(((an-1)^2)*(an-2)));
noBurn   = 1:S;
Emu      = mean(Samples_mus2(noBurn,1));
SDmu     =  std(Samples_mus2(noBurn,1),1);
Es2      = mean(Samples_mus2(noBurn,2));
SDs2     =  std(Samples_mus2(noBurn,2),1);
figure('Color','white');
%plot([0,S],[EthetaTrue,EthetaTrue],'Color','r','LineStyle',':'); hold on;
subplot(1,2,1); plot(Samples_mus2(:,1),'Color','k');
xlabel('Sampling Iteration'); ylabel('\mu'); xlim([0,S]); hold on;
text(S,EmuTrue,strcat({' '},num2str(round(EmuTrue,2))))
subplot(1,2,2); plot(Samples_mus2(:,2),'Color','k');
xlabel('Sampling Iteration'); ylabel('\sigma^2');  xlim([0,S]); hold on;
text(S,Es2True,strcat({' '},num2str(round(Es2True,2))))
format bank;
timeLab{1} = 'TimeSec'; timeLab{2} = 'Iterations'; 
timeResults = [computationTimeSeconds,S];
display(dataset([timeResults timeLab]));
Lab{1}  = 'Emu'; Lab{2} = 'SDmu'; Lab{3} = 'Es2'; Lab{4} = 'SDs2';
Results = [EmuTrue,SDmuTrue,Es2True,SDs2True; Emu,SDmu,Es2,SDs2];
display(dataset([Results Lab],'ObsNames',{'trueEst','Est'}));
% save output:
save(char(strcat({'Normal Analysis Sulfur dioxide '},strrep(datestr(datetime),':','_'),'.mat')))