library(MCMCpack)
# rbprobitGibbs Gibbs Sampler (Albert and Chib) for Binary Probit

# Markov Chain Monte Carlo for Probit Regression
# This function generates a sample from the posterior distribution of a probit 
# regression model using the data augmentation approach of Albert and Chib (1993). 
# The user supplies data and priors, and a sample from the posterior distribution 
# is returned as an mcmc object, which can be subsequently analyzed with functions 
# provided in the coda package.
#
#Usage
#MCMCprobit(formula, data = NULL, burnin = 1000, mcmc = 10000, thin = 1,
#  verbose = 0, seed = NA, beta.start = NA, b0 = 0, B0 = 0,
#  bayes.resid = FALSE, marginal.likelihood = c("none", "Laplace", "Chib95"),
#  ...)

#Arguments

#formula  Model formula.
data    Data frame.
burnin  The number of burn-in iterations for the sampler.
mcmc    The number of Gibbs iterations for the sampler.
thin    The thinning interval used in the simulation. 
 	  The number of Gibbs iterations must be divisible by this value.
verbose A switch which determines whether or not the progress of the sampler is 
        printed to the screen. If verbose is greater than 0 the iteration number 
        and the betas are printed to the screen every verboseth iteration.
seed    The seed for the random number generator. If NA, the Mersenne Twister 
        generator is used with default seed 12345; if an integer is passed it is 
        used to seed the Mersenne twister. The user can also pass a list of length 
        two to use the L'Ecuyer random number generator, which is suitable for parallel 
        computation. The first element of the list is the L'Ecuyer seed, which is a 
        vector of length six or NA (if NA a default seed of rep(12345,6) is used). 
        The second element of list is a positive substream number. See the MCMCpack 
        specification for more details.
beta.start  The starting value for the � vector. This can either be a scalar or a 
            column vector with dimension equal to the number of betas. If this takes 
            a scalar value, then that value will serve as the starting value for all 
            of the betas. The default value of NA will use the maximum likelihood 
            estimate of � as the starting value.
b0      The prior mean of �. This can either be a scalar or a column vector with 
        dimension equal to the number of betas. If this takes a scalar value, 
        then that value will serve as the prior mean for all of the betas.
B0    The prior precision of �. This can either be a scalar or a square matrix with 
      dimensions equal to the number of betas. If this takes a scalar value, then that 
      value times an identity matrix serves as the prior precision of �. Default value 
      of 0 is equivalent to an improper uniform prior on �.
bayes.resid
    Should latent Bayesian residuals (Albert and Chib, 1995) be returned? 
    Default is FALSE meaning no residuals should be returned. Alternatively, the 
    user can specify an array of integers giving the observation numbers for which 
    latent residuals should be calculated and returned. TRUE will return draws of 
    latent residuals for all observations.
marginal.likelihood  How should the marginal likelihood be calculated? 
        Options are: none in which case the marginal likelihood will not be 
        calculated, Laplace in which case the Laplace approximation 
        (see Kass and Raftery, 1995) is used, or Chib95 in which 
         case Chib (1995) method is used.

# Results for n = 30K. p = 8
rm(list=ls())
yX <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/binary reg n=30K.csv",header=FALSE,sep=",")
# ======================================================================================
# MCMC analysis using the Albert-Chib (1993) MCMC sampler.
# ======================================================================================
y   = matrix(yX[,1],ncol=1);   X = as.matrix(yX[,3:ncol(yX)]);
start_time <- Sys.time()
out = MCMCprobit(y~X,b0=0,B0=1/(10^8),mcmc = 100000, burnin = 0)
end_time <- Sys.time()
end_time - start_time
# Time difference of 5.801792 mins
summary(out,tvalues=beta)

# Results for n = 100K. p = 8
rm(list=ls())
yX <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/binary reg n=100K.csv",header=FALSE,sep=",")
# ======================================================================================
# MCMC analysis using the Albert-Chib (1993) MCMC sampler.
# ======================================================================================
y   = matrix(yX[,1],ncol=1);   X = as.matrix(yX[,3:ncol(yX)]);
start_time <- Sys.time()
out = MCMCprobit(y~X,b0=0,B0=1/(10^8),mcmc = 1000, burnin = 0)
end_time <- Sys.time()
end_time - start_time
# Time difference of  27.46204 secs
summary(out,tvalues=beta)
# for a 100K iteration run, 45.77007 minutes = (27.46204*100)/60

# Results for n = 1M. p = 8
rm(list=ls())
yX <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/binary reg n=1M.csv",header=FALSE,sep=",")
# ======================================================================================
# MCMC analysis using the Albert-Chib (1993) MCMC sampler.
# ======================================================================================
y   = matrix(yX[,1],ncol=1);   X = as.matrix(yX[,3:ncol(yX)]);
start_time <- Sys.time()
out = MCMCprobit(y~X,b0=0,B0=1/(10^8),mcmc = 1000, burnin = 0)
end_time <- Sys.time()
end_time - start_time
# Time difference of 2.826887 mins
# for a 100K iteration run,282.6887 minutes = (2.826887*100),  
# 4.711478 hours (282.6887/60)


# Results for 1001 selected multivariate quantiles. p=8
rm(list=ls())
yX <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/binary reg subset 1K from n=10M.csv",header=FALSE,sep=",")
# ======================================================================================
# MCMC analysis using the Albert-Chib (1993) MCMC sampler.
# ======================================================================================
y   = matrix(yX[,1],ncol=1);   X = as.matrix(yX[,3:ncol(yX)]);
start_time <- Sys.time()
out = MCMCprobit(y~X,b0=0,B0=1/(10^8),mcmc = 100000, burnin = 0)
end_time <- Sys.time()
end_time - start_time
# Time difference of 9.300014 secs


# Results for n = 30K. p = 100
rm(list=ls())
yX <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/binary reg n=30K, p = 100.csv",header=FALSE,sep=",")
# ======================================================================================
# MCMC analysis using the Albert-Chib (1993) MCMC sampler.
# ======================================================================================
y   = matrix(yX[,1],ncol=1);   X = as.matrix(yX[,3:ncol(yX)]);
start_time <- Sys.time()
out = MCMCprobit(y~X,b0=0,B0=1/(10^8),mcmc = 10000, burnin = 0)
end_time <- Sys.time()
end_time - start_time
# Time difference of 4.50594 mins
# 45.0594 minutes for 100K iterations   (4.50594*(100000/10000))
summary(out,tvalues=beta)


# Results for n = 100K. p = 100
rm(list=ls())
yX <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/binary reg n=100K, p = 100.csv",header=FALSE,sep=",")
# ======================================================================================
# MCMC analysis using the Albert-Chib (1993) MCMC sampler.
# ======================================================================================
y   = matrix(yX[,1],ncol=1);   X = as.matrix(yX[,3:ncol(yX)]);
start_time <- Sys.time()
out = MCMCprobit(y~X,b0=0,B0=1/(10^8),mcmc = 1000, burnin = 0)
end_time <- Sys.time()
end_time - start_time
# Time difference of 1.576619 mins
summary(out,tvalues=beta)
# for a 100K iteration run,  2.627698 hrs  (1.576619*(100000/1000))/60



# Diabetic data.
rm(list=ls())
data = read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/DiabeticData_Reformatted.csv",header=FALSE,sep=",")
X    = data[,1:27];
# z-score transform of covariates (and jitter with uniform random variates because X is not pd
X    = scale(X+matrix(runif(nrow(X)*ncol(X),-.001,.001),nrow(X),ncol(X))); 
y    = data[,28]; # EarlyReadmission into hospital indicator (coded 0 or 1).
start_time <- Sys.time()
out = MCMCprobit(y~X,b0=0,B0=1/(10^8),mcmc = 1000, burnin = 0)
end_time <- Sys.time()
end_time - start_time
summary(out,tvalues=beta)
# 43.45206 secs for 1000 iterations 
#  1.207002 hours for 100,000 iterations ((43.45206/60)*(100000/1000))/60



