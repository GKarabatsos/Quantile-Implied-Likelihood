% =========================================================================
% Simulate a data set:  n = 30K, p = 8
% =========================================================================clear;
clear; 
% data  = csvread('binary reg n=30K.csv');
% y = data(:,1);
% X = data(:,2:end);
% betatrue = [0,3,1.5,0,0,2,0,0,0]';
% after inputs above, then can proceed to fit logit model below, after skipping the next 6 lines
n   = 30000;
Abs = (1:8)'; Abs = abs(Abs-Abs'); 
X   = [ones(n,1),mvnrnd(zeros(1,8),.5.^Abs,n)];
betatrue = [0,3,1.5,0,0,2,0,0,0]'; eta = X*betatrue;
P   = exp(eta)./(1+exp(eta));      y   = binornd(1,P);
csvwrite('binary reg n=30K.csv',[y,X])
% Find the MLE, the starting value of the algorithm which minimizes the 
% negative log likelihood, to find the posterior mean (mode):
tic;
[MLE,~,stats] = glmfit(X(:,2:end),y,'binomial','link','logit'); SEMLE = stats.se;
[thetaPostMode,~,~,~,~,hessian] = fminunc(@(beta) negLogLikeBinary(y,X,beta),MLE);
SEPostMode = real(sqrt(diag(inv(hessian))));
toc;
% Elapsed time is  3.944138 seconds.
[quantile(abs(betatrue-thetaPostMode),[0,.5,1]'),...
 quantile(abs(MLE-thetaPostMode),[0,.5,1]'),...
 quantile(abs(SEMLE-SEPostMode),[0,.5,1]')]
%    0.0009    0.0022    0.0203
%    0.0271    0.0439    0.0263
%    0.1061    0.1001    0.0420

%RMSE = sqrt((betatrue-thetaPostMode).^2)'
%  0.0038    0.1317    0.1040    0.0349    0.0799    0.0308    0.0041    0.0359    0.0026


% =========================================================================
% Simulate a data set: n = 100K , p = 8
% =========================================================================
clear;
% data  = csvread('binary reg n=100K.csv');
% y = data(:,1);
% X = data(:,2:end);
% betatrue = [0,3,1.5,0,0,2,0,0,0]';
% after inputs above, then can proceed to fit logit model below, after skipping the next 6 lines
n   = 100000;
Abs = (1:8)'; Abs = abs(Abs-Abs'); 
X   = [ones(n,1),mvnrnd(zeros(1,8),.5.^Abs,n)];
betatrue = [0,3,1.5,0,0,2,0,0,0]'; eta = X*betatrue;
P   = exp(eta)./(1+exp(eta));      y   = binornd(1,P);
csvwrite('binary reg n=100K.csv',[y,X])
% Find the MLE, the starting value of the algorithm which minimizes the 
% negative log likelihood, to find the posterior mean (mode):
tic;
[MLE,dev,stats] = glmfit(X(:,2:end),y,'binomial','link','logit');
SEMLE = stats.se;
[thetaPostMode,negLLval,~,~,~,hessian] = fminunc(@(beta) negLogLikeBinary(y,X,beta),MLE);
SEPostMode = real(sqrt(diag(inv(hessian))));
toc;
% Elapsed time is 17.481585 seconds.
[quantile(abs(betatrue-thetaPostMode),[0,.5,1]'),...
 quantile(abs(MLE-thetaPostMode),[0,.5,1]'),...
 quantile(abs(SEMLE-SEPostMode),[0,.5,1]')]
%    0.0065    0.0002    0.0111
%    0.0481    0.0426    0.0144
%    0.0826    0.1022    0.0231

%RMSE = sqrt((betatrue-thetaPostMode).^2)'
%  0.0080    0.0826    0.0678    0.0740    0.0286    0.0481    0.0500    0.0074    0.0065



% =========================================================================
% Simulate a data set:  n = 1 million, p = 8
% =========================================================================
clear; 
% data  = csvread('binary reg n=1M.csv');
% y = data(:,1);
% X = data(:,2:end);
% betatrue = [0,3,1.5,0,0,2,0,0,0]';
% after inputs above, then can proceed to fit logit model below, after skipping the next 6 lines
n   = 1000000;
Abs = (1:8)'; Abs = abs(Abs-Abs'); 
X   = [ones(n,1),mvnrnd(zeros(1,8),.5.^Abs,n)];
betatrue = [0,3,1.5,0,0,2,0,0,0]'; eta = X*betatrue;
P   = exp(eta)./(1+exp(eta));      y   = binornd(1,P);
csvwrite('binary reg n=1M.csv',[y,X])
% Find the MLE, the starting value of the algorithm which minimizes the 
% negative log likelihood, to find the posterior mean (mode):
tic;
[MLE,dev,stats] = glmfit(X(:,2:end),y,'binomial','link','logit');
SEMLE = stats.se;
[thetaPostMode,negLLval,~,~,~,hessian] = fminunc(@(beta) negLogLikeBinary(y,X,beta),MLE);
SEPostMode = real(sqrt(diag(inv(hessian))));
toc;
% Elapsed time is 203.742396 seconds. 3.4 minutes.
[quantile(abs(betatrue-thetaPostMode),[0,.5,1]'),...
 quantile(abs(MLE-thetaPostMode),[0,.5,1]'),...
 quantile(abs(SEMLE-SEPostMode),[0,.5,1]')]
%   0.0007    0.0009    0.0035
%   0.0140    0.0176    0.0045
%   0.0430    0.0404    0.0072  
%RMSE = sqrt((betatrue-thetaPostMode).^2)'
%  0.0007    0.0429    0.0432    0.0158    0.0141    0.0227    0.0093    0.0019    0.0108


% =========================================================================
% Simulate a data set: n = 10 million, p = 8
% =========================================================================
clear;  
% data  = csvread('binary reg n=10M.csv');
% y = data(:,1);
% X = data(:,2:end);
% betatrue = [0,3,1.5,0,0,2,0,0,0]';
% after inputs above, then can proceed to fit logit model below, after skipping the next 6 lines
n   = 10000000;
Abs = (1:8)'; Abs = abs(Abs-Abs'); 
X   = [ones(n,1),mvnrnd(zeros(1,8),.5.^Abs,n)];
betatrue = [0,3,1.5,0,0,2,0,0,0]'; eta = X*betatrue;
P   = exp(eta)./(1+exp(eta));      y   = binornd(1,P);
%csvwrite('binary reg n=10M.csv',[y,X])
% Find the MLE, the starting value of the algorithm which minimizes the 
% negative log likelihood, to find the posterior mean (mode):
tic;
[MLE,~,stats] = glmfit(X(:,2:end),y,'binomial','link','logit');
SEMLE = stats.se;
[thetaPostMode,negLLval,~,~,~,hessian] = fminunc(@(beta) negLogLikeBinary(y,X,beta),MLE);
SEPostMode = real(sqrt(diag(inv(hessian))));
toc;
% Elapsed time is 1745.167362 seconds.    29.0861 minutes
[quantile(abs(betatrue-thetaPostMode),[0,.5,1]'),...
 quantile(abs(MLE-thetaPostMode),[0,.5,1]'),...
 quantile(abs(SEMLE-SEPostMode),[0,.5,1]')]
%  0.0006    0.0000    0.0011
%  0.0203    0.0193    0.0014
%  0.0414    0.0417    0.0023
%RMSE = sqrt((betatrue-thetaPostMode).^2)'
%0.0011    0.0321    0.0244    0.0158    0.0121    0.0184    0.0078    0.0034    0.0029




% now, get estimates based on subset selection from the n = 10 million data set (above).
tic;
yX = [zscore(y,1),X(:,2:9)];
[covyX,meanyX] = robustcov(yX);
D = pdist2(yX,meanyX,'mahalanobis',covyX);
MahDepth = 1./(1+D);
sortMahDepth = sort(MahDepth);
% Select subset of multivariate quantiles:
ks2stat = Inf; j = 0;
while (ks2stat>.001) && (j<n)
 j = j+50;
 Ind = 1:(ceil(n/j)-1):n;
 [~,~,ks2stat] = kstest2(sortMahDepth(Ind),sortMahDepth);
end %[d,ks2stat]
toc
% Time for subset selection: Elapsed time is 31.358170 seconds.
ynew = sortrows([y,MahDepth],2 ); ynew = ynew(:,1);
Xnew = sortrows([X,MahDepth],10); Xnew = Xnew(:,1:9);
ynew = ynew(Ind);
Xnew = Xnew(Ind,:);
csvwrite('binary reg subset 1K from n=10M.csv',[ynew,Xnew])
% Find the MLE, the starting value of the algorithm which minimizes the 
% negative log likelihood, to find the posterior mean (mode):
tic;
[MLE,~,stats] = glmfit(Xnew(:,2:end),ynew,'binomial','link','logit'); SEMLE = stats.se;
[thetaPostMode,~,~,~,~,hessian] = fminunc(@(beta) negLogLikeBinary(ynew,Xnew,beta),MLE);
SEPostMode = real(sqrt(diag(inv(hessian))));
toc;
% Elapsed time is  1.623039 seconds.
[quantile(abs(betatrue-thetaPostMode),[0,.5,1]'),...
 quantile(abs(MLE-thetaPostMode),[0,.5,1]'),...
 quantile(abs(SEMLE-SEPostMode),[0,.5,1]')]
%    0.0060    0.0017    0.1141
%    0.1219    0.0112    0.1473
%    0.3065    0.1062    0.2199
%RMSE = sqrt((betatrue-thetaPostMode).^2)'
%    0.0085    0.1206    0.0751    0.0752    0.0643    0.1458    0.1955    0.0043    0.0157



% =========================================================================
% Simulate a data set:  n = 30K, p = 100
% =========================================================================
clear;  
% data  = csvread('binary reg n=30K, p = 100.csv');
% y = data(:,1);
% X = data(:,2:end);
% betatrue = [0;repmat([3,1.5,0,0,2]',20,1)];
% after inputs above, then can proceed to fit logit model below, after skipping the next 6 lines
n   = 30000;
Abs = (1:100)'; Abs = abs(Abs-Abs'); 
X   = [ones(n,1),mvnrnd(zeros(1,100),.5.^Abs,n)];
betatrue = [0;repmat([3,1.5,0,0,2]',20,1)]; eta = X*betatrue;
P   = exp(eta)./(1+exp(eta));      y   = binornd(1,P);
csvwrite('binary reg n=30K, p = 100.csv',[y,X])
% Find the MLE, the starting value of the algorithm which minimizes the 
% negative log likelihood, to find the posterior mean (mode):
tic;
[MLE,~,stats] = glmfit(X(:,2:end),y,'binomial','link','logit'); SEMLE = stats.se;
[thetaPostMode,~,~,~,~,hessian] = fminunc(@(beta) negLogLikeBinary(y,X,beta),MLE);
SEPostMode = real(sqrt(diag(inv(hessian))));
toc;
% Elapsed time is  103.580793 seconds.   1.7263 minutes
[quantile(abs(betatrue-thetaPostMode),[0,.5,1]'),...
 quantile(abs(MLE-thetaPostMode),[0,.5,1]'),...
 quantile(abs(SEMLE-SEPostMode),[0,.5,1]')]
% 0.0014    0.0000    0.0481
% 0.0678    0.0000    0.0742
% 0.2844    0.0001    0.1053
%RMSE = sqrt((betatrue-thetaPostMode).^2)'
%Columns 1 through 12
%  0.0917    0.1101    0.0616    0.0155    0.0535    0.1035    0.1316    0.0657    0.0206    0.0155    0.0710    0.0468
%  Columns 13 through 24
%  0.1334    0.0114    0.0204    0.1966    0.0771    0.0335    0.0062    0.0111    0.0558    0.1790    0.0815    0.0633
%  Columns 25 through 36
%  0.0000    0.1540    0.1444    0.0857    0.1458    0.0488    0.1065    0.0971    0.0200    0.0472    0.0252    0.0679
%  Columns 37 through 48
%  0.1904    0.0045    0.1562    0.0032    0.0398    0.2008    0.0428    0.0028    0.0744    0.0635    0.2034    0.1264
%  Columns 49 through 60
%  0.0596    0.0346    0.0414    0.1054    0.1736    0.0095    0.1132    0.1948    0.0631    0.1525    0.0300    0.0138
%  Columns 61 through 72
%  0.1098    0.0044    0.1567    0.0417    0.0425    0.0678    0.1564    0.0379    0.0923    0.0266    0.1306    0.0949
%  Columns 73 through 84
%  0.1568    0.0299    0.0228    0.0270    0.2846    0.0207    0.0161    0.1292    0.1278    0.1567    0.0476    0.0156
%  Columns 85 through 96
%  0.0735    0.0186    0.1398    0.1148    0.0889    0.0155    0.0977    0.2146    0.0885    0.0942    0.0831    0.0673
%  Columns 97 through 101
%  0.1336    0.0619    0.0969    0.1183    0.0312



% =========================================================================
% Simulate a data set: n = 100K , p = 100
% =========================================================================clear;
clear;  
% data  = csvread('binary reg n=100K, p = 100.csv');
% y = data(:,1);
% X = data(:,2:end);
% betatrue = [0;repmat([3,1.5,0,0,2]',20,1)];
% after inputs above, then can proceed to fit logit model below, after skipping the next 6 lines
n   = 100000;
Abs = (1:100)'; Abs = abs(Abs-Abs'); 
X   = [ones(n,1),mvnrnd(zeros(1,100),.5.^Abs,n)];
betatrue = [0;repmat([3,1.5,0,0,2]',20,1)]; eta = X*betatrue;
P   = exp(eta)./(1+exp(eta));      y   = binornd(1,P);
csvwrite('binary reg n=100K, p = 100.csv',[y,X])
% Find the MLE, the starting value of the algorithm which minimizes the 
% negative log likelihood, to find the posterior mean (mode):
tic;
[MLE,dev,stats] = glmfit(X(:,2:end),y,'binomial','link','logit');
SEMLE = stats.se;
[thetaPostMode,negLLval,~,~,~,hessian] = fminunc(@(beta) negLogLikeBinary(y,X,beta),MLE);
SEPostMode = real(sqrt(diag(inv(hessian))));
toc;
% Elapsed time is 318.721037 seconds. 5.3120 minutes
[quantile(abs(betatrue-thetaPostMode),[0,.5,1]'),...
 quantile(abs(MLE-thetaPostMode),[0,.5,1]'),...
 quantile(abs(SEMLE-SEPostMode),[0,.5,1]')]
%  0.0001    0.0000    0.0250
%  0.0249    0.0002    0.0385
%  0.0949    0.0007    0.0536
%RMSE = sqrt((betatrue-thetaPostMode).^2)'
%RMSE =
%  Columns 1 through 10
%    0.0265    0.0332    0.0311    0.0457    0.0182    0.0519    0.0315    0.0504    0.0573    0.0538
%  Columns 11 through 20
%    0.0528    0.0394    0.0020    0.0206    0.0129    0.0295    0.0690    0.0178    0.0192    0.0098
%  Columns 21 through 30
%    0.0133    0.0116    0.0020    0.0165    0.0331    0.0063    0.0161    0.0008    0.0472    0.0400
%  Columns 31 through 40
%    0.0445    0.0116    0.0056    0.0318    0.0296    0.0108    0.0350    0.0485    0.0363    0.0017
%  Columns 41 through 50
%    0.0123    0.0210    0.0349    0.0146    0.0312    0.0325    0.0128    0.0064    0.0103    0.0038
%  Columns 51 through 60
%    0.0273    0.0403    0.0931    0.0305    0.0270    0.0115    0.0249    0.0489    0.0174    0.0013
%  Columns 61 through 70
%    0.0045    0.0225    0.0175    0.0266    0.0136    0.0473    0.0439    0.0499    0.0185    0.0445
%  Columns 71 through 80
%    0.0092    0.0186    0.0151    0.0346    0.0323    0.0082    0.0871    0.0059    0.0429    0.0043
%  Columns 81 through 90
%    0.0013    0.0949    0.0272    0.0327    0.0239    0.0332    0.0260    0.0161    0.0089    0.0280
%  Columns 91 through 100
%    0.0001    0.0321    0.0259    0.0114    0.0088    0.0084    0.0601    0.0106    0.0153    0.0267
%  Column 101
%    0.0005


% =========================================================================
% Simulate a data set:  n = 1 million, p = 100
% =========================================================================
clear;  
% data  = csvread('binary reg n=1M, p = 100.csv');
% y = data(:,1);
% X = data(:,2:end);
% betatrue = [0;repmat([3,1.5,0,0,2]',20,1)];
% after inputs above, then can proceed to fit logit model below, after skipping the next 6 lines
n   = 1000000;
Abs = (1:100)'; Abs = abs(Abs-Abs'); 
X   = [ones(n,1),mvnrnd(zeros(1,100),.5.^Abs,n)];
betatrue = [0;repmat([3,1.5,0,0,2]',20,1)]; eta = X*betatrue;
P   = exp(eta)./(1+exp(eta));      y   = binornd(1,P);
csvwrite('binary reg n=1M, p = 100.csv',[y,X])
% Find the MLE, the starting value of the algorithm which minimizes the 
% negative log likelihood, to find the posterior mean (mode):
tic;
[MLE,dev,stats] = glmfit(X(:,2:end),y,'binomial','link','logit');
SEMLE = stats.se;
[thetaPostMode,negLLval,~,~,~,hessian] = fminunc(@(beta) negLogLikeBinary(y,X,beta),MLE);
SEPostMode = real(sqrt(diag(inv(hessian))));
toc;
% Elapsed time is 4114.586863 seconds..
[quantile(abs(betatrue-thetaPostMode),[0,.5,1]'),...
 quantile(abs(MLE-thetaPostMode),[0,.5,1]'),...
 quantile(abs(SEMLE-SEPostMode),[0,.5,1]')]
% 0.0003    0.0000    0.0079
% 0.0080    0.0005    0.0120
% 0.0283    0.0016    0.0165
%RMSE = sqrt((betatrue-thetaPostMode).^2)'
%RMSE =
%  Columns 1 through 9
%    0.0017    0.0071    0.0051    0.0033    0.0076    0.0006    0.0236    0.0050    0.005
%  Columns 10 through 18
%    0.0023    0.0146    0.0270    0.0090    0.0109    0.0006    0.0037    0.0152    0.0057
%  Columns 19 through 27
%    0.0135    0.0053    0.0081    0.0283    0.0019    0.0019    0.0023    0.0022    0.0251
%  Columns 28 through 36
%    0.0063    0.0017    0.0031    0.0044    0.0155    0.0124    0.0163    0.0058    0.0127
%  Columns 37 through 45
%    0.0128    0.0019    0.0055    0.0035    0.0041    0.0102    0.0080    0.0006    0.0120
%  Columns 46 through 54
%    0.0062    0.0126    0.0088    0.0228    0.0148    0.0193    0.0178    0.0153    0.0061
%  Columns 55 through 63
%    0.0003    0.0179    0.0046    0.0069    0.0126    0.0029    0.0151    0.0079    0.0170
%  Columns 64 through 72
%    0.0081    0.0031    0.0021    0.0225    0.0007    0.0005    0.0138    0.0176    0.0117
%  Columns 73 through 81
%    0.0086    0.0018    0.0079    0.0166    0.0251    0.0065    0.0029    0.0159    0.0197
%  Columns 82 through 90
%    0.0095    0.0074    0.0155    0.0168    0.0077    0.0132    0.0161    0.0089    0.0073
%  Columns 91 through 99
%    0.0077    0.0122    0.0165    0.0026    0.0120    0.0041    0.0218    0.0040    0.0092
%  Columns 100 through 101
%    0.0120    0.0047
 
 
 

% now, get estimates based on subset selection from the n = 1 million data set (above).
tic;
yX = [zscore(y,1),X(:,2:end)];
[covyX,meanyX] = robustcov(yX);
D = pdist2(yX,meanyX,'mahalanobis',covyX);
MahDepth = 1./(1+D);
sortMahDepth = sort(MahDepth);
% Select subset of multivariate quantiles:
ks2stat = Inf; j = 0;
while (ks2stat>.001) && (j<n)
 j = j+50;
 Ind = 1:(ceil(n/j)-1):n;
 [~,~,ks2stat] = kstest2(sortMahDepth(Ind),sortMahDepth);
end %[d,ks2stat]
toc
% Time for subset selection: Elapsed time is 10.007412 seconds. 
ynew = sortrows([y,MahDepth],2 ); ynew = ynew(:,1);
Xnew = sortrows([X,MahDepth],102); Xnew = Xnew(:,1:101);
ynew = ynew(Ind);
Xnew = Xnew(Ind,:);
csvwrite('binary reg subset 1K from n=1M, p = 100.csv',[ynew,Xnew])
% Find the MLE, the starting value of the algorithm which minimizes the 
% negative log likelihood, to find the posterior mean (mode):
tic;
[MLE,~,stats] = glmfit(Xnew(:,2:end),ynew,'binomial','link','logit'); SEMLE = stats.se;
[thetaPostMode,~,~,~,~,hessian] = fminunc(@(beta) negLogLikeBinary(ynew,Xnew,beta),MLE);
SEPostMode = real(sqrt(diag(inv(hessian))));
toc;
% Elapsed time is   
[quantile(abs(betatrue-thetaPostMode),[0,.5,1]'),...
 quantile(abs(MLE-thetaPostMode),[0,.5,1]'),...
 quantile(abs(SEMLE-SEPostMode),[0,.5,1]')]
 

% =========================================================================
% Diabetic data
% =========================================================================
clear;
data = csvread('DiabeticData_Reformatted.csv');
% 27 binary covariate indicators (0 or 1) describing discharge disposition, 
% race, gender, Admission source, Medical Specialty, Age, Primary Diagnosis,
% and HbA1c: Hemoglobin A1c, Important measure of glucose control
% which is interacted with indicator of change in diabetes medications.
X    = [ones(101766,1),zscore(data(:,1:27),1)];
y    = data(:,28); % EarlyReadmission into hospital.
clear data;
tic;
[MLE,dev,stats] = glmfit(X(:,2:end),y,'binomial','link','logit');
SEMLE = stats.se;
[thetaPostMode,negLLval,~,~,~,hessian] = fminunc(@(beta) negLogLikeBinary(y,X,beta),MLE);
SEPostMode = real(sqrt(diag(inv(hessian))));
toc;
% Elapsed time is 65.383503 seconds.


