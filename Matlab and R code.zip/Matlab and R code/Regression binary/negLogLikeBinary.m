function negLL = negLogLikeBinary(Q,X,beta)
  Phi    = exp(X*beta)./(1+exp(X*beta));
  % max(Phi,(1-Phi)) is Bernoulli density of Bernoulli median:
  t      = (Q~=(Phi>=.5))./(.25./(max(Phi,(1-Phi)).^2));  
  negLL0 = sum(-log(chi2pdf(t+eps,1)));% d = 1
  negLL  = negLL0 - sum(log(normpdf(beta(2:end),0,10000)+eps));% prior variance is 10^8
end