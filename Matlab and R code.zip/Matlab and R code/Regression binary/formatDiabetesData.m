clear;
[num,txt,raw] = xlsread('diabetic_data_initial.csv');

% This code reformats the Diabetes data of Strack et al. 2014,
% available from the Supplementary information of that article in
% https://www.hindawi.com/journals/bmri/2014/781670/ 
% These data have sample size n = 101,766 and p = 27 covariates.
% The p covariates and the dependent variable are all binary (0 or 1) valued.
% =========================================================================
%                               COVARIATES
% =========================================================================
%--------------------------------------------------------------------------
% Discharge type
%--------------------------------------------------------------------------
% for some clues about coding, explore tabulate(num(:,8)) and 
% compare with Table 3 of Strack et al. (2014) paper.
DischargeType1 = num(:,8)==1; % Discharge to home (presumed, given available information)
%--------------------------------------------------------------------------
% Race:
%--------------------------------------------------------------------------
U = unique(txt(2:end,3));
RaceMiss  = strcmp(txt(2:end,3),U(1));
RaceAfAm  = strcmp(txt(2:end,3),U(2));
RaceCau   = strcmp(txt(2:end,3),U(4));
%--------------------------------------------------------------------------
% Gender:
%--------------------------------------------------------------------------
U = unique(txt(2:end,4));
Female    = strcmp(txt(2:end,4),U(1));
Male      = strcmp(txt(2:end,4),U(2));
%--------------------------------------------------------------------------
% Admission source
%--------------------------------------------------------------------------
% for some clues about coding this variable, explore tabulate(num(:,9)) and
% compare with Table 3 of Strack et al. (2014) paper.
AdmissionType7 = num(:,9)==7; % Emergency (presumed, given available information)
AdmissionType1 = num(:,9)==1; % Emergency (presumed, given available information)
%--------------------------------------------------------------------------
% Medical Specialty:
%--------------------------------------------------------------------------
U = unique(txt(2:end,12));
MedSpecialty_Cardiology  = strcmp(txt(2:end,12),U(5));
MedSpecialty_GenPractice = strcmp(txt(2:end,12),U(13));
MedSpecialty_InternalMed = strcmp(txt(2:end,12),U(20));
MedSpecialty_Surgery     = strcmp(txt(2:end,12),U(61))|strcmp(txt(2:end,12),U(62))|...
                           strcmp(txt(2:end,12),U(63))|strcmp(txt(2:end,12),U(64))|...
                           strcmp(txt(2:end,12),U(65))|strcmp(txt(2:end,12),U(66))|...
                           strcmp(txt(2:end,12),U(67))|strcmp(txt(2:end,12),U(68))|...
                           strcmp(txt(2:end,12),U(69))|strcmp(txt(2:end,12),U(70))|...
                           strcmp(txt(2:end,12),U(71))|strcmp(txt(2:end,12),U(72));
MedSpecialty_Missing     = strcmp(txt(2:end,12),U(1)); % Not a covariate.
MedSpecialty_Other       = ~(MedSpecialty_Cardiology|MedSpecialty_GenPractice|...
                             MedSpecialty_InternalMed|MedSpecialty_Surgery|MedSpecialty_Missing);
%--------------------------------------------------------------------------
% Age category
%--------------------------------------------------------------------------
U =  unique(txt(2:end,5));
Age0_10  = strcmp(txt(2:end,5),U(1)); Age10_20 = strcmp(txt(2:end,5),U(2));% Not a covariate. 
Age20_30 = strcmp(txt(2:end,5),U(3)); Age30_40 = strcmp(txt(2:end,5),U(4));% Not a covariate. 
Age40_50 = strcmp(txt(2:end,5),U(5)); Age50_60 = strcmp(txt(2:end,5),U(6)); % Not a covariate.
Age60_70 = strcmp(txt(2:end,5),U(7)); Age70_80 = strcmp(txt(2:end,5),U(8)); % Not a covariate.
Age80_90 = strcmp(txt(2:end,5),U(9)); Age90_100 = strcmp(txt(2:end,5),U(10)); % Not a covariate.
% Age categories used as covariates: --------------------------------------
Age30_60   = Age30_40|Age40_50|Age50_60;
Age60_100  = Age60_70|Age70_80|Age80_90|Age90_100;
%--------------------------------------------------------------------------
% Primary Diagnosis
%--------------------------------------------------------------------------
Diabetes    = round(num(:,19),0)==250;% Not a covariate. Reference.
Circulatory = (num(:,19)>=390) & (num(:,19)<=459);
Digestive   = (num(:,19)>=520) & (num(:,19)<=579);
Genitourinary = ((num(:,19)>=580) & (num(:,19)<=629))|(num(:,19)==788);
Injury      = (num(:,19)>=800) & (num(:,19)<=999);
Musculoskeletal = (num(:,19)>=710) & (num(:,19)<=739);
Neoplasms   = (num(:,19)>=140) & (num(:,19)<=239);
Respiratory = ((num(:,19)>=460)&(num(:,19)<=519))|(num(:,19)==786);
Other = ~(Circulatory|Digestive|Genitourinary|Diabetes|Injury|Musculoskeletal|Neoplasms|Respiratory);
%--------------------------------------------------------------------------
% HbA1c: Hemoglobin A1c, Important measure of glucose control
% Interacted with indicator of change in diabetes medications:
%--------------------------------------------------------------------------
U = unique(txt(2:end,24)); changeInDiabeticMedications = strcmp(txt(2:end,48),'Ch');
HbA1c_Normal = strcmp(txt(2:end,24),U(4));
HbA1c_HiMedicationsChanged    = ...
 (strcmp(txt(2:end,24),U(1))|strcmp(txt(2:end,24),U(2)))&changeInDiabeticMedications;
HbA1c_HiMedicationsNotChanged = ...
 (strcmp(txt(2:end,24),U(1))|strcmp(txt(2:end,24),U(2)))&(~changeInDiabeticMedications);
% HbA1c is the primary covariate(s) of interest. 
% All other covariates serves as control variables (see Strack et al. 2014)
%--------------------------------------------------------------------------
% FORMAT ALL OF THE 27 COVARIATES:
%--------------------------------------------------------------------------
X = [DischargeType1,RaceMiss,RaceAfAm,RaceCau,Female,Male,AdmissionType7,AdmissionType1,MedSpecialty_Cardiology,MedSpecialty_GenPractice,...
     MedSpecialty_InternalMed,MedSpecialty_Surgery,MedSpecialty_Missing,MedSpecialty_Other,Age30_60,Age60_100,Circulatory,Digestive,...
     Genitourinary,Injury,Musculoskeletal,Neoplasms,Respiratory,Other,HbA1c_Normal,HbA1c_HiMedicationsChanged,HbA1c_HiMedicationsNotChanged];%
% =========================================================================
%                           DEPENDENT VARIABLE
% =========================================================================
EarlyReadmission = strcmp(txt(2:end,50),'<30');
y = EarlyReadmission;
% =========================================================================

csvwrite('DiabeticData_Reformatted.csv',[X,y]);

