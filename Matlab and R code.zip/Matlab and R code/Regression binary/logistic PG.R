library(BayesLogit)

# Usage
# logit(y, X, n=rep(1,length(y)),
# m0=rep(0, ncol(X)), P0=matrix(0, nrow=ncol(X), ncol=ncol(X)),
# samp=1000, burn=500)
#
# Arguments
# y An N dimensional vector; yi is the average response at xi.
# X An N x P dimensional design matrix; xi is the ith row.
# n An N dimensional vector; n_i is the number of observations at each xi.
# m0 A P dimensional prior mean.
# P0 A PxP dimensional prior precision.
# samp The number of MCMC iterations saved.
# burn The number of MCMC iterations discarded.

# Results for n = 30K. p=8
rm(list=ls())
yX <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/binary reg n=30K.csv",header=FALSE,sep=",")
# ======================================================================================
# MCMC analysis using the Polya Gamma MCMC sampler.
# ======================================================================================
y = yX[,1];   X = yX[,2:ncol(yX)];
# prior precision:
P0 = matrix(0, nrow=ncol(X), ncol=ncol(X)); diag(P0) <- c(0,1/(10^8)*rep(1,ncol(X)-1))
output = logit(y, X, samp=10000, P0=P0, burn=0); ## Run logistic regression.
# Sampling complete: 240.554 sec.  (4.009233 mins) for 10000 iterations.
# 40.09233 minutes for 100000 iterations.   (240.554*(100000/10000))/60

# Results for n = 100K. p=8
rm(list=ls())
yX <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/binary reg n=100K.csv",header=FALSE,sep=",")
# ======================================================================================
# MCMC analysis using the Polya Gamma MCMC sampler.
# ======================================================================================
y = yX[,1];  X = yX[,2:ncol(yX)];
# prior precision:
P0 = matrix(0, nrow=ncol(X), ncol=ncol(X)); diag(P0) <- c(0,1/(10^8)*rep(1,ncol(X)-1))
output = logit(y, X, samp=1000, P0=P0, burn=0); ## Run logistic regression.
# Sampling complete: 78.208 sec. for 1000 iterations.
# 130.3467 minutes for 100000 iterations.   (78.208*(100000/1000))/60
# 2.172445 hours, (130.3467/60)
 
# Results for 1001 selected multivariate quantiles. p=8
rm(list=ls())
yX <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/binary reg subset 1K from n=10M.csv",header=FALSE,sep=",")
# ======================================================================================
# MCMC analysis using the Polya Gamma MCMC sampler.
# ======================================================================================
y = yX[,1];  X = yX[,2:ncol(yX)];
# prior precision:
P0 = matrix(0, nrow=ncol(X), ncol=ncol(X)); diag(P0) <- c(0,1/(10^8)*rep(1,ncol(X)-1))
output = logit(y, X, samp=100000, P0=P0, burn=0); ## Run logistic regression.
# Sampling complete: 74.646 sec. for 100000 iterations.
#  1.2441 minutes (74.646/60)


# Results for n = 30K. p=100
rm(list=ls())
yX <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/binary reg n=30K, p = 100.csv",header=FALSE,sep=",")
# ======================================================================================
# MCMC analysis using the Polya Gamma MCMC sampler.
# ======================================================================================
y = yX[,1];   X = yX[,2:ncol(yX)];
# prior precision:
P0 = matrix(0, nrow=ncol(X), ncol=ncol(X)); diag(P0) <- c(0,1/(10^8)*rep(1,ncol(X)-1))
output = logit(y, X, samp=1000, P0=P0, burn=0); ## Run logistic regression.
# Sampling complete: 492.549 sec. for 1000 iterations.
# 13.68192 hours (492.549*(100000/1000))/60/60


# Diabetic data.
rm(list=ls())
data <- read.csv(file="C:/Users/George/Desktop/qil/Results/Regression binary/DiabeticData_Reformatted.csv",header=FALSE,sep=",")
X    = cbind(matrix(1,nrow=101766,ncol=1),scale(data[,1:27])); # z-score transform of covariates
y    = data[,28]; # EarlyReadmission into hospital indicator (coded 0 or 1).
P0 = matrix(0, nrow=ncol(X), ncol=ncol(X)); diag(P0) <- c(0,1/(10^8)*rep(1,ncol(X)-1))
output = logit(y, X, samp=1000, P0=P0, burn=0); ## Run logistic regression.
# 64.248 sec. for 1000 iterations
# 107.08 minutes   (64.248/60) *(100000/1000)
# 1.784667 hours (107.08/60)


