clear;
% -------------------------------------------------------------------------
% LASSO prior set up for regression coefficients (beta). 
% beta ~ Prod_k Laplace(beta_k|0,1/lambda), lambda ~ Gamma(a1,a2)
a1 = .5; a2 = 1;
% -------------------------------------------------------------------------
S = 100000; % # MH sampling iterations.
% -------------------------------------------------------------------------
% Diabetes data of Strack et al. 2014 (n = 101766)
data = csvread('DiabeticData_Reformatted.csv');
% 27 binary covariate indicators (0 or 1) describing discharge disposition, 
% race, gender, Admission source, Medical Specialty, Age, Primary Diagnosis,
% and HbA1c: Hemoglobin A1c, Important measure of glucose control
% which is interacted with indicator of change in diabetes medications.
X    = zscore(data(:,1:27),1);
y    = data(:,28); % EarlyReadmission into hospital.
clear data;
% -------------------------------------------------------------------------
% Simulate a data set:
% -------------------------------------------------------------------------
%n   = 30000;
%Abs = (1:8)'; Abs = abs(Abs-Abs'); 
%X   = mvnrnd(zeros(1,8),.5.^Abs,n);
%X   = [ones(n,1),zscore(X,1)];
%eta = X*[0,3,1.5,0,0,2,0,0,0]'; % beta = [0,3,1.5,0,0,2,0,0,0]' 
%P   = exp(eta)./(1+exp(eta));
%y   = binornd(1,P);
% -------------------------------------------------------------------------
%
for s = 1:S
  if s==1 % Initiate
   tic; warning('off','all')
   n = length(y); 
   p = size(X,2);
   X = [ones(n,1),X];
   Samples_beta   = NaN(S,p+1);
   Samples_lambda = NaN(S,1);
   % ----------------------------------------------------------------------
   % Find the maximum log likelihood estimator as the starting value:
   % ----------------------------------------------------------------------
   MLE = glmfit(X(:,2:end),y,'binomial','link','logit')+eps;
   beta1 = MLE;   s2 = 1;  lambda0 = a1/a2;
   % Adaptive Metropolis parameters for beta (Atchade Rosenthal (2009): multivariate normal proposal with updated covariance):
   D = p+1; D2 = 2*D; muhat = beta1; EXXt = muhat*muhat';
   cMH1  = (2.38^2)/D; cMH2 = sqrt((.1^2)/D); 
   LL0 = -Inf; Jitter = .0001*eye(D);
   % Adaptive Metropolis parameters for lambda (Atchade Rosenthal (2005) method):
   PropVar_lambda = .01;
  end
  % -----------------------------------------------------------------------
  % Sample from proposal distribution.
  % -----------------------------------------------------------------------
  if (rand>.05)&&(s>D2); betaProposal = mvnrnd( beta0,cMH1*Vhat)'; 
  else;          if s>1; betaProposal = normrnd(beta0,cMH2);       end; end
  if s>1; beta1 = betaProposal; end;
  % -----------------------------------------------------------------------
  % Perform Metropolis update of betas.
  % -----------------------------------------------------------------------
  %if s==1
  % Phi   = exp(X*beta0)./(1+exp(X*beta0));  
  % t     = (y~=(Phi>=.5))./(.25./(max(Phi,(1-Phi)).^2));  % max(Phi,(1-Phi)) is Bernoulli density of Bernoulli median:
  % t     = t + eps;
  % LL0   = sum(log((t.^((1/2)-1)).*exp(-t/2)));% proportional to chi square pdf with df=1.
   %LL0   = sum(log(chi2pdf(t+eps,1)));% d = 1
  % LL0   = LL0 + sum(log((lambda0/2)*exp(-abs(beta1(2:end))./(1/lambda0))));      
  %end  
  Phi    = exp(X*beta1)./(1+exp(X*beta1));  
  t      = (y~=(Phi>=.5))./(.25./(max(Phi,(1-Phi)).^2));  % max(Phi,(1-Phi)) is Bernoulli density of Bernoulli median:
  t      = t + eps;
  LL1    = sum(log((t.^((1/2)-1)).*exp(-t/2)));% proportional to chi square pdf with df=1.
  %LL1    = sum(log(chi2pdf(t+eps,1)));% d = 1
  LL1    = LL1 + sum(log((lambda0/2)*exp(-abs(beta1(2:end))./(1/lambda0))));
  if (log(rand)<(LL1-LL0))||(s==1); beta0 = beta1; LL0 = LL1; end
  Samples_beta(s,:) = beta0';
  % Adaptive Metropolis: Update proposal covariance matrix for beta (Atchade Rosenthal (2009) method):
  muhat  = (Samples_beta(s,:)' + (s-1)*muhat)/s;
  EXXt   = ((Samples_beta(s,:)'*Samples_beta(s,:)) + ((s-1)*EXXt))./s;
  Vhat   = (EXXt - muhat*muhat') + Jitter;
  % -----------------------------------------------------------------------
  % Perform Metropolis update of lambda.
  % -----------------------------------------------------------------------  
  if s==1; LL0lambda  = sum(log((lambda0/2)*exp(-abs(beta0(2:end))./(1/lambda0))))+log(gampdf(lambda0,a1,1/a2)); end
  lambda1	          = exp(normrnd(lambda0,sqrt(PropVar_lambda))); % lambda proposal
  LL1lambda           = sum(log((lambda1/2)*exp(-abs(beta0(2:end))./(1/lambda1))))+log(gampdf(lambda1,a1,1/a2));
  acceptProb_lambda   = min(1,exp(LL1lambda - LL0lambda));
  if rand<acceptProb_lambda; lambda0 = lambda1; LL0lambda = LL1lambda; end
  Samples_lambda(s,:) = lambda0;
  % Adaptive Metropolis; update the proposal variance for lambda (Atchade-Rosenthal (2005) method).
  PropVar_lambda      = real(min(1000,max(eps,PropVar_lambda+((1/s)*(acceptProb_lambda-.44)))));
  if (s/500)==round(s/500); disp(s); end % Display iteration 
end
warning('on','all')
computationTimeSeconds = toc; %Elapsed time
Ebeta    = mean(Samples_beta);     SDbeta   = std(Samples_beta,1);
Elambda  = mean(Samples_lambda);   SDlambda = std(Samples_lambda,1);
%plot(Samples_beta(:,2))  plot(Samples_lambda)
% save output:
save(char(strcat({'Bayesian logit LASSO Diabetes data'},strrep(datestr(datetime),':','_'),'.mat')))