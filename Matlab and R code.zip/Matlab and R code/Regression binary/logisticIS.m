clear;
S = 100000; % #
% Simulated data:
dataName = 'binary reg n=30K.csv';
%dataName = 'binary reg n=100K.csv';
%dataName = 'binary reg n=1M.csv';
%dataName = 'binary reg n=10M.csv';
%dataName = 'binary reg subset 1K from n=10M.csv';
%dataName = 'binary reg n=30K, p = 100.csv';
%dataName = 'binary reg n=100K, p = 100.csv';
%dataName = 'binary reg n=1M, p = 100.csv';
data = csvread(dataName);
X    = zscore(data(:,3:end),1);
n = size(X,1);  p    = size(X,2);
X    = [ones(n,1),X];
y    = data(:,ones(1,S)); % EarlyReadmission into hospital.
% S samples from the mvn prior
beta   = mvnrnd(zeros(1,p+1),(1/(10^8))*eye(p+1),S)';
Phi    = exp(X*beta)./(1+exp(X*beta));
t      = (y~=(Phi>=.5))./(.25./(max(Phi,(1-Phi)).^2));  % max(Phi,(1-Phi)) is Bernoulli density of Bernoulli median:
t      = t + eps;
Like   = sum(log((t.^((1/2)-1)).*exp(-t/2)),1);% proportional to chi square pdf with df=1.







