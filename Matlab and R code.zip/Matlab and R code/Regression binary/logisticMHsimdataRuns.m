clear;
% -------------------------------------------------------------------------
% LASSO prior set up for regression coefficients (beta). 
% beta ~ Prod_k Laplace(beta_k|0,1/lambda), lambda ~ Gamma(a1,a2)
a1 = .5; a2 = 1;
% -------------------------------------------------------------------------
S = 100; % # MH sampling iterations.
% -------------------------------------------------------------------------
% Simulated data:
%dataName = 'binary reg n=30K.csv';
%dataName = 'binary reg n=100K.csv';
%dataName = 'binary reg n=1M.csv';
dataName = 'binary reg n=10M.csv';
%dataName = 'binary reg subset 1K from n=10M.csv';
%dataName = 'binary reg n=30K, p = 100.csv';
%dataName = 'binary reg n=100K, p = 100.csv';
%dataName = 'binary reg n=1M, p = 100.csv';
data = csvread(dataName);
X    = zscore(data(:,3:end),1);
y    = data(:,1); % EarlyReadmission into hospital.
clear data;
% -------------------------------------------------------------------------
%
for s = 1:S
  if s==1 % Initiate
   tic; warning('off','all')
   n = length(y); 
   p = size(X,2);
   X = [ones(n,1),X];
   Samples_beta   = NaN(S,p+1);
   Samples_lambda = NaN(S,1);
   % ----------------------------------------------------------------------
   % Find the maximum log likelihood estimator as the starting value:
   % ----------------------------------------------------------------------
   %MLE = glmfit(X(:,2:end),y,'binomial','link','logit')+eps;
   MLE = zeros(size(X,2),1);
   beta0 = MLE;   s2 = 1;  lambda0 = a1/a2;
   % Adaptive Metropolis parameters for beta (Atchade Rosenthal (2009): multivariate normal proposal with updated covariance):
   D = p+1; S2D = S*2*D; muhat = beta0; EXXt = muhat*muhat';
   cMH1 = 1/D; cMH2 = sqrt(.1^2); LL0 = -Inf; Jitter = .01*eye(D);
   % Adaptive Metropolis parameters for lambda (Atchade Rosenthal (2005) method):
   PropVar_lambda = .01;  LL0lambda = -Inf;
  end
  % -----------------------------------------------------------------------
  % Sample from proposal distribution.
  % -----------------------------------------------------------------------
  if (rand>.05)&&(s>S2D); betaProposal = normrnd(beta0,sqrt(cMH1*Vhat)); 
  else;                   betaProposal = normrnd(beta0,cMH2);           end
  beta1 = betaProposal;
  % -----------------------------------------------------------------------
  % Perform Metropolis update of betas.
  % -----------------------------------------------------------------------
  if s==1
   Phi   = exp(X*beta0)./(1+exp(X*beta0));  
   t     = (y~=(Phi>=.5))./(.25./(max(Phi,(1-Phi)).^2));  % max(Phi,(1-Phi)) is Bernoulli density of Bernoulli median:
   t     = t + eps;
   LL0   = sum(log((t.^((1/2)-1)).*exp(-t/2)));% proportional to chi square pdf with df=1.
   %LL0   = sum(log(chi2pdf(t+eps,1)));% d = 1
   LL0   = LL0 + sum(log((lambda0/2)*exp(-abs(beta1(2:end))./(1/lambda0))));      
  end  
  Phi    = exp(X*beta1)./(1+exp(X*beta1));  
  t      = (y~=(Phi>=.5))./(.25./(max(Phi,(1-Phi)).^2));  % max(Phi,(1-Phi)) is Bernoulli density of Bernoulli median:
  t      = t + eps;
  LL1    = sum(log((t.^((1/2)-1)).*exp(-t/2)));% proportional to chi square pdf with df=1.
  %LL1    = sum(log(chi2pdf(t+eps,1)));% d = 1
  LL1    = LL1 + sum(log((lambda0/2)*exp(-abs(beta1(2:end))./(1/lambda0))));
  if log(rand)<(LL1-LL0); beta0 = beta1; LL0 = LL1; end
  Samples_beta(s,:) = beta0';
  % Adaptive Metropolis: Update proposal covariance matrix for beta (Atchade Rosenthal (2009) method):
  muhat  = (Samples_beta(s,:)' + (s-1)*muhat)/s;
  EXXt   = ((Samples_beta(s,:)'*Samples_beta(s,:)) + ((s-1)*EXXt))./s;
  Vhat   = (EXXt - muhat*muhat') + Jitter;
  % -----------------------------------------------------------------------
  % Perform Metropolis update of lambda.
  % -----------------------------------------------------------------------  
  if s==1; LL0lambda  = sum(log((lambda0/2)*exp(-abs(beta0(2:end))./(1/lambda0))))+log(gampdf(lambda0,a1,1/a2)); end
  lambda1	          = exp(normrnd(lambda0,sqrt(PropVar_lambda))); % lambda proposal
  LL1lambda           = sum(log((lambda1/2)*exp(-abs(beta0(2:end))./(1/lambda1))))+log(gampdf(lambda1,a1,1/a2));
  acceptProb_lambda   = min(1,exp(LL1lambda - LL0lambda));
  if rand<acceptProb_lambda; lambda0 = lambda1; LL0lambda = LL1lambda; end
  Samples_lambda(s,:) = lambda0;
  % Adaptive Metropolis; update the proposal variance for lambda (Atchade-Rosenthal (2005) method).
  PropVar_lambda      = real(min(1000,max(eps,PropVar_lambda+((1/s)*(acceptProb_lambda-.44)))));
  if (s/500)==round(s/500); disp(s); end % Display iteration 
end
warning('on','all')
computationTimeSeconds = toc; %Elapsed time
Ebeta    = mean(Samples_beta);     SDbeta   = std(Samples_beta,1);
Elambda  = mean(Samples_lambda);   SDlambda = std(Samples_lambda,1);
computationTimeMinutes100Kiterations = (computationTimeSeconds/60)*(100000/S)