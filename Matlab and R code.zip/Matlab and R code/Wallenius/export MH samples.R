Dir = "C:\\Users\\Yanni  Leizla\\Desktop\\George\\PAPERS\\PAPERS, CURRENT\\qil\\code\\Results\\Wallenius\\Wallenius PISA2015 4schools, A-MH Samples 2018-08-18 08_26_12.csv";
colnames(Samples_theta) <- c( "Eat","StudyRead","FriendsPlay","TalkParents","WorkInHouseOrForPay","Exercise")

write.table(Samples_theta,Dir, row.names = FALSE,  sep=",")

