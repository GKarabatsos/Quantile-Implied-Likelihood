getwd() #returns the working directory file path- if it requires changing use setwd line of code below
#setwd("C:/Users/Yanni  Leizla/Desktop/PUF_SPSS_COMBINED_CMB_STU_QQQ") #sets the working directory file path to the location of the file you wish to import
setwd("C:/Users/George/Desktop/qil/Results/Wallenius)

install.packages("foreign", repos="http://cran.case.edu/") #import the foreign package which gives us the ability to read in SPSS data files-you can change the cran url if you wish
library("foreign") #activates the library called foreign

# Import school data file
mydataSchool <- read.spss("CY6_MS_CMB_SCH_QQQ.sav", use.value.labels = TRUE,to.data.frame=TRUE) #replace "mydatafile" with the SPSS file name you wish to import surrounded by quotes
ColNamesSchool = colnames(mydataSchool)
head(mydataSchool) #this command will display the first few rows of your data file
nrow(mydataSchool)#counts the number of rows in a data frame/file which can help to confirm all observations imported into R successfully
ColNamesSchool[c(1:3,23:33)] # variables on school activities offered by the school
# [1] "CNTRYID"    "CNT"        "CNTSCHID"   "SC053Q01TA" "SC053Q02TA"
# [6] "SC053Q03TA" "SC053Q04TA" "SC053Q05NA" "SC053Q06NA" "SC053Q07TA"
#[11] "SC053Q08TA" "SC053Q09TA" "SC053Q10TA" "SC053D11TA"
mydataSchoolActiv = mydataSchool[,c(1:3,23:33)];
write.csv(mydataSchoolActiv, file = "Imported PISA2015USAschoolActiv.csv")


# Import student data file:
mydata <- read.spss("CY6_MS_CMB_STU_QQQ.sav", use.value.labels = TRUE,to.data.frame=TRUE) #replace "mydatafile" with the SPSS file name you wish to import surrounded by quotes
head(mydata[,c(3,227:248)]) #this command will display the first few rows of your data file
nrow(mydata)#counts the number of rows in a data frame/file which can help to confirm all observations imported into R successfully

ColNames = colnames(mydata)
ColNames[3] # "CNTSCHID"

ColNames[227:248]
> ColNames[227:248]
 [1] "ST076Q01NA" "ST076Q02NA" "ST076Q03NA" "ST076Q04NA" "ST076Q05NA"
 [6] "ST076Q06NA" "ST076Q07NA" "ST076Q08NA" "ST076Q09NA" "ST076Q10NA"
[11] "ST076Q11NA" "ST078Q01NA" "ST078Q02NA" "ST078Q03NA" "ST078Q04NA"
[16] "ST078Q05NA" "ST078Q06NA" "ST078Q07NA" "ST078Q08NA" "ST078Q09NA"
[21] "ST078Q10NA" "ST078Q11NA"

# The above variable names pertain to the student questionnaire items below:

ST076
On the most recent day you attended school, did you do any of the following before going to school?
(Please select one response in each row.)  	Yes 	No
Eat breakfast 	 	
Study for school or homework 	 	
Watch TV/DVD/Video 	 	
Read a book/newspaper/magazine 	 	
Internet/Chat/Social networks (e.g., Facebook, Twitter) 	 	
Play video-games 	 	
Meet friends or talk to friends on the phone 	 	
Talk to your parents 	 	
Work in the household or take care of other family members 	 	
Work for pay 	 	
Exercise or practice a sport 	 	

ST078
On the most recent day you attended school, did you do any of the following after leaving school?
(Please select one response in each row.)  	Yes 	No
Eat dinner 	 	
Study for school or homework 	 	
Watch TV/DVD/Video 	 	
Read a book/newspaper/magazine 	 	
Internet/Chat/Social networks (e.g., Facebook, Twitter) 	 	
Play video-games 	 	
Meet friends or talk to friends on the phone 	 	
Talk to your parents 	 	
Work in the household or take care of other family members
Work for pay
Exercise or practice a sport

USA   =  ifelse(mydata[,1]=="United States",1,0); #sum(USA)
USAid = 1:nrow(mydata);  USAid = USAid[USA==1];
mydataSubset = mydata[USAid,227:248];
write.csv(mydataSubset, file = "Imported PISA2015USAprefData.csv")


USA2  =  ifelse(mydata[,3]==84000050,1,0)+ifelse(mydata[,3]==84000193,1,0)+ifelse(mydata[,3]==84000249,1,0)+ifelse(mydata[,3]==84000282,1,0);
ColNames[3] % "CNTSCHID"
# The four US Schools that report no after school activities are: 
# CNTSCHID= 
# 84000050
# 84000193
# 84000249
# 84000282
USA2id = 1:nrow(mydata); 
USA2id[USA2==1]
mydataSubset2 = mydata[USA2id[USA2==1],c(3,227:248)]
write.csv(mydataSubset2, file = "Imported PISA2015USAprefData 4schools.csv")


