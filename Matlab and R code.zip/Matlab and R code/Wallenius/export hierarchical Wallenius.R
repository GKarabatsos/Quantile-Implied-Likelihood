write.csv( E_theta, file = "E_theta_Hierarchical Wallenius.csv")
write.csv(SD_theta, file = "SD_theta_Hierarchical Wallenius.csv")