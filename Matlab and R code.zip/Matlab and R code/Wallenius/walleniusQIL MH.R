# -----------------------------------------------------------------------------------
# Code for vanilla Importance Sampling the posterior distribution of the 
# multivariate Wallenius model using the QIL (Karabatsos Leisen 2018)
# -----------------------------------------------------------------------------------
# Input parameters of mulivariate Wallenius (noncentral hypergeometric) distribution.
# Urn has N = sum(m) balls with C different colors
# Initial number of balls of each color in urn are m = (m_1,...,m_C), and N = sum(m)
# Each individual person selects n out of those N balls, with 0 <= n < N
# Each person has conditional odds of selecting a ball of each color 
# given by theta = (theta_1,...,theta_C)).
# We now refer to theta as the "conditional selection probabilities".
# -----------------------------------------------------------------------------------
install.packages("BiasedUrn")
library(BiasedUrn)
library(MASS)
install.packages("spate")
library(spate)
# -----------------------------------------------------------------------------------------------
# Real PISA 2015 Data on 56 students from 4 US schools that do not report as 
# offering extracurricular activities:
# The 2015 PISA data obtained from: # http://www.oecd.org/pisa/data/2015database/
# The Programme for International Student Assessment (PISA) is a triennial international survey 
# which aims to evaluate education systems worldwide by testing the skills and knowledge of 15-year-old students.
# In 2015 over half a million students, representing 28 million 15-year-olds in 72 countries and economies, 
# took the internationally agreed two-hour test. Students were assessed in science, mathematics, reading, 
# collaborative problem solving and financial literacy.
# The results of the 2015 assessment were published on 6th December 2016.
# For more details about the PIRLS 2015 assessment, see OECD17. 
# -----------------------------------------------------------------------------------------------
rm(list=ls(all=TRUE))
#setwd("C:/Users/Yanni  Leizla/Desktop/George/PAPERS/PAPERS, CURRENT/qil/code/Results/Wallenius") 
#setwd("C:/Users/George/Desktop/qil/Results/Wallenius") 
setwd("C:/Users/George/Desktop/qil 6-18-18/qil/code/Results/Wallenius") 

PISA2015rowID  	 = c(461176,461177,461178,461180,461181,464158,464159,464160,464161,464162,464163,464164,464165,464166,464167,464168,464169,464170,464171,464172,464173,464174,464175,464176,464177,464178,464179,464180,465353,465355,465356,465358,465360,465361,465362,465364,465365,465367,465368,465371,465372,465373,465374,465376,465377,465378,465379,465380,465382,465383,465384,465385,465387,465388,465389,465391);
CNTSCHID        	 = c(84000050,84000050,84000050,84000050,84000050,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249);
Eat                 = c(0,2,2,1,1,2,2,1,0,2,1,1,2,2,1,1,1,2,2,2,2,2,2,1,2,1,2,2,2,2,2,2,1,2,2,1,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2);
StudyRead           = c(4,0,1,2,4,2,3,4,2,3,2,2,4,4,2,4,4,4,2,4,2,0,4,3,3,1,4,4,2,4,3,4,2,2,1,4,4,4,2,2,0,1,3,0,1,2,2,4,3,4,3,4,2,1,1,3);
FriendsPlay         = c(8,5,8,8,4,4,4,6,4,4,4,5,8,1,2,8,7,7,5,6,4,8,7,5,6,5,4,8,6,6,6,6,3,6,6,6,6,4,6,5,5,6,7,4,4,6,7,5,4,6,5,4,6,7,5,6);
TalkParents         = c(2,0,2,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,1,2,2,1,2,2,0,2,0,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2);
WorkInHouseOrForPay = c(2,0,4,2,4,1,2,2,0,1,0,1,0,0,0,4,1,2,3,2,1,4,2,2,4,0,3,4,2,2,1,0,0,4,1,0,2,2,1,3,4,4,2,4,0,0,0,2,0,2,1,0,0,2,1,1);
Exercise            = c(0,2,2,2,2,1,1,2,0,2,0,0,2,1,1,2,1,2,2,2,1,2,1,1,2,1,2,2,0,2,0,2,0,2,0,0,2,2,2,2,0,2,2,2,1,2,2,0,1,2,1,1,1,1,1,1);
X           =  cbind( Eat , StudyRead , FriendsPlay , TalkParents , WorkInHouseOrForPay , Exercise);
colnames(X) <- c(    "Eat","StudyRead","FriendsPlay","TalkParents","WorkInHouseOrForPay","Exercise")
C  = ncol(X); # number of colors
m = c(2,4,8,2,4,2); # Number of balls for each of the 6 colors. sum(m)=22;
n = matrix(rowSums(X),ncol=1);     # n's per person (row)
k = nrow(X); # number of persons/rows in X data. Using Grazian et al.'s (2018) notation.
# -----------------------------------------------------------------------------------------------
# Here are the relvant questionnaire items:
# On the most recent day you attended school, 
# did you do any of the following before going to school?
# (Please select one response in each row.)  	Yes 	No
# PISAvarname col Activity
# ST076Q01NA    1 Eat breakfast 	 	
# ST076Q02NA    2 Study for school or homework 	 	
# ST076Q03NA    3 Watch TV/DVD/Video 	 	
# ST076Q04NA    4 Read a book/newspaper/magazine 	 	
# ST076Q05NA    5 Internet/Chat/Social networks (e.g., Facebook, Twitter) 	 	
# ST076Q06NA    6 Play video-games 	 	
# ST076Q07NA    7 Meet friends or talk to friends on the phone 	 	
# ST076Q08NA    8 Talk to your parents 	 	
# ST076Q09NA    9 Work in the household or take care of other family members 	 	
# ST076Q10NA   10 Work for pay 	 	
# ST076Q11NA   11 Exercise or practice a sport 	 	
# -----------------------------------------------------------------------------------
# On the most recent day you attended school, 
# did you do any of the following after leaving school?
# (Please select one response in each row.)  	Yes 	No
# PISAvarname col Activity
# ST078Q01NA   12 Eat dinner 	 	
# ST078Q02NA   13 Study for school or homework 	 	
# ST078Q03NA   14 Watch TV/DVD/Video 	 	
# ST078Q04NA   15 Read a book/newspaper/magazine 	 	
# ST078Q05NA   16 Internet/Chat/Social networks (e.g., Facebook, Twitter) 	 	
# ST078Q06NA   17 Play video-games 	 	
# ST078Q07NA   18 Meet friends or talk to friends on the phone 	 	
# ST078Q08NA   19 Talk to your parents 	 	
# ST078Q09NA   20 Work in the household or take care of other family members
# ST078Q10NA   21 Work for pay
# ST078Q11NA   22 Exercise or practice a sport
# -----------------------------------------------------------------------------------
# Items Grouped into 6 categories (colors):                                    Color
# -----------------------------------------------------------------------------------
#(1,12) Eat breakfast or dinner                                                    1
# -----------------------------------------------------------------------------------
#(2,13) Study for school or homework, 
#(4,15) Read a book/newspaper/magazine        2
# -----------------------------------------------------------------------------------
#(5,16) Internet/Chat/Social networks (e.g., Facebook, Twitter),                   3
#(7,18) Meet friends or talk to friends on the phone
#(3,14) Watch TV/DVD/Video
#(6,17) Play video-games
# -----------------------------------------------------------------------------------
#(8,19) Talk to your parents                                                       4
# -----------------------------------------------------------------------------------
#(9,20)  Work in the household or take care of other family members                5
#(10,21) Work for pay
# -----------------------------------------------------------------------------------
#(11,22) Exercise or practice a sport                                              6
# -----------------------------------------------------------------------------------

# -----------------------------------------------------------------------------------
# Prior for Wallenius model: theta ~ Dirichlet(alpha).
# -----------------------------------------------------------------------------------
# (the prior constraint sum(theta)=1 helps identify the Wallenius pmf. 
#  see Grazian et al (2018) for a more detailed discussion)
# -----------------------------------------------------------------------------------
alpha = rep(1,C); # Dirichlet(alpha) prior for theta.
# -----------------------------------------------------------------------------------
# Setup of Adaptive Metropolis algorithm:
# ------------------------------------------------------------------------------
S = 10^5;# number of IS iterations.
d = 1;   # number of quantiles from non-iid multivariate data. (each person/group has sample size of 1)
lambda = matrix((1:d)/(d+1),ncol=1);
Qsyn   = lambda;# =unifinv(lambda,0,1).Also,unifpdf(unifinv(lambda,0,1),0,1)=1
Qsyn   = matrix(Qsyn,nrow=k,ncol=1);
Covnum = c(lambda*(1-lambda));
Cov    = Covnum/1; # (each person/group has sample size of n = 1)
Samples_theta     = matrix(NA,nrow=S,ncol=C)
E_theta  = matrix(0,1,C); 
E_theta2 = matrix(0,1,C);
theta1   = rep(1,C)/C;
theta0   = theta1;
# Adaptive Metropolis parameters:
D     = length(theta1)-1;
muhat = matrix(log(theta1[1:(C-1)]/theta1[C]),ncol=1); 
EXXt  = muhat%*%t(muhat);
Vhat  = c();
cMH1  = (2.38^2)/D; cMH2 = sqrt((.1^2)/D); LL0 = -Inf; 
# Set up functions to use in MH loop (set up in iteration 1 of the loop):
meanMWNCHypergeo2 <- function(n){outmean = meanMWNCHypergeo(m, n, theta1)}
varMWNCHypergeo2  <- function(n){outvar  = varMWNCHypergeo (m, n, theta1)}
# ------------------------------------------------------------------------------

# ======================================================================================
# Run the Adaptive Metropolis sampling loop
# ======================================================================================
start_time <- Sys.time()
for (s in 1:S){
# --------------------------------------------------------------------------------------
# Sample from proposal distribution.
# --------------------------------------------------------------------------------------
# Draw log(theta1) form a multivariate normal proposal distribution:
if(s<=(2*D)){                 logtheta1 =   rnorm(C-1,log(theta0[1:(C-1)]/theta0[C]),cMH2);}
propBeta  = runif(1);
if((s>(2*D))&(propBeta<=.05)){logtheta1 =   rnorm(C-1,log(theta0[1:(C-1)]/theta0[C]),cMH2);} 
if((s>(2*D))&(propBeta >.05)){logtheta1 = mvrnorm(1,  log(theta0[1:(C-1)]/theta0[C]),cMH1*Vhat);}
theta1    = c( exp(logtheta1)/(1+sum(exp(logtheta1))), 1 - sum(exp(logtheta1)/(1+sum(exp(logtheta1)))) );
#---------------------------------------------------------------------------------------
# Perform adaptive Metropolis update 
#---------------------------------------------------------------------------------------
# Compute Wallenius means and variances for each person (data row):
MeanWall = t(apply(n,1,meanMWNCHypergeo2));# Wallenius means per person (row) # verified code line works
VarWall  = t(apply(n,1,varMWNCHypergeo2 ))+2.220e-16;# Wallenius variances per person (row)# verified code line works
# Now compute the QIL:
MahTheta = matrix(rowSums(((X-MeanWall)^2)/VarWall),ncol=1)
R        = pchisq(MahTheta,df=C,lower.tail = FALSE)
Q        = R; # because we have non-iid multivariate data
tstat    = (1/Cov)*((Q-Qsyn)^2);
LL1      = sum(dchisq(tstat,df=d,log=TRUE)); #QIL
LL1      = LL1 + sum(log(theta1^(alpha-1))); # add Dirichlet prior contribution
if ((log(runif(1))<(LL1-LL0))|(s==1)){theta0 = theta1; LL0 = LL1;}
Samples_theta[s,]   = matrix(theta0,nrow=1);
# -----------------------------------------------------------------------------------
# Update proposal distribution covariance matrix:
# -----------------------------------------------------------------------------------
logtheta0  = matrix(log( Samples_theta[s,1:(C-1)] / Samples_theta[s,C] ),nrow=1)
muhat      = ( t(logtheta0)              +  (s-1)*muhat)/s;
EXXt       = ((t(logtheta0)%*%logtheta0) + ((s-1)*EXXt))/s;
Vhat       = (EXXt - muhat%*%t(muhat));
# -----------------------------------------------------------------------------------
print(paste("Iteration", s))
flush.console()
# -----------------------------------------------------------------------------------
}
end_time <- Sys.time();
computationTime = end_time - start_time;
# ===================================================================================

# ===================================================================================
# Calculate posterior estimates of model parameters
# ===================================================================================
burnedIn          = 10001:S;
E_theta           = colMeans(Samples_theta[burnedIn,]);
E_theta2          = colMeans(Samples_theta[burnedIn,]^2);
SD_theta          = sqrt(E_theta2 - ((E_theta)^2));
PosteriorResults  =  rbind(E_theta,SD_theta)
colnames(PosteriorResults) <- colnames(X)
rownames(PosteriorResults) <- c("PostE","PostSD")
round(PosteriorResults,3)
computationTime
# ===================================================================================
#> round(PosteriorResults,3)
         Eat StudyRead FriendsPlay TalkParents WorkInHouseOrForPay Exercise
PostE  0.098     0.164       0.124       0.293               0.143    0.176
PostSD 0.003     0.001       0.001       0.009               0.002    0.002
> computationTime
Time difference of 29.29155 mins

par(mfrow=c(2,3))
trace.plot(as.data.frame(t(as.data.frame(Samples_theta))), true = NULL, BurnIn = NULL,BurnInAdaptive=NULL)

# ===================================================================================
# Save the output:
# ===================================================================================
fileName  = paste('Wallenius PISA2015 4schools, A-MH ',Sys.time(),".RData",sep="");
fileName  = gsub(":", "_", fileName);
save.image(file=fileName)
# ===================================================================================