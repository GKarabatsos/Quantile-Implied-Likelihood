# -----------------------------------------------------------------------------------
# Code for vanilla Importance Sampling the posterior distribution of the 
# multivariate Wallenius model using the QIL (Karabatsos Leisen 2018)
# -----------------------------------------------------------------------------------
# Input parameters of mulivariate Wallenius (noncentral hypergeometric) distribution.
# Urn has N = sum(m) balls with C different colors
# Initial number of balls of each color in urn are m = (m_1,...,m_C), and N = sum(m)
# Each individual person selects n out of those N balls, with 0 <= n < N
# Each person has conditional odds of selecting a ball of each color 
# given by theta = (theta_1,...,theta_C)).
# We now refer to theta as the "conditional selection probabilities".
# -----------------------------------------------------------------------------------
install.packages("BiasedUrn")
library(BiasedUrn)
library(MASS)
install.packages("spate")
library(spate)

# -----------------------------------------------------------------------------------------------
# Real PISA 2015 Data on 56 students from 4 US schools that do not report as 
# offering extracurricular activities:
# The 2015 PISA data obtained from: # http://www.oecd.org/pisa/data/2015database/
# The Programme for International Student Assessment (PISA) is a triennial international survey 
# which aims to evaluate education systems worldwide by testing the skills and knowledge of 15-year-old students.
# In 2015 over half a million students, representing 28 million 15-year-olds in 72 countries and economies, 
# took the internationally agreed two-hour test. Students were assessed in science, mathematics, reading, 
# collaborative problem solving and financial literacy.
# The results of the 2015 assessment were published on 6th December 2016.
# For more details about the PIRLS 2015 assessment, see OECD17. 
# -----------------------------------------------------------------------------------------------
rm(list=ls(all=TRUE))
#setwd("C:/Users/Yanni  Leizla/Desktop/George/PAPERS/PAPERS, CURRENT/qil/code/Results/Wallenius") 
setwd("C:/Users/George/Desktop/qil/Results/Wallenius") 
#setwd("C:/Users/George/Desktop/qil 6-18-18/qil/code/Results/Wallenius") 

# -----------------------------------------------------------------------------------
# Simulate the data set
# -----------------------------------------------------------------------------------
thetaTrue = c(.10,.17,.12,.29,.14,.18)
C = 6; # number of colors
m = c(2,4,8,2,4,2); # Number of balls for each of the 6 colors. sum(m)=22;
n = c(16,9,19,17,17,12,13,17,8,14,9,11,18,10,8,21,16,19,16,18,11,18,18,14,19,10,17,22,14,18,14,16,7,18,12,12,18,16,12,16,11,17,18,14,9,14,15,15,12,18,14,13,13,15,12,15);
n = matrix(n,ncol=1); 
k = 56;
rMWNCHypergeo2 <- function(n){RandomSample = rMWNCHypergeo(1,m,n,thetaTrue)}
X              = t(apply(n,1,rMWNCHypergeo2));
colnames(X)    <- c("Eat","StudyRead","FriendsPlay","TalkParents","WorkInHouseOrForPay","Exercise")

# -----------------------------------------------------------------------------------
# Prior for Wallenius model: theta ~ Dirichlet(alpha).
# -----------------------------------------------------------------------------------
# (the prior constraint sum(theta)=1 helps identify the Wallenius pmf. 
#  see Grazian et al (2018) for a more detailed discussion)
# -----------------------------------------------------------------------------------
alpha = rep(1,C); # Dirichlet(alpha) prior for theta.
# -----------------------------------------------------------------------------------
# Setup Adaptive Metropolis algorithm:
# ------------------------------------------------------------------------------
S        = 10^5;# 10^5 number of IS iterations.
d        = 1;   # number of quantiles from non-iid multivariate data. (each person/group has sample size of 1)
lambda   = matrix((1:d)/(d+1),ncol=1);
Qsyn     = lambda;# =unifinv(lambda,0,1).Also,unifpdf(unifinv(lambda,0,1),0,1)=1
Qsyn     = matrix(Qsyn,nrow=k,ncol=1);
Covnum   = c(lambda*(1-lambda));
Cov      = Covnum/1; # (each person/group has sample size of n = 1)
Samples_theta     = matrix(NA,nrow=S,ncol=C)
E_theta  = matrix(0,1,C); 
E_theta2 = matrix(0,1,C);
theta1   = rep(1,C)/C;
theta0   = theta1;
# Adaptive Metropolis parameters:
D        = length(theta1)-1; S2D = S*2*D; 
muhat    = matrix(log(theta1[1:(C-1)]/theta1[C]),ncol=1);
EXXt     = muhat%*%t(muhat);
Vhat     = c();
cMH1  = (2.38^2)/D; cMH2 = sqrt((.1^2)/D); LL0 = -Inf; 
# Set up functions to use in MH loop (set up in iteration 1 of the loop):
meanMWNCHypergeo2 <- function(n){outmean = meanMWNCHypergeo(m, n, theta1)}
varMWNCHypergeo2  <- function(n){outvar  = varMWNCHypergeo (m, n, theta1)}
# ------------------------------------------------------------------------------

# ======================================================================================
# Run the Adaptive Metropolis algorithm loop
# ======================================================================================
start_time <- Sys.time()
for (s in 1:S){
# --------------------------------------------------------------------------------------
# Sample from proposal distribution.
# --------------------------------------------------------------------------------------
# Draw log(theta1) form a multivariate normal proposal distribution:
if(s<=(2*D)){                 logtheta1 =   rnorm(C-1,log(theta0[1:(C-1)]/theta0[C]),cMH2);}
propBeta  = runif(1);
if((s>(2*D))&(propBeta<=.05)){logtheta1 =   rnorm(C-1,log(theta0[1:(C-1)]/theta0[C]),cMH2);} 
if((s>(2*D))&(propBeta >.05)){logtheta1 = mvrnorm(1,  log(theta0[1:(C-1)]/theta0[C]),cMH1*Vhat);}
theta1    = c( exp(logtheta1)/(1+sum(exp(logtheta1))), 1 - sum(exp(logtheta1)/(1+sum(exp(logtheta1)))) );
#---------------------------------------------------------------------------------------
# Perform adaptive Metropolis update 
#---------------------------------------------------------------------------------------
# Compute Wallenius means and variances for each person (data row):
MeanWall = t(apply(n,1,meanMWNCHypergeo2));# Wallenius means per person (row) # verified code line works
VarWall  = t(apply(n,1,varMWNCHypergeo2 ))+2.220e-16;# Wallenius variances per person (row)# verified code line works
# Now compute the QIL:
MahTheta = matrix(rowSums(((X-MeanWall)^2)/VarWall),ncol=1)
R        = pchisq(MahTheta,df=C,lower.tail = FALSE)
Q        = R; # because we have non-iid multivariate data
tstat    = (1/Cov)*((Q-Qsyn)^2);
LL1      = sum(dchisq(tstat,df=d,log=TRUE)); #QIL
LL1      = LL1 + sum(log(theta1^(alpha-1))); # add Dirichlet prior contribution
if ((log(runif(1))<(LL1-LL0))|(s==1)){theta0 = theta1; LL0 = LL1;}
Samples_theta[s,]   = matrix(theta0,nrow=1);
# -----------------------------------------------------------------------------------
# Update proposal distribution covariance matrix:
# -----------------------------------------------------------------------------------
logtheta0  = matrix(log( Samples_theta[s,1:(C-1)] / Samples_theta[s,C] ),nrow=1)
muhat      = ( t(logtheta0)              +  (s-1)*muhat) /s;
EXXt       = ((t(logtheta0)%*%logtheta0) + ((s-1)*EXXt ))/s;
Vhat       = (EXXt - muhat%*%t(muhat));
# -----------------------------------------------------------------------------------
print(paste("Iteration", s))
flush.console()
# -----------------------------------------------------------------------------------
}
end_time <- Sys.time();
computationTime = end_time - start_time;
# ===================================================================================

# ===================================================================================
# Calculate posterior estimates of model parameters
# ===================================================================================
burnedIn          = 10001:S;
E_theta           = colMeans(Samples_theta[burnedIn,]);
E_theta2          = colMeans(Samples_theta[burnedIn,]^2);
SD_theta          = sqrt(E_theta2 - ((E_theta)^2));
RMSE              =  matrix( sqrt(colMeans( (t(matrix(thetaTrue,C,length(burnedIn)))-Samples_theta[burnedIn,])^2) ), nrow=1)
PosteriorResults  =  rbind(E_theta,SD_theta,RMSE)
colnames(PosteriorResults) <- colnames(X)
rownames(PosteriorResults) <- c("PostE","PostSD","RMSE")
round(PosteriorResults,3)
computationTime
# ===================================================================================
#> round(PosteriorResults,3)
#         Eat StudyRead FriendsPlay TalkParents WorkInHouseOrForPay Exercise
#PostE  0.081     0.176       0.206       0.217               0.155    0.165
#PostSD 0.001     0.001       0.002       0.003               0.001    0.000
#RMSE   0.019     0.006       0.086       0.073               0.015    0.015
#> computationTime
#Time difference of 1.086672 hours
par(mfrow=c(2,3))
trace.plot(as.data.frame(t(as.data.frame(Samples_theta))),true=thetaTrue,BurnIn=NULL,BurnInAdaptive=NULL)

# ===================================================================================
# Save the output:
# ===================================================================================
fileName  = paste('Wallenius SimCond PISA2015 4schools, A-MH ',Sys.time(),".RData",sep="");
fileName  = gsub(":", "_", fileName);
save.image(file=fileName)
# ===================================================================================