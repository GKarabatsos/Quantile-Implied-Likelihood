% This code imports, recodes, and exports the PISA 2015 questionnaire item 
% data on activities before or after school, on mot recent school day.
% -------------------------------------------------------------------------
% PISA questionnaire items:
% -------------------------------------------------------------------------
% On the most recent day you attended school, 
% did you do any of the following before going to school?
% (Please select one response in each row.)  	Yes 	No
% PISAvarname  col Activity
% ST076Q01NA 	 1 Eat breakfast 	 	
% ST076Q02NA	 2 Study for school or homework 	 	
% ST076Q03NA	 3 Watch TV/DVD/Video 	 	
% ST076Q04NA	 4 Read a book/newspaper/magazine 	 	
% ST076Q05NA	 5 Internet/Chat/Social networks (e.g., Facebook, Twitter) 	 	
% ST076Q06NA	 6 Play video-games 	 	
% ST076Q07NA	 7 Meet friends or talk to friends on the phone 	 	
% ST076Q08NA	 8 Talk to your parents 	 	
% ST076Q09NA	 9 Work in the household or take care of other family members 	 	
% ST076Q10NA	10 Work for pay 	 	
% ST076Q11NA	11 Exercise or practice a sport 	 	
% -------------------------------------------------------------------------
% On the most recent day you attended school, 
% did you do any of the following after leaving school?
% (Please select one response in each row.)  	Yes 	No
% PISAvarname   col Activity
% ST078Q01NA     12 Eat dinner 	 	
% ST078Q02NA     13 Study for school or homework 	 	
% ST078Q03NA     14 Watch TV/DVD/Video 	 	
% ST078Q04NA     15 Read a book/newspaper/magazine 	 	
% ST078Q05NA     16 Internet/Chat/Social networks (e.g., Facebook, Twitter) 	 	
% ST078Q06NA     17 Play video-games 	 	
% ST078Q07NA     18 Meet friends or talk to friends on the phone 	 	
% ST078Q08NA     19 Talk to your parents 	 	
% ST078Q09NA     20 Work in the household or take care of other family members
% ST078Q10NA     21 Work for pay
% ST078Q11NA     22 Exercise or practice a sport
% -------------------------------------------------------------------------

% -------------------------------------------------------------------------
% Group into categories (colors):
% -------------------------------------------------------------------------
% Have meals:
% (1,12) Eat breakfast or dinner 
%
% Out of school learning:
% (2,13) Study for school or homework, (4,15) Read a book/newspaper/magazine
%
% (5,16) Internet/Chat/Social networks (e.g., Facebook, Twitter),
% (7,18) Meet friends or talk to friends on the phone
% (3,14) Watch TV/DVD/Video
% (6,17) Play video-games
%
% (8,19) Talk to your parents
%
% (9,20) Work in the household or take care of other family members
%(10,21) Work for pay
%
%(11,22) Exercise or practice a sport
% -------------------------------------------------------------------------

% First, Explore school PISA 2015 data set
% to extract the CNTSCHID for the four schools
% that report no after school activities.
clear
[num,txt,raw] = xlsread('Imported PISA2015USAschoolActiv.xlsx');
schoolData = num;  schoolData(schoolData==-99) = NaN; %recode missing responses.
numActivities = sum(schoolData(:,2:12),2);
tabulate(numActivities) % worldwide
% Count of the number of schhools with given number of activities
%  Value    Count   Percent
%      0      184      1.61%
%      1      256      2.24%
%      2      579      5.07%
%      3      811      7.10%
%      4     1145     10.02%
%      5     1376     12.04%
%      6     1553     13.59%
%      7     1543     13.51%
%      8     1311     11.48%
%      9     1172     10.26%
%     10      831      7.27%
%     11      663      5.80%

rowID    = (1:size(schoolData,1))';
USschool = strcmp(txt(2:end,1),'United States');
USschoolData = schoolData(rowID(USschool),2:12);
numActivitiesUS = nansum(USschoolData,2);
tabulate(numActivitiesUS) % US schools only
%  Value    Count   Percent
%      0        4      2.26%
%      1        1      0.56%
%      2        2      1.13%
%      3        4      2.26%
%      4        4      2.26%
%      5       10      5.65%
%      6       10      5.65%
%      7       30     16.95%
%      8       29     16.38%
%      9       38     21.47%
%     10       45     25.42%

% Now, Extract the CNTSCHID for the four schools
% that report no after school activities.
Ind = rowID(USschool&(nansum(schoolData(:,2:12),2)==0));
schoolData(rowID(Ind),1)
%  CNTSCHID for the four schools:
%  84000050
%  84000193
%  84000249
%  84000282




% Explore and construct Student PISA 2015 data on preferences
% for students in the four schools:
% that report no after school activities.
[num,txt,raw] = xlsread('Imported PISA2015USAprefData 4schools.xlsx');
Data0 = num;  Data0(num==-99) = NaN; %recode missing responses.
Data0 = Data0(~any(isnan(Data0),2),:);% retain data for persons with no missing responses
prefData = Data0(:,3:24);
PISA2015rowID = Data0(:,1);
CNTSCHID  = Data0(:,2);
prefData  = [sum(prefData(:,[1,12]),2),...               %1
             sum(prefData(:,[2,13,4,15]),2),...          %2
             sum(prefData(:,[5,16,7,18,3,14,6,17]),2),...%3
             sum(prefData(:,[8,19]),2),...               %4
             sum(prefData(:,[9,20,10,21]),2),...         %5
             sum(prefData(:,[11,22]),2)];                %6
% -------------------------------------------------------------------------
% Group into categories (colors):
% -------------------------------------------------------------------------
% Eat:
% (1,12) Eat breakfast or dinner 
%
% StudyRead:
% (2,13) Study for school or homework, 
% (4,15) Read a book/newspaper/magazine
%
% Play
% (5,16) Internet/Chat/Social networks (e.g., Facebook, Twitter),
% (7,18) Meet friends or talk to friends on the phone
% (3,14) Watch TV/DVD/Video
% (6,17) Play video-games
%
% (8,19) Talk to your parents
%
% (9,20) Work in the household or take care of other family members
%(10,21) Work for pay
%
%(11,22) Exercise or practice a sport
% -------------------------------------------------------------------------


% Number of balls for each of the 6 colors:
m = [2,4,8,2,4,2]; sum(m)=22;
PISA2015rowID  = [461176;461177;461178;461180;461181;464158;464159;464160;464161;464162;464163;464164;464165;464166;464167;464168;464169;464170;464171;464172;464173;464174;464175;464176;464177;464178;464179;464180;465353;465355;465356;465358;465360;465361;465362;465364;465365;465367;465368;465371;465372;465373;465374;465376;465377;465378;465379;465380;465382;465383;465384;465385;465387;465388;465389;465391];
CNTSCHID       = [84000050;84000050;84000050;84000050;84000050;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000193;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249;84000249];
Eat            = [0;2;2;1;1;2;2;1;0;2;1;1;2;2;1;1;1;2;2;2;2;2;2;1;2;1;2;2;2;2;2;2;1;2;2;1;2;2;1;2;2;2;2;2;2;2;2;2;2;2;2;2;2;2;2;2];
StudyRead      = [4;0;1;2;4;2;3;4;2;3;2;2;4;4;2;4;4;4;2;4;2;0;4;3;3;1;4;4;2;4;3;4;2;2;1;4;4;4;2;2;0;1;3;0;1;2;2;4;3;4;3;4;2;1;1;3];
FriendsPlay    = [8;5;8;8;4;4;4;6;4;4;4;5;8;1;2;8;7;7;5;6;4;8;7;5;6;5;4;8;6;6;6;6;3;6;6;6;6;4;6;5;5;6;7;4;4;6;7;5;4;6;5;4;6;7;5;6];
TalkParents    = [2;0;2;2;2;2;1;2;2;2;2;2;2;2;2;2;2;2;2;2;1;2;2;2;2;2;2;2;2;2;2;2;1;2;2;1;2;2;0;2;0;2;2;2;1;2;2;2;2;2;2;2;2;2;2;2];
WorkHouseOrPay = [2;0;4;2;4;1;2;2;0;1;0;1;0;0;0;4;1;2;3;2;1;4;2;2;4;0;3;4;2;2;1;0;0;4;1;0;2;2;1;3;4;4;2;4;0;0;0;2;0;2;1;0;0;2;1;1];
Exercise       = [0;2;2;2;2;1;1;2;0;2;0;0;2;1;1;2;1;2;2;2;1;2;1;1;2;1;2;2;0;2;0;2;0;2;0;0;2;2;2;2;0;2;2;2;1;2;2;0;1;2;1;1;1;1;1;1];

%csvwrite('PISA2015USAprefData 4schools.csv',Data);



