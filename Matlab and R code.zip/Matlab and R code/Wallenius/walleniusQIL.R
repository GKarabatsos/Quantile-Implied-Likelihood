# -----------------------------------------------------------------------------------
# Code for vanilla Importance Sampling the posterior distribution of the 
# multivariate Wallenius model using the QIL (Karabatsos Leisen 2018)
# -----------------------------------------------------------------------------------
# Input parameters of mulivariate Wallenius (noncentral hypergeometric) distribution.
# Urn has N = sum(m) balls with C different colors
# Initial number of balls of each color in urn are m = (m_1,...,m_C), and N = sum(m)
# Each individual person selects n out of those N balls, with 0 <= n < N
# Each person has conditional odds of selecting a ball of each color 
# given by omega = (omega_1,...,omega_C)).
# We now refer to omega as the "conditional selection probabilities".
# -----------------------------------------------------------------------------------
install.packages("BiasedUrn")
library(BiasedUrn)

# -----------------------------------------------------------------------------------------------
# Real PISA 2015 Data on 56 students from 4 US schools that do not report as 
# offering extracurricular activities:
# The 2015 PISA data obtained from: # http://www.oecd.org/pisa/data/2015database/
# The Programme for International Student Assessment (PISA) is a triennial international survey 
# which aims to evaluate education systems worldwide by testing the skills and knowledge of 15-year-old students.
# In 2015 over half a million students, representing 28 million 15-year-olds in 72 countries and economies, 
# took the internationally agreed two-hour test. Students were assessed in science, mathematics, reading, 
# collaborative problem solving and financial literacy.
# The results of the 2015 assessment were published on 6th December 2016.
# For more details about the PIRLS 2015 assessment, see OECD17. 
# -----------------------------------------------------------------------------------------------
rm(list=ls(all=TRUE))
#setwd("C:/Users/Yanni  Leizla/Desktop/George/PAPERS/PAPERS, CURRENT/qil/code/Results/Wallenius") 
#setwd("C:/Users/George/Desktop/qil/Results/Wallenius") 
setwd("C:/Users/George/Desktop/qil 6-18-18/Wallenius") 

PISA2015rowID  	  = c(461176,461177,461178,461180,461181,464158,464159,464160,464161,464162,464163,464164,464165,464166,464167,464168,464169,464170,464171,464172,464173,464174,464175,464176,464177,464178,464179,464180,465353,465355,465356,465358,465360,465361,465362,465364,465365,465367,465368,465371,465372,465373,465374,465376,465377,465378,465379,465380,465382,465383,465384,465385,465387,465388,465389,465391);
CNTSCHID       	  = c(84000050,84000050,84000050,84000050,84000050,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000193,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249,84000249);
Eat                 = c(0,2,2,1,1,2,2,1,0,2,1,1,2,2,1,1,1,2,2,2,2,2,2,1,2,1,2,2,2,2,2,2,1,2,2,1,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2);
StudyRead           = c(4,0,1,2,4,2,3,4,2,3,2,2,4,4,2,4,4,4,2,4,2,0,4,3,3,1,4,4,2,4,3,4,2,2,1,4,4,4,2,2,0,1,3,0,1,2,2,4,3,4,3,4,2,1,1,3);
FriendsPlay         = c(8,5,8,8,4,4,4,6,4,4,4,5,8,1,2,8,7,7,5,6,4,8,7,5,6,5,4,8,6,6,6,6,3,6,6,6,6,4,6,5,5,6,7,4,4,6,7,5,4,6,5,4,6,7,5,6);
TalkParents         = c(2,0,2,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,1,2,2,1,2,2,0,2,0,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2);
WorkInHouseOrForPay = c(2,0,4,2,4,1,2,2,0,1,0,1,0,0,0,4,1,2,3,2,1,4,2,2,4,0,3,4,2,2,1,0,0,4,1,0,2,2,1,3,4,4,2,4,0,0,0,2,0,2,1,0,0,2,1,1);
Exercise            = c(0,2,2,2,2,1,1,2,0,2,0,0,2,1,1,2,1,2,2,2,1,2,1,1,2,1,2,2,0,2,0,2,0,2,0,0,2,2,2,2,0,2,2,2,1,2,2,0,1,2,1,1,1,1,1,1);
X = cbind(Eat,StudyRead,FriendsPlay,TalkParents,WorkInHouseOrForPay,Exercise);
colnames(X) <- c("Eat","StudyRead","FriendsPlay","TalkParents","WorkInHouseOrForPay","Exercise")
C  = ncol(X); # number of colors
m = c(2,4,8,2,4,2); # Number of balls for each of the 6 colors. sum(m)=22;
n = matrix(rowSums(X),ncol=1);     # n's per person (row)
k = nrow(X); # number of persons/rows in X data. Using Grazian et al.'s (2018) notation.
# -----------------------------------------------------------------------------------------------
# Here are the relvant questionnaire items:
# On the most recent day you attended school, 
# did you do any of the following before going to school?
# (Please select one response in each row.)  	Yes 	No
# PISAvarname col Activity
# ST076Q01NA    1 Eat breakfast 	 	
# ST076Q02NA    2 Study for school or homework 	 	
# ST076Q03NA    3 Watch TV/DVD/Video 	 	
# ST076Q04NA    4 Read a book/newspaper/magazine 	 	
# ST076Q05NA    5 Internet/Chat/Social networks (e.g., Facebook, Twitter) 	 	
# ST076Q06NA    6 Play video-games 	 	
# ST076Q07NA    7 Meet friends or talk to friends on the phone 	 	
# ST076Q08NA    8 Talk to your parents 	 	
# ST076Q09NA    9 Work in the household or take care of other family members 	 	
# ST076Q10NA   10 Work for pay 	 	
# ST076Q11NA   11 Exercise or practice a sport 	 	
# -----------------------------------------------------------------------------------
# On the most recent day you attended school, 
# did you do any of the following after leaving school?
# (Please select one response in each row.)  	Yes 	No
# PISAvarname col Activity
# ST078Q01NA   12 Eat dinner 	 	
# ST078Q02NA   13 Study for school or homework 	 	
# ST078Q03NA   14 Watch TV/DVD/Video 	 	
# ST078Q04NA   15 Read a book/newspaper/magazine 	 	
# ST078Q05NA   16 Internet/Chat/Social networks (e.g., Facebook, Twitter) 	 	
# ST078Q06NA   17 Play video-games 	 	
# ST078Q07NA   18 Meet friends or talk to friends on the phone 	 	
# ST078Q08NA   19 Talk to your parents 	 	
# ST078Q09NA   20 Work in the household or take care of other family members
# ST078Q10NA   21 Work for pay
# ST078Q11NA   22 Exercise or practice a sport
# -----------------------------------------------------------------------------------
# Items Grouped into 6 categories (colors):                                    Color
# -----------------------------------------------------------------------------------
#(1,12) Eat breakfast or dinner                                                    1
# -----------------------------------------------------------------------------------
#(2,13) Study for school or homework, 
#(4,15) Read a book/newspaper/magazine        2
# -----------------------------------------------------------------------------------
#(5,16) Internet/Chat/Social networks (e.g., Facebook, Twitter),                   3
#(7,18) Meet friends or talk to friends on the phone
#(3,14) Watch TV/DVD/Video
#(6,17) Play video-games
# -----------------------------------------------------------------------------------
#(8,19) Talk to your parents                                                       4
# -----------------------------------------------------------------------------------
#(9,20)  Work in the household or take care of other family members                5
#(10,21) Work for pay
# -----------------------------------------------------------------------------------
#(11,22) Exercise or practice a sport                                              6
# -----------------------------------------------------------------------------------

# -----------------------------------------------------------------------------------
# Prior for Wallenius model: omega ~ Dirichlet(alpha).
# -----------------------------------------------------------------------------------
# (the prior constraint sum(omega)=1 helps identify the Wallenius pmf. 
#  see Grazian et al (2018) for a more detailed discussion)
# -----------------------------------------------------------------------------------
alpha = rep(1,C); # Dirichlet(alpha) prior for omega.
# -----------------------------------------------------------------------------------
# Setup of Importance Sampling (IS) algorithm:
# ------------------------------------------------------------------------------
S = 10^5; # number of IS iterations.
d = 1;   # number of quantiles from non-iid multivariate data. (each person/group has sample size of 1)
lambda = matrix((1:d)/(d+1),ncol=1);
Qsyn   = lambda;# =unifinv(lambda,0,1).Also,unifpdf(unifinv(lambda,0,1),0,1)=1
Qsyn   = matrix(Qsyn,nrow=k,ncol=1);
Covnum = c(lambda*(1-lambda));
Cov    = Covnum/1; # (each person/group has sample size of n = 1)
Samples_ISweights = matrix(NA,S,1);
omegaSamples      = matrix(NA,nrow=S,ncol=C)
E_omega  = matrix(0,1,C); 
E_omega2 = matrix(0,1,C);
# Set up functions to use in IS loop (set up in iteration 1 of the loop):
meanMWNCHypergeo2 <- function(n){outmean = meanMWNCHypergeo(m, n, omega)}
varMWNCHypergeo2  <- function(n){outvar  = varMWNCHypergeo (m, n, omega)}
# ------------------------------------------------------------------------------

# ==============================================================================
# Run the Importance sampling (IS) loop
# ==============================================================================
start_time <- Sys.time()
for (s in 1:S){
# -----------------------------------------------------------------------------------
# Generate Prior sample of omega ~ Dirichlet(alpha).
# -----------------------------------------------------------------------------------
omega = rgamma(C, alpha, rate = 1);
omega = omega/sum(omega); # Dirichlet prior sample.
# -----------------------------------------------------------------------------------

# -----------------------------------------------------------------------------------
# Compute QIL (IS weight) of omega prior sample 
# -----------------------------------------------------------------------------------
# Compute Wallenius means and variances for each person (data row):
MeanWall = t(apply(n,1,meanMWNCHypergeo2));# Wallenius means per person (row) # verified code line works
VarWall  = t(apply(n,1,varMWNCHypergeo2 ))+2.220e-16;# Wallenius variances per person (row)# verified code line works
# Now compute the QIL:
MahTheta = matrix(rowSums((X-MeanWall)^2/VarWall),ncol=1)
R        = pchisq(MahTheta,df=C,lower.tail = FALSE)
Q        = R; # because we have non-iid multivariate data
tstat    = (1/Cov)*((Q-Qsyn)^2);
Like     = prod(dchisq(tstat, df=d)*k); #QIL
Samples_ISweights[s] = Like;
omegaSamples[s,]   = matrix(omega,nrow=1);
# -----------------------------------------------------------------------------------
print(paste("Iteration", s))
flush.console()
# -----------------------------------------------------------------------------------
}
end_time <- Sys.time();
computationTime = end_time - start_time;
# ===================================================================================

# ===================================================================================
# Calculate posterior estimates of model parameters
# ===================================================================================
Samples_ISweights = Samples_ISweights/sum(Samples_ISweights);
ESS  = 1./sum(Samples_ISweights^2);
E_omega  = colSums(Samples_ISweights[,rep(1,C)]*(omegaSamples));
E_omega2 = colSums(Samples_ISweights[,rep(1,C)]*(omegaSamples^2));
V_omega  = E_omega2 - ((E_omega)^2);
PosteriorResults <- rbind(E_omega,V_omega,sqrt(V_omega))
colnames(PosteriorResults) <- colnames(X)
rownames(PosteriorResults) <- c("PostE","PostVar","PostSD")
round(PosteriorResults,3)
computationTime
# ===================================================================================
#> round(PosteriorResults,3)
#          Eat StudyRead FriendsPlay TalkParents WorkInHouseOrForPay Exercise
#PostE   0.161     0.115       0.166       0.308               0.099    0.150
#PostVar 0.000     0.000       0.001       0.004               0.000    0.002
#PostSD  0.016     0.016       0.035       0.062               0.011    0.049
#> computationTime
#Time difference of 24.47536 mins
#> ESS   2.253708



# ===================================================================================
# Save the output:
# ===================================================================================
fileName  = paste('Wallenius PISA2015 4schools ',Sys.time(),".RData",sep="");
fileName  = gsub(":", "_", fileName);
save.image(file=fileName)
# ===================================================================================