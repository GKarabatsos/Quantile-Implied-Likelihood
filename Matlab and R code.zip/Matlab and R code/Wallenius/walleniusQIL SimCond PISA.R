# Simulation condition similar to PISA data design
# All parameters omega1,...,omega_6, set to posterior mean estimates
# obtained from the PISA data analysis.
# the same values of m, n, and number of subjects (56) as in the PISA data.

#install.packages("BiasedUrn")
library(BiasedUrn)
#setwd("C:/Users/George/Desktop/qil/Results/Wallenius") 
setwd("C:/Users/George/Desktop/qil 6-18-18/Wallenius") 
 
rm(list=ls(all=TRUE))
# -----------------------------------------------------------------------------------
# Simulate the data set
# -----------------------------------------------------------------------------------
omegaTrue = c(0.161,0.115,0.166,0.308,0.099,0.150);
C = 6; # number of colors
m = c(2,4,8,2,4,2); # Number of balls for each of the 6 colors. sum(m)=22;
n = c(16,9,19,17,17,12,13,17,8,14,9,11,18,10,8,21,16,19,16,18,11,18,18,14,19,10,17,22,14,18,14,16,7,18,12,12,18,16,12,16,11,17,18,14,9,14,15,15,12,18,14,13,13,15,12,15);
n = matrix(n,ncol=1); 
k = 56;
rMWNCHypergeo2 <- function(n){RandomSample = rMWNCHypergeo(1,m,n,omegaTrue)}
X = t(apply(n,1,rMWNCHypergeo2));
colnames(X) <- c("Eat","StudyRead","FriendsPlay","TalkParents","WorkInHouseOrForPay","Exercise")

# -----------------------------------------------------------------------------------
# Prior for Wallenius model: omega ~ Dirichlet(alpha).
# -----------------------------------------------------------------------------------
# (the prior constraint sum(omega)=1 helps identify the Wallenius pmf. 
#  see Grazian et al (2018) for a more detailed discussion)
# -----------------------------------------------------------------------------------
alpha = rep(1,C); # Dirichlet(alpha) prior for omega.
# -----------------------------------------------------------------------------------
# Setup of Importance Sampling (IS) algorithm:
# ------------------------------------------------------------------------------
S = 10^5; # number of IS iterations.
d = 1;   # number of quantiles from non-iid multivariate data. (each person/group has sample size of 1)
lambda = matrix((1:d)/(d+1),ncol=1);
Qsyn   = lambda;# =unifinv(lambda,0,1).Also,unifpdf(unifinv(lambda,0,1),0,1)=1
Qsyn   = matrix(Qsyn,nrow=k,ncol=1);
Covnum = c(lambda*(1-lambda));
Cov    = Covnum/1; # (each person/group has sample size of n = 1)
Samples_ISweights = matrix(NA,S,1);
omegaSamples      = matrix(NA,nrow=S,ncol=C)
E_omega  = matrix(0,1,C); 
E_omega2 = matrix(0,1,C);
# Set up functions to use in IS loop (set up in iteration 1 of the loop):
meanMWNCHypergeo2 <- function(n){outmean = meanMWNCHypergeo(m, n, omega)}
varMWNCHypergeo2  <- function(n){outvar  = varMWNCHypergeo (m, n, omega)}
# ------------------------------------------------------------------------------

# ==============================================================================
# Run the Importance sampling (IS) loop
# ==============================================================================
start_time <- Sys.time()
for (s in 1:S){
# -----------------------------------------------------------------------------------
# Generate Prior sample of omega ~ Dirichlet(alpha).
# -----------------------------------------------------------------------------------
omega = rgamma(C, alpha, rate = 1);
omega = omega/sum(omega); # Dirichlet prior sample.
# -----------------------------------------------------------------------------------
# Compute QIL (IS weight) of omega prior sample 
# -----------------------------------------------------------------------------------
# Compute Wallenius means and variances for each person (data row):
MeanWall = t(apply(n,1,meanMWNCHypergeo2));# Wallenius means per person (row) # verified code line works
VarWall  = t(apply(n,1,varMWNCHypergeo2 ))+2.220e-16;# Wallenius variances per person (row)# verified code line works
# Now compute the QIL:
MahTheta = matrix(rowSums((X-MeanWall)^2/VarWall),ncol=1)
R        = pchisq(MahTheta,df=C,lower.tail = FALSE)
Q        = R; # because we have non-iid multivariate data
tstat    = (1/Cov)*((Q-Qsyn)^2);
Like     = prod(dchisq(tstat, df=d)*k); #QIL
Samples_ISweights[s] = Like;
omegaSamples[s,]   = matrix(omega,nrow=1);
# -----------------------------------------------------------------------------------
print(paste("Iteration", s))
flush.console()
# -----------------------------------------------------------------------------------
}
end_time <- Sys.time();
computationTime = end_time - start_time;
# ===================================================================================

# ===================================================================================
# Calculate posterior estimates of model parameters
# ===================================================================================
Samples_ISweights = Samples_ISweights/sum(Samples_ISweights);
ESS  = 1./sum(Samples_ISweights^2);
E_omega  = colSums(Samples_ISweights[,rep(1,C)]*(omegaSamples));
E_omega2 = colSums(Samples_ISweights[,rep(1,C)]*(omegaSamples^2));
V_omega  = E_omega2 - ((E_omega)^2);
PosteriorResults <- rbind(E_omega,V_omega)
colnames(PosteriorResults) <- colnames(X)
rownames(PosteriorResults) <- c("PostE","PostVar")
round(PosteriorResults,3)
computationTime
# ===================================================================================
#> round(PosteriorResults,3)
#          Eat StudyRead FriendsPlay TalkParents WorkInHouseOrForPay Exercise
#PostE   0.127     0.171       0.207       0.244               0.107    0.144
#PostVar 0.001     0.001       0.000       0.002               0.001    0.001
#omegaTrue = c(0.161,0.115,0.166,0.308,0.099,0.150);
#> computationTime
#Time difference of 24.38309 mins 100K (10^5) Importance sampling iterations
#> ESS [1]  4.794364


# Calculate Root mean square error of posterior samples from omegaTrue values.
RMSE = sqrt(colSums(Samples_ISweights[,rep(1,C)]*((t(matrix(omegaTrue,C,S))-omegaSamples)^2)))
RMSE = matrix(RMSE,nrow=1)
colnames(RMSE) <- c("Eat","StudyRead","FriendsPlay","TalkParents","WorkInHouseOrForPay","Exercise")
#RMSE
#            Eat  StudyRead FriendsPlay TalkParents WorkInHouseOrForPay   Exercise
#[1,] 0.04859915 0.06274154  0.04497436    0.079013          0.02493247 0.03807844
# round(RMSE,3)
#       Eat StudyRead FriendsPlay TalkParents WorkInHouseOrForPay Exercise
#[1,] 0.049     0.063       0.045       0.079               0.025    0.038


# ===================================================================================
# Save the output:
# ===================================================================================
fileName  = paste('SimCond 4 ',Sys.time(),".RData",sep="");
fileName  = gsub(":", "_", fileName);
save.image(file=fileName)
# ===================================================================================