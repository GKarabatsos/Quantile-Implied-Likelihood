function bestResults = ghgkQfit(model,Q,lambda,y,n)
warning ('off','all');
%
for start=1:232
 if start==1
   medy = median(y);  iqry2 = iqr(y)/2;
   Est = NaN(232,4); SEs = NaN(232,4); negLLs = NaN(232,1);
 end % or model = 'g and h';
 if start==1  % Hoaglin starting value for g and h model (nongeneralized):
   Astart    = median(y);
   p_i       = [.005,.01,.025,.05,.10,.25];
   zpi       = norminv(p_i);
   zpisqdiv2 = (zpi.^2)./2;
   Qpi       = quantile(y,p_i);
   Q1minuspi = quantile(y,1-p_i);
   gstart    = median((-1./zpi).*log((Q1minuspi-Astart)./(Astart-Qpi)))+eps;
   if gstart>0; logg = log((gstart*(Q1minuspi-Astart))./exp(-gstart*zpi)); end
   if gstart<0; logg = log((gstart*(Astart-Qpi))./(1-exp(gstart*zpi)));    end
   logB_k    = glmfit(zpisqdiv2,logg,'normal');
   hkstart   = abs(logB_k(2));
   Bstart    = exp(logB_k(1));
   % [Astart, Bstart, gstart, hkstart]
 end
 if start== 2; Astart = medy; Bstart = iqry2; gstart =   1; hkstart =   1; end%starting value #1 RM(2002,p.61)
 if start== 3; Astart = medy; Bstart = iqry2; gstart = eps; hkstart = eps; end%starting value #2 RM(2002,p.61)
 if start== 4; Astart = medy; Bstart = iqry2; gstart =   1; hkstart = eps; end
 if start== 5; Astart = medy; Bstart = iqry2; gstart = eps; hkstart =   1; end
 if start== 6; Astart = medy; Bstart = iqry2; gstart =  -1; hkstart = eps; end
 if start== 7; Astart = medy; Bstart = iqry2; gstart =  -1; hkstart =   1; end
 if start== 8; Astart =    1; Bstart =     1; gstart =   1; hkstart =   1; end%starting value #3 RM(2002,p.61)
 if start== 9; Astart =    1; Bstart =     1; gstart = eps; hkstart = eps; end
 if start==10; Astart =    1; Bstart =     1; gstart =   1; hkstart = eps; end
 if start==11; Astart =    1; Bstart =     1; gstart = eps; hkstart =   1; end
 if start==12; Astart =    1; Bstart =     1; gstart =  -1; hkstart = eps; end
 if start==13; Astart =    1; Bstart =     1; gstart =  -1; hkstart =   1; end
 if start==14; Astart =    0; Bstart =     1; gstart = eps; hkstart = eps; end%starting value #4 RM(2002,p.61)
 if start==15; Astart =    0; Bstart =     1; gstart = eps; hkstart = eps; end
 if start==16; Astart =    0; Bstart =     1; gstart =   1; hkstart = eps; end
 if start==17; Astart =    0; Bstart =     1; gstart = eps; hkstart =   1; end
 if start==18; Astart =    0; Bstart =     1; gstart =  -1; hkstart = eps; end
 if start==19; Astart =    0; Bstart =     1; gstart =  -1; hkstart =   1; end 
 if start==20; Astart = medy; Bstart =     1; gstart =   1; hkstart =   1; end
 if start==21; Astart = medy; Bstart =     1; gstart = eps; hkstart = eps; end
 if start==22; Astart = medy; Bstart =     1; gstart =   1; hkstart = eps; end
 if start==23; Astart = medy; Bstart =     1; gstart = eps; hkstart =   1; end
 if start==24; Astart = medy; Bstart =     1; gstart =  -1; hkstart = eps; end
 if start==25; Astart = medy; Bstart =     1; gstart =  -1; hkstart =   1; end 
 if start==26; Astart =   -1; Bstart =     1; gstart =   1; hkstart =   1; end
 if start==27; Astart =   -1; Bstart =     1; gstart = eps; hkstart = eps; end
 if start==28; Astart =   -1; Bstart =     1; gstart =   1; hkstart = eps; end
 if start==29; Astart =   -1; Bstart =     1; gstart = eps; hkstart =   1; end
 if start==30; Astart =   -1; Bstart =     1; gstart =  -1; hkstart = eps; end
 if start==31; Astart =   -1; Bstart =     1; gstart =  -1; hkstart =   1; end 
 if start==32; Astart =    1; Bstart = iqry2; gstart =   1; hkstart =   1; end
 if start==33; Astart =    1; Bstart = iqry2; gstart = eps; hkstart = eps; end
 if start==34; Astart =    1; Bstart = iqry2; gstart =   1; hkstart = eps; end
 if start==35; Astart =    1; Bstart = iqry2; gstart = eps; hkstart =   1; end
 if start==36; Astart =    1; Bstart = iqry2; gstart =  -1; hkstart = eps; end
 if start==37; Astart =    1; Bstart = iqry2; gstart =  -1; hkstart =   1; end 
 if start==38; Astart =    0; Bstart = iqry2; gstart =   1; hkstart =   1; end
 if start==39; Astart =    0; Bstart = iqry2; gstart = eps; hkstart = eps; end
 if start==40; Astart =    0; Bstart = iqry2; gstart =   1; hkstart = eps; end
 if start==41; Astart =    0; Bstart = iqry2; gstart = eps; hkstart =   1; end
 if start==42; Astart =    0; Bstart = iqry2; gstart =  -1; hkstart = eps; end
 if start==43; Astart =    0; Bstart = iqry2; gstart =  -1; hkstart =   1; end
 if start==44; Astart =   -1; Bstart = iqry2; gstart =   1; hkstart =   1; end
 if start==45; Astart =   -1; Bstart = iqry2; gstart = eps; hkstart = eps; end
 if start==46; Astart =   -1; Bstart = iqry2; gstart =   1; hkstart = eps; end
 if start==47; Astart =   -1; Bstart = iqry2; gstart = eps; hkstart =   1; end
 if start==48; Astart =   -1; Bstart = iqry2; gstart =  -1; hkstart = eps; end
 if start==49; Astart =   -1; Bstart = iqry2; gstart =  -1; hkstart =   1; end 
 if start==50; Astart = medy; Bstart = iqry2; gstart =   1; hkstart =   1; end
 if start==51; Astart = medy; Bstart = iqry2; gstart = eps; hkstart = eps; end
 if start==52; Astart = medy; Bstart = iqry2; gstart =   1; hkstart = eps; end
 if start==53; Astart = medy; Bstart = iqry2; gstart = eps; hkstart =   1; end
 if start==54; Astart = medy; Bstart = iqry2; gstart =  -1; hkstart = eps; end
 if start==55; Astart = medy; Bstart = iqry2; gstart =  -1; hkstart =   1; end
 if start==56; Astart =    1; Bstart =     1; gstart =   1; hkstart =   1; end
 if start==57; Astart =    1; Bstart =     1; gstart = eps; hkstart = eps; end
 if start==58; Astart =    1; Bstart =     1; gstart =   1; hkstart = eps; end
 if start==59; Astart =    1; Bstart =     1; gstart = eps; hkstart =   1; end
 if start==60; Astart =    1; Bstart =     1; gstart =  -1; hkstart = eps; end
 if start==61; Astart =    1; Bstart =     1; gstart =  -1; hkstart =   1; end
 if start==62; Astart =    0; Bstart =     1; gstart = eps; hkstart = eps; end
 if start==63; Astart =    0; Bstart =     1; gstart = eps; hkstart = eps; end
 if start==64; Astart =    0; Bstart =     1; gstart =   1; hkstart = eps; end
 if start==65; Astart =    0; Bstart =     1; gstart = eps; hkstart =   1; end
 if start==66; Astart =    0; Bstart =     1; gstart =  -1; hkstart = eps; end
 if start==67; Astart =    0; Bstart =     1; gstart =  -1; hkstart =   1; end 
 if start==68; Astart = medy; Bstart =     1; gstart =   1; hkstart =   1; end
 if start==69; Astart = medy; Bstart =     1; gstart = eps; hkstart = eps; end
 if start==70; Astart = medy; Bstart =     1; gstart =   1; hkstart = eps; end
 if start==71; Astart = medy; Bstart =     1; gstart = eps; hkstart =   1; end
 if start==72; Astart = medy; Bstart =     1; gstart =  -1; hkstart = eps; end
 if start==73; Astart = medy; Bstart =     1; gstart =  -1; hkstart =   1; end 
 if start==74; Astart =   -1; Bstart =     1; gstart =   1; hkstart =   1; end
 if start==75; Astart =   -1; Bstart =     1; gstart = eps; hkstart = eps; end
 if start==76; Astart =   -1; Bstart =     1; gstart =   1; hkstart = eps; end
 if start==77; Astart =   -1; Bstart =     1; gstart = eps; hkstart =   1; end
 if start==78; Astart =   -1; Bstart =     1; gstart =  -1; hkstart = eps; end
 if start==79; Astart =   -1; Bstart =     1; gstart =  -1; hkstart =   1; end 
 if start==80; Astart =    1; Bstart = iqry2; gstart =   1; hkstart =   1; end
 if start==81; Astart =    1; Bstart = iqry2; gstart = eps; hkstart = eps; end
 if start==82; Astart =    1; Bstart = iqry2; gstart =   1; hkstart = eps; end
 if start==83; Astart =    1; Bstart = iqry2; gstart = eps; hkstart =   1; end
 if start==84; Astart =    1; Bstart = iqry2; gstart =  -1; hkstart = eps; end
 if start==85; Astart =    1; Bstart = iqry2; gstart =  -1; hkstart =   1; end 
 if start==86; Astart =    0; Bstart = iqry2; gstart =   1; hkstart =   1; end
 if start==87; Astart =    0; Bstart = iqry2; gstart = eps; hkstart = eps; end
 if start==88; Astart =    0; Bstart = iqry2; gstart =   1; hkstart = eps; end
 if start==89; Astart =    0; Bstart = iqry2; gstart = eps; hkstart =   1; end
 if start==90; Astart =    0; Bstart = iqry2; gstart =  -1; hkstart = eps; end
 if start==91; Astart =    0; Bstart = iqry2; gstart =  -1; hkstart =   1; end
 if start==92; Astart =   -1; Bstart = iqry2; gstart =   1; hkstart =   1; end
 if start==93; Astart =   -1; Bstart = iqry2; gstart = eps; hkstart = eps; end
 if start==94; Astart =   -1; Bstart = iqry2; gstart =   1; hkstart = eps; end
 if start==95; Astart =   -1; Bstart = iqry2; gstart = eps; hkstart =   1; end
 if start==96; Astart =   -1; Bstart = iqry2; gstart =  -1; hkstart = eps; end
 if start==97; Astart =   -1; Bstart = iqry2; gstart =  -1; hkstart =   1; end 
 if start==98; Astart = medy; Bstart = iqry2; gstart =   10; hkstart =   1; end
 if start==99; Astart = medy; Bstart = iqry2; gstart =   10; hkstart = eps; end
 if start==100; Astart = medy; Bstart = iqry2; gstart =  -10; hkstart = eps; end
 if start==101; Astart = medy; Bstart = iqry2; gstart =  -10; hkstart =   1; end
 if start==102; Astart =    1; Bstart =     1; gstart =   10; hkstart =   1; end
 if start==103; Astart =    1; Bstart =     1; gstart =   10; hkstart = eps; end
 if start==104; Astart =    1; Bstart =     1; gstart =  -10; hkstart = eps; end
 if start==105; Astart =    1; Bstart =     1; gstart =  -10; hkstart =   1; end
 if start==106; Astart =    0; Bstart =     1; gstart =   10; hkstart = eps; end
 if start==107; Astart =    0; Bstart =     1; gstart =  -10; hkstart = eps; end
 if start==108; Astart =    0; Bstart =     1; gstart =  -10; hkstart =   1; end 
 if start==109; Astart = medy; Bstart =     1; gstart =   10; hkstart =   1; end
 if start==110; Astart = medy; Bstart =     1; gstart =   10; hkstart = eps; end
 if start==111; Astart = medy; Bstart =     1; gstart =  -10; hkstart = eps; end
 if start==112; Astart = medy; Bstart =     1; gstart =  -10; hkstart =   1; end 
 if start==113; Astart =   -1; Bstart =     1; gstart =   10; hkstart =   1; end
 if start==114; Astart =   -1; Bstart =     1; gstart =   10; hkstart = eps; end
 if start==115; Astart =   -1; Bstart =     1; gstart =  -10; hkstart = eps; end
 if start==116; Astart =   -1; Bstart =     1; gstart =  -10; hkstart =   1; end 
 if start==117; Astart =    1; Bstart = iqry2; gstart =   10; hkstart =   1; end
 if start==118; Astart =    1; Bstart = iqry2; gstart =   10; hkstart = eps; end
 if start==119; Astart =    1; Bstart = iqry2; gstart =  -10; hkstart = eps; end
 if start==120; Astart =    1; Bstart = iqry2; gstart =  -10; hkstart =   1; end 
 if start==121; Astart =    0; Bstart = iqry2; gstart =   10; hkstart =   1; end
 if start==122; Astart =    0; Bstart = iqry2; gstart =   10; hkstart = eps; end
 if start==123; Astart =    0; Bstart = iqry2; gstart =  -10; hkstart = eps; end
 if start==124; Astart =    0; Bstart = iqry2; gstart =  -10; hkstart =   1; end
 if start==125; Astart =   -1; Bstart = iqry2; gstart =   10; hkstart =   1; end
 if start==126; Astart =   -1; Bstart = iqry2; gstart =   10; hkstart = eps; end
 if start==127; Astart =   -1; Bstart = iqry2; gstart =  -10; hkstart = eps; end
 if start==128; Astart =   -1; Bstart = iqry2; gstart =  -10; hkstart =   1; end 
 if start==129; Astart = medy; Bstart = iqry2; gstart =   1; hkstart =  10; end
 if start==130; Astart = medy; Bstart = iqry2; gstart = eps; hkstart =  10; end
 if start==131; Astart = medy; Bstart = iqry2; gstart =  -1; hkstart =  10; end
 if start==132; Astart =    1; Bstart =     1; gstart =   1; hkstart =  10; end
 if start==133; Astart =    1; Bstart =     1; gstart = eps; hkstart =  10; end
 if start==134; Astart =    1; Bstart =     1; gstart =  -1; hkstart =  10; end
 if start==135; Astart =    0; Bstart =     1; gstart = eps; hkstart =  10; end
 if start==136; Astart =    0; Bstart =     1; gstart =  -1; hkstart =  10; end 
 if start==137; Astart = medy; Bstart =     1; gstart =   1; hkstart =  10; end
 if start==138; Astart = medy; Bstart =     1; gstart = eps; hkstart =  10; end
 if start==139; Astart = medy; Bstart =     1; gstart =  -1; hkstart =  10; end 
 if start==140; Astart =   -1; Bstart =     1; gstart =   1; hkstart =  10; end
 if start==141; Astart =   -1; Bstart =     1; gstart = eps; hkstart =  10; end
 if start==142; Astart =   -1; Bstart =     1; gstart =  -1; hkstart =  10; end 
 if start==143; Astart =    1; Bstart = iqry2; gstart =   1; hkstart =  10; end
 if start==144; Astart =    1; Bstart = iqry2; gstart = eps; hkstart =  10; end
 if start==145; Astart =    1; Bstart = iqry2; gstart =  -1; hkstart =  10; end 
 if start==146; Astart =    0; Bstart = iqry2; gstart =   1; hkstart =  10; end
 if start==147; Astart =    0; Bstart = iqry2; gstart = eps; hkstart =  10; end
 if start==148; Astart =    0; Bstart = iqry2; gstart =  -1; hkstart =  10; end
 if start==149; Astart =   -1; Bstart = iqry2; gstart =   1; hkstart =  10; end
 if start==150; Astart =   -1; Bstart = iqry2; gstart = eps; hkstart =  10; end
 if start==151; Astart =   -1; Bstart = iqry2; gstart =  -1; hkstart =  10; end 
 if start==152; Astart = medy; Bstart = iqry2; gstart =   10; hkstart =  10; end
 if start==153; Astart = medy; Bstart = iqry2; gstart =  -10; hkstart =  10; end
 if start==154; Astart =    1; Bstart =     1; gstart =   10; hkstart =  10; end
 if start==155; Astart =    1; Bstart =     1; gstart =  -10; hkstart =  10; end
 if start==156; Astart =    0; Bstart =     1; gstart =  -10; hkstart =  10; end 
 if start==157; Astart = medy; Bstart =     1; gstart =   10; hkstart =  10; end
 if start==158; Astart = medy; Bstart =     1; gstart =  -10; hkstart =  10; end 
 if start==159; Astart =   -1; Bstart =     1; gstart =   10; hkstart =  10; end
 if start==160; Astart =   -1; Bstart =     1; gstart =  -10; hkstart =  10; end 
 if start==161; Astart =    1; Bstart = iqry2; gstart =   10; hkstart =  10; end
 if start==162; Astart =    1; Bstart = iqry2; gstart =  -10; hkstart =  10; end 
 if start==163; Astart =    0; Bstart = iqry2; gstart =   10; hkstart =  10; end
 if start==164; Astart =    0; Bstart = iqry2; gstart =  -10; hkstart =  10; end
 if start==165; Astart =   -1; Bstart = iqry2; gstart =   10; hkstart =  10; end
 if start==166; Astart =   -1; Bstart = iqry2; gstart =  -10; hkstart =  10; end  
 if start==167; Astart =    1; Bstart =     10; gstart =   10; hkstart =   1; end
 if start==168; Astart =    1; Bstart =     10; gstart =   10; hkstart = eps; end
 if start==169; Astart =    1; Bstart =     10; gstart =  -10; hkstart = eps; end
 if start==170; Astart =    1; Bstart =     10; gstart =  -10; hkstart =   1; end
 if start==171; Astart =    0; Bstart =     10; gstart =   10; hkstart = eps; end
 if start==172; Astart =    0; Bstart =     10; gstart =  -10; hkstart = eps; end
 if start==173; Astart =    0; Bstart =     10; gstart =  -10; hkstart =   1; end 
 if start==174; Astart = medy; Bstart =     10; gstart =   10; hkstart =   1; end
 if start==175; Astart = medy; Bstart =     10; gstart =   10; hkstart = eps; end
 if start==176; Astart = medy; Bstart =     10; gstart =  -10; hkstart = eps; end
 if start==177; Astart = medy; Bstart =     10; gstart =  -10; hkstart =   1; end 
 if start==178; Astart =   -1; Bstart =     10; gstart =   10; hkstart =   1; end
 if start==179; Astart =   -1; Bstart =     10; gstart =   10; hkstart = eps; end
 if start==180; Astart =   -1; Bstart =     10; gstart =  -10; hkstart = eps; end
 if start==181; Astart =   -1; Bstart =     10; gstart =  -10; hkstart =   1; end 
 if start==182; Astart =    1; Bstart =     10; gstart =   1; hkstart =  10; end
 if start==183; Astart =    1; Bstart =     10; gstart = eps; hkstart =  10; end
 if start==184; Astart =    1; Bstart =     10; gstart =  -1; hkstart =  10; end
 if start==185; Astart =    0; Bstart =     10; gstart = eps; hkstart =  10; end
 if start==186; Astart =    0; Bstart =     10; gstart =  -1; hkstart =  10; end 
 if start==187; Astart = medy; Bstart =     10; gstart =   1; hkstart =  10; end
 if start==188; Astart = medy; Bstart =     10; gstart = eps; hkstart =  10; end
 if start==189; Astart = medy; Bstart =     10; gstart =  -1; hkstart =  10; end 
 if start==190; Astart =   -1; Bstart =     10; gstart =   1; hkstart =  10; end
 if start==191; Astart =   -1; Bstart =     10; gstart = eps; hkstart =  10; end
 if start==192; Astart =   -1; Bstart =     10; gstart =  -1; hkstart =  10; end 
 if start==193; Astart =    1; Bstart =     10; gstart =   10; hkstart =  10; end
 if start==194; Astart =    1; Bstart =     10; gstart =  -10; hkstart =  10; end
 if start==195; Astart =    0; Bstart =     10; gstart =  -10; hkstart =  10; end 
 if start==196; Astart = medy; Bstart =     10; gstart =   10; hkstart =  10; end
 if start==197; Astart = medy; Bstart =     10; gstart =  -10; hkstart =  10; end 
 if start==198; Astart =   -1; Bstart =     10; gstart =   10; hkstart =  10; end
 if start==199; Astart =   -1; Bstart =     10; gstart =  -10; hkstart =  10; end 
 if start==200; Astart =    1; Bstart =     100; gstart =   10; hkstart =   1; end
 if start==201; Astart =    1; Bstart =     100; gstart =   10; hkstart = eps; end
 if start==202; Astart =    1; Bstart =     100; gstart =  -10; hkstart = eps; end
 if start==203; Astart =    1; Bstart =     100; gstart =  -10; hkstart =   1; end
 if start==204; Astart =    0; Bstart =     100; gstart =   10; hkstart = eps; end
 if start==205; Astart =    0; Bstart =     100; gstart =  -10; hkstart = eps; end
 if start==206; Astart =    0; Bstart =     100; gstart =  -10; hkstart =   1; end 
 if start==207; Astart = medy; Bstart =     100; gstart =   10; hkstart =   1; end
 if start==208; Astart = medy; Bstart =     100; gstart =   10; hkstart = eps; end
 if start==209; Astart = medy; Bstart =     100; gstart =  -10; hkstart = eps; end
 if start==210; Astart = medy; Bstart =     100; gstart =  -10; hkstart =   1; end 
 if start==211; Astart =   -1; Bstart =     100; gstart =   10; hkstart =   1; end
 if start==212; Astart =   -1; Bstart =     100; gstart =   10; hkstart = eps; end
 if start==213; Astart =   -1; Bstart =     100; gstart =  -10; hkstart = eps; end
 if start==214; Astart =   -1; Bstart =     100; gstart =  -10; hkstart =   1; end 
 if start==215; Astart =    1; Bstart =     100; gstart =   1; hkstart =  10; end
 if start==216; Astart =    1; Bstart =     100; gstart = eps; hkstart =  10; end
 if start==217; Astart =    1; Bstart =     100; gstart =  -1; hkstart =  10; end
 if start==218; Astart =    0; Bstart =     100; gstart = eps; hkstart =  10; end
 if start==219; Astart =    0; Bstart =     100; gstart =  -1; hkstart =  10; end 
 if start==220; Astart = medy; Bstart =     100; gstart =   1; hkstart =  10; end
 if start==221; Astart = medy; Bstart =     100; gstart = eps; hkstart =  10; end
 if start==222; Astart = medy; Bstart =     100; gstart =  -1; hkstart =  10; end 
 if start==223; Astart =   -1; Bstart =     100; gstart =   1; hkstart =  10; end
 if start==224; Astart =   -1; Bstart =     100; gstart = eps; hkstart =  10; end
 if start==225; Astart =   -1; Bstart =     100; gstart =  -1; hkstart =  10; end 
 if start==226; Astart =    1; Bstart =     100; gstart =   10; hkstart =  10; end
 if start==227; Astart =    1; Bstart =     100; gstart =  -10; hkstart =  10; end
 if start==228; Astart =    0; Bstart =     100; gstart =  -10; hkstart =  10; end 
 if start==229; Astart = medy; Bstart =     100; gstart =   10; hkstart =  10; end
 if start==230; Astart = medy; Bstart =     100; gstart =  -10; hkstart =  10; end 
 if start==231; Astart =   -1; Bstart =     100; gstart =   10; hkstart =  10; end
 if start==232; Astart =   -1; Bstart =     100; gstart =  -10; hkstart =  10; end  
 %
 thetastart = [Astart,log(Bstart),gstart,log(hkstart)];
 [thetahat,negLLval,~,~,~,hessian] = ...     
     fminunc(@(theta) negLogLike(model,Q,lambda,n,theta),thetastart);
 Est(start,:)  = [thetahat(1),exp(thetahat(2)),thetahat(3),exp(thetahat(4))];
 SEs(start,:)  = real(sqrt(diag(inv(hessian))))';
 negLLs(start) = negLLval;
 startInd  = (1:232)';
 minnegLL  = negLLs==nanmin(negLLs);
 if start==232
  ResultsEst = [startInd,negLLs,minnegLL,Est];
  ResultsSE  = [startInd,negLLs,minnegLL,SEs];
 end
end
Lab{1}='StartValNum'; Lab{2}='negLL'; Lab{3} = 'minNegLL';
Lab{4}='A_est'; Lab{5}='B_est'; Lab{6}='g_est'; Lab{7}='hk_est';
%display(dataset([ResultsEst,Lab]));
%[ResultsEst(minnegLL,:);ResultsSE(minnegLL,:)]
%LabSE{1}='StartValNum'; LabSE{2}='negLL'; LabSe{3} = 'minNegLL';
%LabSE{4}='SE_A'; LabSE{5}='SE_B'; LabSE{6}='SE_g'; LabSE{7}='SE_hk';
%display(dataset([ResultsSE,Lab]));
bestResults = [ResultsEst(minnegLL,[1:2,4:7]);ResultsSE(minnegLL,[1:2,4:7])];
bestResults = bestResults(1:2,:);% in case multiple solutions have the same negLL
display(dataset([bestResults,Lab([1:2,4:7])],'ObsNames',{'Est','SE'}))