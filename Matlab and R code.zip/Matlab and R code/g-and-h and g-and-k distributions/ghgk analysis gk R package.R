Data <- read.csv(file="C:/Users/George/Desktop/qil/Results/g-and-h and g-and-k distributions/gh gk all data.csv",header=TRUE,sep=",")
setwd("C:/Users/George/Desktop/qil/Results/g-and-h and g-and-k distributions")

# fix(Data)
library(gk);

#===============================================================================================================
# Simulated Data
# MLE estimation via the fsda method.
#===============================================================================================================

# ghSim data analysis, MLE estimation via the fsda method.
x = Data[1:20000,1];
start_time <- Sys.time()
out = fdsa(x,N=1000,model="gh",theta0=c(mean(x),sd(x),0,0),theta_min=c(-5,1E-5,-5,0),theta_max=c(5,5,5,5))
end_time <- Sys.time()
end_time - start_time
MLE_ABgh_LogLike = out[nrow(out),]
#Time difference of 9.471014 secs
#Failed to produce output.
# true values:
#          A           B          g     h          
# true  -0.70       1.70      -0.40     0.50

# gkSim data analysis, MLE estimation via the fsda method.
x = Data[1:20000,2];
start_time <- Sys.time()
out = fdsa(x,N=1000,model="gk",theta0=c(mean(x),sd(x),0,0),theta_min=c(-5,1E-5,-5,0),theta_max=c(5,5,5,5))
end_time <- Sys.time()
end_time - start_time
#Time difference of 21.04703 secs
MLE_ABgk_LogLike = out[nrow(out),]
#        A           B          g   k estimated   log likelihood 
# 2.240395    2.541923   4.077628   0.000000      -58176.856193 



#===============================================================================================================
# Sulfur Dioxide Data
# MLE estimation via the fsda method.
#===============================================================================================================
# Sulfur Dioxide data analysis, MLE estimation via the fsda method.
x = Data[,3];
start_time <- Sys.time()
out = fdsa(x,N=1000,model="gh",theta0=c(mean(x),sd(x),0,0),theta_min=c(-100,1E-5,-100,0),theta_max=c(100,100,100,100))
end_time <- Sys.time()
end_time - start_time
MLE_ABgh_LogLike = out[nrow(out),]
#Time difference of  3.112338 mins
#MLE_ABgh_LogLike 
#   A                        B                        g                        h estimated log likelihood 
#  -19.29641                 59.97302                 99.72393                 40.06802            -416867.16915 
 
# Sulfur Dioxide data analysis, MLE estimation via the fsda method.
x = Data[,3];
start_time <- Sys.time()
out = fdsa(x,N=1000,model="gk",theta0=c(mean(x),sd(x),0,0),theta_min=c(-100,1E-5,-100,0),theta_max=c(100,100,100,100))
end_time <- Sys.time()
end_time - start_time
#Time difference of  3.925339 mins
MLE_ABgk_LogLike = out[nrow(out),]
#> MLE_ABgk_LogLike
#           A                        B                        g                        k estimated log likelihood 
#    81.07289                 96.59420                 71.22979                 77.64407            -563667.42620 
 

#===============================================================================================================
# Simulated Data
# MCMC using numerical evaluation of exact likelihood  for each case i = 1,...,n
#===============================================================================================================
# ghSim data analysis, MCMC estimation under noninformative improper prior.
# mcmc performs Markov chain Monte Carlo inference for iid data from a g-and-k or g-and-h distribution,
# using the adaptive Metropolis algorithm of Haario et al (2001). (from gk R package documentation)
# "For IID data the likelihood is the product each observation�s pdf. Evaluating this for the 
# g-and-k or g-and-h distributions using the pgk or pgh command requires n calls to numerical
# optimisation. Therefore MCMC becomes computationally expensive for even moderately large datasets." 
# (Prangle 2017)
x = Data[1:20000,1];
start_time <- Sys.time()
out = mcmc(x, N=50000, model="gh",theta0=c(mean(x),sd(x),0,0), Sigma0=0.1*diag(4))
end_time <- Sys.time()
end_time - start_time
# I confirm with Prangle (2017) that this run was computationally prohibitive.
# the package seemed to estimate a total run time of 2 days!
# Same would be true for model="gk"
# so I did not bother to run this model.



#===============================================================================================================
# Simulated Data
# ABC, c("all order statistics")
#===============================================================================================================

# ghSim data analysis, ABC estimation 
# under noninformative flat prior: A ~ U(-10,10), B ~ U(0,10), g ~ U(-10,10), k ~ U(0,10)
# Using sumstats = c("all order statistics")
# Excerpt from gk R package documentation:
# This function performs approximate Bayesian inference for iid data from a g-and-k or g-and-h distribution,
# avoiding expensive density calculations. The algorithm samples many parameter vectors
# from the prior and simulates corresponding data from the model. The parameters are accepted or
# rejected based on how similar the simulations are to the observed data. Similarity is measured using
# weighted Euclidean distance between summary vectors of the simulations and observations. Several
# summaries can be used, including the complete order statistics or summaries based on octiles.
# In the latter case only the corresponding order statistics are simulated, speeding up the method.
# Usage
# abc(x, N, model = c("gk", "gh"), logB = FALSE, rprior, M,
# sumstats = c("all order statistics", "octiles", "moment estimates"),
# silent = FALSE)
# Arguments
# x Vector of observations.
# N Number of iterations to perform.
# model Whether to fit g-and-k or g-and-h model.
# logB When true, the second parameter is log(B) rather than B.
# rprior A function with single argument, n, which returns a matrix with n rows consisting
# of samples from the prior distribution for 4 parameters e.g. (A,B,g,k).
# M Number of simulations to accept.
# sumstats Which summary statistics to use.#sumstats = c("all order statistics", "octiles", "moment estimates")
# silent When FALSE (the default) a progress bar is shown.
#
x = Data[1:20000,1];
start_time <- Sys.time()
rprior = function(n) { cbind(runif(n,-10,10),runif(n,0,10),runif(n,-10,10),runif(n,0,10)) }
out    = abc(x, model="gh", N=50000, rprior=rprior, M=1000)
end_time <- Sys.time()
end_time - start_time
# Time difference of  6.846331 mins 
# fix(out)
# summarize M=1000 accepted parameter values.
# rbind(colMeans(out),apply(out, 2, sd))
#              A        B          g        h  distance
#[1,] -0.7194873 1.365922 -0.1053745 3.261614 140.29425
#[2,]  0.6329570 1.023075  5.5423196 2.448457  76.39183
# true values:
#              A        B          g        h          
true_gh =  c(-0.70,   1.70,    -0.40,    0.50)
out_ghSim = out;
RMSE = sqrt( colMeans( (out_ghSim[,1:4] - true_gh)^2 ) )
#> RMSE
#       A        B        g        h 
# 1.510872 1.760783 5.565846 3.986310


# gkSim data analysis, ABC estimation 
# under noninformative flat prior: A ~ U(-10,10), B ~ U(0,10), g ~ U(-10,10), k ~ U(0,10)
# Using sumstats = c("all order statistics")
x = Data[1:20000,2];
start_time <- Sys.time()
rprior = function(n) { cbind(runif(n,-10,10),runif(n,0,10),runif(n,-10,10),runif(n,0,10)) }
out    = abc(x, model="gk", N=50000, rprior=rprior, M=1000)
end_time <- Sys.time()
end_time - start_time
# Time difference of  5.78331 mins 
# fix(out)
# summarized M=1000 accepted parameter values.
rbind(colMeans(out),apply(out, 2, sd))
#              A        B          g        k  distance
#[1,] -0.6695839 1.499837 -0.2563459 3.195281 108.47335
#[2,]  0.5899633 1.176874  5.5288868 2.342245  65.89831
#  
# true values:
#              A        B          g        k          
true_gk =  c(-0.70,   1.70,    -0.40,    0.50)
out_gkSim = out;
RMSE = sqrt( colMeans( (out_gkSim[,1:4] - true_gk)^2 ) )
#> RMSE
#       A        B        g        k 
#1.466418 1.884961 5.609473 3.886002


#===============================================================================================================
# Simulated data.
# ABC sumstats = "Octiles"
#===============================================================================================================
# ghSim data analysis, ABC estimation 
# under noninformative flat prior: A ~ U(-10,10), B ~ U(0,10), g ~ U(-10,10), k ~ U(0,10)
# Using sumstats = "Octiles"
x = Data[1:20000,1];
start_time <- Sys.time()
rprior = function(n) { cbind(runif(n,-10,10),runif(n,0,10),runif(n,-10,10),runif(n,0,10)) }
out    = abc(x, model="gh", sumstats = "Octiles", N=1000000, rprior=rprior, M=1000)
end_time <- Sys.time()
end_time - start_time
# Time of  52.35407 secs
# fix(out)
# summarize M=1000 accepted parameter values.
rbind(colMeans(out),apply(out, 2, sd))
#              A        B          g        h   distance
[1,] -0.7468897 1.957301 -0.3845572 1.514522 0.04591091
[2,]  0.7260973 1.369806  0.3163558 1.040992 0.01956838
# true values:
#              A        B          g        h          
true_gh =  c(-0.70,   1.70,    -0.40,    0.50)
out_ghSim_Octiles = out;
RMSE = sqrt( colMeans( (out_ghSim_Octiles[,1:4] - true_gh)^2 ) )
#> RMSE
#       A        B        g        h 
#1.547418 2.327613 1.188639 1.887382




# gkSim data analysis, ABC estimation 
# under noninformative flat prior: A ~ U(-10,10), B ~ U(0,10), g ~ U(-10,10), k ~ U(0,10)
# Using sumstats = "Octiles"
x = Data[1:20000,2];
start_time <- Sys.time()
rprior = function(n) { cbind(runif(n,-10,10),runif(n,0,10),runif(n,-10,10),runif(n,0,10)) }
out    = abc(x, model="gk", sumstats = "Octiles", N=1000000, rprior=rprior, M=1000)
end_time <- Sys.time()
end_time - start_time
# Time difference of 56.56508 secs 
# fix(out)
# summarized M=1000 accepted parameter values.
rbind(colMeans(out),apply(out, 2, sd))
#              A        B          g         k   distance
[1,] -0.6955835 3.578937 -0.4954989 1.3955185 0.02540094
[2,]  0.5387900 2.492210  0.2496819 0.9348272 0.01138677
#              A        B          g        k          
true_gk =  c(-0.70,   1.70,    -0.40,    0.50)
out_gkSim_Octiles = out;
RMSE = sqrt( colMeans( (out_gkSim_Octiles[,1:4] - true_gk)^2 ) )
RMSE
#       A        B        g        k 
# 1.455040 4.244606 1.245650 1.695066




#===============================================================================================================
# Sulfur Dioxide data.
# ABC, sumstats = c("all order statistics")
# TAKES TOO LONG TO RUN
#===============================================================================================================

# Sulfur Dioxide data analysis, ABC estimation 
# under noninformative flat prior: A ~ U(-10,10), B ~ U(0,10), g ~ U(-10,10), k ~ U(0,10)
# Using sumstats="Octiles"
# TAKES TOO LONG TO RUN Using sumstats = c("all order statistics")
x = Data[,3];
start_time <- Sys.time()
rprior = function(n) { cbind(runif(n,-10,10),runif(n,0,10),runif(n,-10,10),runif(n,0,10)) }
out    = abc(x, model="gh", sumstats="Octiles", N=500000, rprior=rprior, M=1000)
end_time <- Sys.time()
end_time - start_time
# Time difference of  27.78204 secs
# fix(out)
# summarize M=1000 accepted parameter values.
# rbind(colMeans(out),apply(out, 2, sd))
#             A        B         g        h   distance
#[1,] 0.3512546 1.786721 0.7170769 1.553869 0.08671176
#[2,] 0.9346836 1.308104 0.4441276 1.106244 0.03667765
out_gh_SulphurDioxide = out;



# Sulfur Dioxide data analysis, ABC estimation 
# under noninformative flat prior: A ~ U(-10,10), B ~ U(0,10), g ~ U(-10,10), k ~ U(0,10)
# Using sumstats="Octiles"
# TAKES TOO LONG TO RUN Using sumstats = c("all order statistics")
x = Data[,3];
start_time <- Sys.time()
rprior = function(n) { cbind(runif(n,-10,10),runif(n,0,10),runif(n,-10,10),runif(n,0,10)) }
out    = abc(x, model="gk", sumstats="Octiles", N=500000, rprior=rprior, M=1000)
end_time <- Sys.time()
end_time - start_time
# Time difference of    27.64204 secs
# fix(out)
# summarized M=1000 accepted parameter values.
# rbind(colMeans(out),apply(out, 2, sd))
#             A        B         g        k   distance
#[1,] 0.2633445 3.881994 0.7306711 1.489607 0.04649882
#[2,] 0.7029486 2.653296 0.3264314 1.003926 0.01943613
out_gk_SulphurDioxide = out;


#> ls()
# [1] "Data"                 
# [2] "end_time"             
# [3] "out"                  
# [5] "out_ghSim"            
# [8] "out_gkSim"            

# [6] "out_ghSim_Octiles"    
# [9] "out_gkSim_Octiles"    
#[10] "RMSE"              

# [4] "out_gh_SulphurDioxide"
# [7] "out_gk_SulphurDioxide"
   
#[11] "rprior"               
#[12] "start_time"           
#[13] "true_gh"              
#[14] "true_gk"              
#[15] "x"        


fileName  = paste('ABC results g-and-h and g-and-k ',Sys.time(),".RData",sep="");
fileName  = gsub(":", "_", fileName);
save.image(file=fileName)


