% =========================================================================
% CODE FOR BASYESIAN INFERENCE OF THE g-and-h DISTRIBUTION.
% BASED ON SIMULATED DATA, or real data.
% =========================================================================
% Data set up
% -------------------------------------------------------------------------
% simulate data:
clear;
n = 20000;
% True data-generating parameters:
A = -.7; % location
B = 1.7; % scale  B > 0
c = .8; % choice c<=.83 guarantees a completely proper distribution
g = -.4; % skewness
h = .5;  % kurtosis (h>0).
%z = normrnd(0,1,n,1);
%y = A + B*(1 + c*tanh(g*z./2)).*z.*exp((h*(z.^2))/2);
y = xlsread('sim gh n=20k.csv');
% -------------------------------------------------------------------------
%clear; %real data analysis
% Sulfur dioxide concentration, in ppb, as a numeric vector.(n = 63371)
%Data = xlsread('mydata.xls');
%y = Data(:,8);  y = y(~isnan(y),:);
%y = y/100; % rescale to ppb/100 for more numerical stability.
%n = length(y);
%c = .8; % choice c<=.83 guarantees a completely proper distribution
%A = []; B = []; g = []; h = []; % True values unknown.
% -------------------------------------------------------------------------
% simulate data, using estimates of real data analysis as true parameters:
%clear;
%n = 63371;
% True data-generating parameters:
%A = .43; % location
%B = .33; % scale  B > 0
%c = .8; % choice c<=.83 guarantees a completely proper distribution
%g = .90; % skewness
%h = .59;  % kurtosis (h>0).
%z = normrnd(0,1,n,1);
%y = A + B*(1 + c*tanh(g*z./2)).*z.*exp((h*(z.^2))/2);
% -------------------------------------------------------------------------
tic;
% -------------------------------------------------------------------------
% Prior set up. Prior density is (Prangle, 2017, p.8): 
% p(A,B,g,k,c) propto 1(a_A<A<b_A))1(a_B<B<b_B)1(a_g<g<b_g)1(a_k<k<b_k)delta_.8(c)
%a_A = -1;  b_A = 1;     a_B = 0;  b_B =  1;
%a_g = -5;  b_g = 5;     a_h = 0;  b_h = 10;
%a = [a_A, a_B, a_g, a_h];  b = [b_A, b_B, b_g, b_h];
% -------------------------------------------------------------------------
% MH algorithm set up.
% -------------------------------------------------------------------------
S = 10000; % # MH sampling iterations.
% -------------------------------------------------------------------------

% Run MH algorithm for S iterations.
for s = 1:S
 if s==1   %  Initialize
   warning('off','all');
   % ------------------------------------------------
   % estimate lambda and d
   % ------------------------------------------------
   ks2stat = Inf; d = 0;
   while (ks2stat>.01) && (d<=n)
    d = d+1;                 lambda        = ((1:d)/(d+1))';
    Q = quantile(y,lambda);  [~,~,ks2stat] = kstest2(Q,y);
   end %[d,ks2stat]
   % ----------------------------------------------------------------------
   % Find the maximum log likelihood estimator as the starting value:
   % ----------------------------------------------------------------------
   thetahat = ghgkQfit('g and h',Q,lambda,y,n);
   thetahat = thetahat(1,3:6);
   A1 = thetahat(1); B1 = thetahat(2); g1 = thetahat(3); h1 = thetahat(4);
   % ----------------------------------------------------------------------   
   Samples_ABgh = NaN(S,4);
   % Adaptive Metropolis parameters:
   D     = length([A1,B1,g1,h1]); S2D = S*2*D;
   muhat = [A1,B1,g1,h1]'; EXXt = muhat*muhat'; Jitter = .0001*eye(D);
   cMH1  = (2.38^2)/D; cMH2 = sqrt((.1^2)/D);
   LL0 = -Inf;   
 end
 % ------------------------------------------------------------------------
 % Sample from proposal distribution.
 % ------------------------------------------------------------------------
 if (rand >.05)&&(s>S2D); R = mvnrnd ([A0,B0,g0,h0], cMH1*Vhat);
 else;            if s>1; R = normrnd([A0,B0,g0,h0],      cMH2); end; end
 if s>1; A1 = R(1); B1 = R(2); g1 = R(3); h1 = R(4); end
 % ------------------------------------------------------------------------
 if s==1; J  = 10000; end; % Synthetic data sample size.
 if s==1; bw = .9*min([std(y,1),iqr(y)/1.34])*(n^(-1/5));end;% bandwidth for kernel estiamtion of synthetic data.
 if s==1; A0 = A1; B0 = B1; g0 = g1; h0 = h1; 
   zsyn0 = normrnd(0,1,J,1);
   ysyn0 = A0 + B0*(1 + c*tanh(g0*zsyn0./2)).*zsyn0.*exp((h0*(zsyn0.^2))/2);
   [LL0,~]   = ksdensity(ysyn0,y,'Kernel','epanechnikov','Bandwidth',bw);  
   LL0       = sum(log(LL0+eps)); 
 end
 if s>1
  zsyn1 = normrnd(0,1,J,1);
  ysyn1 = A1 + B1*(1 + c*tanh(g1*zsyn1./2)).*zsyn1.*exp((h1*(zsyn1.^2))/2);
  [LL1,~]   = ksdensity(ysyn1,y,'Kernel','epanechnikov','Bandwidth',bw);  
  LL1       = sum(log(LL1+eps));
  if (log(rand)<(LL1-LL0))||(s==1); A0 = A1; B0 = B1; g0 = g1; h0 = h1; LL0 = LL1; end
 end
 Samples_ABgh(s,:) = [A0,B0,g0,h0];
 % ------------------------------------------------------------------------
 % Update proposal distribution covariance matrix:
 % ------------------------------------------------------------------------
 muhat = (Samples_ABgh(s,:)' + (s-1)*muhat)/s;
 EXXt  = ((Samples_ABgh(s,:)'*Samples_ABgh(s,:)) + ((s-1)*EXXt))./s;
 Vhat  = (EXXt - muhat*muhat') + Jitter;
 if (s/100)==round(s/100); disp(s); end % Display iteration
 % ------------------------------------------------------------------------
 % Produce Output after the end of the Metropolis algorithm run:
 % ------------------------------------------------------------------------
 if s==S
  computationTimeSeconds = toc; %Elapsed time
  a_A = min(Samples_ABgh(:,1))-.001;  b_A = max(Samples_ABgh(:,1))+.001;
  a_B = min(Samples_ABgh(:,2))-.001;  b_B = max(Samples_ABgh(:,2))+.001;
  a_g = min(Samples_ABgh(:,3))-.001;  b_g = max(Samples_ABgh(:,3))+.001;
  a_h = min(Samples_ABgh(:,4))-.001;  b_h = max(Samples_ABgh(:,4))+.001;  
  %------------------------------------------------------------------------
  % Trace plots
  %------------------------------------------------------------------------
  figure('Color','white');
  subplot(1,4,1); plot(Samples_ABgh(:,1)); 
    xlabel('Sampling Iteration'); ylabel('\itA'); ylim([a_A,b_A]);
    if ~isempty(A); text(S,A,strcat({' '},num2str(round(A,2)))); end
  subplot(1,4,2); plot(Samples_ABgh(:,2));
    xlabel('Sampling Iteration'); ylabel('\itB'); ylim([a_B,b_B]);
    if ~isempty(B); text(S,B,strcat({' '},num2str(round(B,2)))); end
  subplot(1,4,3); plot(Samples_ABgh(:,3));
    xlabel('Sampling Iteration'); ylabel('\itg'); ylim([a_g,b_g]);
    if ~isempty(g); text(S,g,strcat({' '},num2str(round(g,2)))); end
  subplot(1,4,4); plot(Samples_ABgh(:,4));
    xlabel('Sampling Iteration'); ylabel('\ith'); ylim([a_h,b_h]);
    if ~isempty(h); text(S,h,strcat({' '},num2str(round(h,2)))); end
  %------------------------------------------------------------------------
  % Table of posterior mean and Sd estimates, compared to the true values  
  %------------------------------------------------------------------------
  format bank;
  noBurn = 1:S;
  EABgh  = mean(Samples_ABgh(noBurn,:)); 
  SDABgh =  std(Samples_ABgh(noBurn,:),1);
  LabTime{1} = 'TimeSec'; Lab{2} = 'Iterations'; 
  timeResults = [computationTimeSeconds,S];
  display(dataset([timeResults LabTime]));  
  Lab{1} = 'A'; Lab{2} = 'B'; Lab{3} = 'g'; Lab{4} = 'h'; 
  if ~isempty(A)
    Results = [A,B,g,h; thetahat; EABgh; SDABgh];
    display(dataset([Results Lab],'ObsNames',{'true','QMLEstart','postE','postSD'}));   
  else
    Results = [thetahat; EABgh; SDABgh];
    display(dataset([Results Lab],'ObsNames',{'QMLEstart','postE','postSD'}));
  end
 end
end
save(char(strcat({'g and h Analysis Brute'},strrep(datestr(datetime),':','_'),'.mat')))