clear;
% Sulphur dioxide data:
%Data = xlsread('mydata.xls'); y = Data(:,9);  y = y(~isnan(y),:); n = length(y);
%
% Simulated data:
n = 20000;
% True data-generating parameters:
A = -.7; % location
B = 1.7; % scale  B > 0
c = .8; % choice c<=.83 guarantees a completely proper distribution
g = -.4; % skewness
h = .5;  % kurtosis (h>0).
z = normrnd(0,1,n,1);
y = A + B*(1 + c*tanh(g*z./2)).*z.*exp((h*(z.^2))/2);
% ------------------------------------------------
% estimate lambda and d
% ------------------------------------------------
ks2stat = Inf; d = 0;
while (ks2stat>.01) && (d<200)
 d = d+1;                 lambda        = ((1:d)/(d+1))';
 Q = quantile(y,lambda);  [~,~,ks2stat] = kstest2(Q,y);
end %[d,ks2stat]

bestResultsgh = ghgkQfit('g and h',Q,lambda,y,n);
bestResultsgk = ghgkQfit('g and k',Q,lambda,y,n);
% ------------------------------------------------
